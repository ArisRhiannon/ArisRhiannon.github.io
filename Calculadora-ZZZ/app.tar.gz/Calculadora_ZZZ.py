﻿import flet as ft
import os
import logging
from cargar_datos import CargadorDatos
from logica_danos import LogicaDmg
from Crear_Gui import CrearGui
from gestor_api import GestorApi
from estado_build import EstadoBuild
from efectos_mindscapes import CONFIG_MINDSCAPES, MAPA_MINDSCAPES
from gestor_estadisticas import GestorEstadisticas
from efectos_wengines import MAPA_WENGINES, CONFIG_WENGINES
from efectos_sets import MAPA_EFECTOS_SETS, CONFIG_SETS
from efectos_core import MAPA_CORE, CONFIG_CORE_UI
from efectos_pasivas import CONFIG_PASIVAS_UI
from efectos_soportes import MAPA_SOPORTES_AGENTES, MAPA_SOPORTES_SETS
from efectos_soportes import MAPA_SOPORTES_WENGINES
import sys
import json
import csv

logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CalculadoraZZZ:
    def __init__(self, page: ft.Page,
                 cargador: CargadorDatos = None,
                 logica_dmg: LogicaDmg = None):
        self.logger = logger
        self.page = page
        self.base_path = self.obtener_ruta_base()
        self.datos_dir = os.path.join(self.base_path, 'datos')
        self.gestor_stats = GestorEstadisticas()

        self.gui = CrearGui(self)
        self.cargador = cargador or CargadorDatos(self.datos_dir)
        self.gestor_api = GestorApi()
        self.logica_dmg = logica_dmg or LogicaDmg(logger=logger)

        self.estado_actual = EstadoBuild()
        self.agentes_data, self.wengine_data, self.habilidades_agente, self.enemigos_data, self.sets_data, self.discos_data = [], {}, {}, [], [], {}
        self.tres_leches = False
        self.base_stats, self.elemento, self.tipo = {}, None, None
        self.substats_db = []
        self.ultimos_stats_calculados = {}
        self.base_enemigo = {}

        self.gui.page = page
        self.build_ui()
        self.cargar_datos()

    def obtener_ruta_base(self):
        return os.path.dirname(os.path.abspath(__file__))
    
    def build_ui(self):
        tabs = ft.Tabs(
            tabs=[
                ft.Tab(text="DPS", content=self.gui.create_character_tab()),
                ft.Tab(text="Agentes en tu equipo", content=self.gui.create_buffs_tab()),
                ft.Tab(text="Guardar y cargar builds", content=self.gui.create_comparator_tab()),
                ft.Tab(text="Recomendaciones", content=self.gui.create_recommendations_tab()),
                ft.Tab(text="Gráficas", content=self.gui.create_graph_tab()),
            ], expand=True
        )
        self.page.add(tabs)
        self.configurar_eventos()

    def configurar_eventos(self):
        self.gui.agent_dropdown.on_change = lambda e: self.cargar_agente(e.control.value)
        self.gui.wengine_dropdown.on_change = lambda e: self.cargar_wengine(e.control.value)
        self.gui.stacks_dropdown.on_change = self.cambiar_stacks
        self.gui.set_stacks_dropdown.on_change = self.cambiar_set_stacks
        self.gui.set_checkbox.on_change = self.cambiar_set_condicion
        self.gui.habilidad_dropdown.on_change = self.manejador_habilidad
        self.gui.enemy_dropdown.on_change = lambda e: self.cargar_enemigo(e.control.value)
        self.gui.dd_estado_enemigo.on_change = self.calcular_dano
        self.gui.set1_dropdown.on_change = lambda e: self.aplicar_set(e.control.value, 'set1')
        self.gui.set2_dropdown.on_change = lambda e: self.aplicar_set(e.control.value, 'set2')
        self.gui.set3_dropdown.on_change = lambda e: self.aplicar_set(e.control.value, 'set3')
        self.gui.mindscape_dropdown.on_change = self.cambiar_mindscape
        self.gui.mindscape_stacks_dropdown.on_change = self.cambiar_mindscape_stacks
        self.gui.core_checkbox.on_change = self.cambiar_core_activo
        self.gui.chk_filtro_wengine.on_change = self.cambiar_filtro_wengines
        for slot, dropdown in self.gui.disco_dropdowns.items():
            dropdown.on_change = lambda e, s=slot: self.aplicar_disco(e.control.value, s)
        for field in self.gui.entry_vars.values():
            if hasattr(field, 'data') and field.data:
                field.on_submit = self.manejar_edicion_stat
        if hasattr(self.gui, 'dd_estado_enemigo'):
            self.gui.dd_estado_enemigo.on_change = self.calcular_dano
        self.configurar_eventos_soporte("sup1")
        self.configurar_eventos_soporte("sup2")

    def configurar_eventos_soporte(self, prefijo):
        """
        Lógica inteligente para Soportes:
        """

        def on_change_agente(e):
            nombre_agente = e.control.value

            dd_wengine = self.gui.team_controls.get(f"{prefijo}_wengine")
            dd_set = self.gui.team_controls.get(f"{prefijo}_set4")
            txt_tipo = self.gui.team_controls.get(f"{prefijo}_tipo")
            txt_elemento = self.gui.team_controls.get(f"{prefijo}_elemento")
            txt_faccion = self.gui.team_controls.get(f"{prefijo}_faccion")

            self.gui.actualizar_imagen_team(prefijo, "agente", nombre_agente)

            if nombre_agente == "Ninguno":
                todas_armas = list(self.wengine_data.keys())
                todas_armas.sort()
                
                if dd_wengine:
                    dd_wengine.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in todas_armas]
                    dd_wengine.value = "Ninguno"
                    self.gui.actualizar_imagen_team(prefijo, "wengine", "Ninguno")
                
                if dd_set: dd_set.value = "Ninguno"
                if txt_tipo: txt_tipo.value = ""
                if txt_elemento: txt_elemento.value = ""
                if txt_faccion: txt_faccion.value = ""
                
                self.recalcular_stats_finales()
                self.gui.page.update()
                return

            agente_data = next((a for a in self.agentes_data if a['Nombre'] == nombre_agente), None)
            
            if agente_data:
                if txt_tipo: txt_tipo.value = agente_data.get("Tipo", "")
                if txt_elemento: txt_elemento.value = agente_data.get("Elemento", "") or agente_data.get("elemento", "")
                if txt_faccion: txt_faccion.value = agente_data.get("Faccion", "") or agente_data.get("Facción", "")

                if dd_wengine:
                    tipo_agente = agente_data.get("Tipo", "")
                    tipo_agente_norm = self.gestor_stats._normalizar(tipo_agente)
                    
                    armas_filtradas = []
                    for w_nombre, w_datos in self.wengine_data.items():
                        w_tipo = w_datos.get('tipow', '')
                        if self.gestor_stats._normalizar(w_tipo) == tipo_agente_norm:
                            armas_filtradas.append(w_nombre)
                    armas_filtradas.sort()
                    dd_wengine.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in armas_filtradas]

                    arma_firma = "Ninguno"
                    for w_nombre, w_datos in self.wengine_data.items():
                        if w_datos.get('agente') == nombre_agente:
                            arma_firma = w_nombre
                            break
                    
                    dd_wengine.value = arma_firma if arma_firma in armas_filtradas else "Ninguno"
                    self.gui.actualizar_imagen_team(prefijo, "wengine", dd_wengine.value)

                if dd_set:
                    set_rec = agente_data.get("Conjunto 4 piezas") or agente_data.get("Set 4pc")
                    existe_set = any(s['Nombre'] == set_rec for s in self.sets_data) if set_rec else False
                    dd_set.value = set_rec if existe_set else "Ninguno"
            
            self.recalcular_stats_finales()
            self.gui.page.update()
        
        def on_change_wengine(e):
            nombre = e.control.value
            self.gui.actualizar_imagen_team(prefijo, "wengine", nombre)
            self.recalcular_stats_finales()

        def on_change_arma_stats(e):
            self.recalcular_stats_finales()

        def on_change_set(e):
            self.recalcular_stats_finales()

        if f"{prefijo}_set4" in self.gui.team_controls:
                self.gui.team_controls[f"{prefijo}_set4"].on_change = on_change_set
        keys_stats = ["atk", "hp", "crit_rate", "crit_dmg", "er", "am", "pen", "ap"]

        for key in keys_stats:
                nombre_control = f"{prefijo}_stat_{key}"
                campo = self.gui.team_controls.get(nombre_control)
                
                if campo:
                    campo.on_change = lambda e: self.recalcular_stats_finales()

        if f"{prefijo}_mindscape" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_mindscape"].on_change = lambda e: self.recalcular_stats_finales()
            
        if f"{prefijo}_mindscape_stacks" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_mindscape_stacks"].on_change = lambda e: self.recalcular_stats_finales()
            
        if f"{prefijo}_mindscape_cond" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_mindscape_cond"].on_change = lambda e: self.recalcular_stats_finales()

        if f"{prefijo}_wengine" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_wengine"].on_change = on_change_wengine

        if f"{prefijo}_wengine_ref" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_wengine_ref"].on_change = on_change_arma_stats
        
        if f"{prefijo}_wengine_stacks" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_wengine_stacks"].on_change = on_change_arma_stats
        
        if f"{prefijo}_agente" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_agente"].on_change = on_change_agente

        if f"{prefijo}_set4" in self.gui.team_controls:
            self.gui.team_controls[f"{prefijo}_set4"].on_change = on_change_set

    def modificar_substat(self, unique_key, delta):
        valor_actual = self.estado_actual.substats_counts.get(unique_key, 0)
        nuevo_valor = valor_actual + delta
        
        if 0 <= nuevo_valor <= 40:
            self.estado_actual.substats_counts[unique_key] = nuevo_valor

            if unique_key in self.gui.substat_counters:
                self.gui.substat_counters[unique_key].value = str(nuevo_valor)
                self.gui.substat_counters[unique_key].update()
            
            self.recalcular_stats_finales()

    def cargar_datos(self):
        try:
            self.agentes_data = self.cargador.cargar_csv('agentes.csv')
            self.wengine_data = self.cargador.cargar_wengine('wengine.csv')
            self.enemigos_data = self.cargador.cargar_csv('enemigos.csv')
            self.sets_data = self.cargador.cargar_csv('sets.csv')

            # Carga de substats dinámica
            raw_substats = self.cargador.cargar_csv('substat.csv')
            self.substats_db = []
            key_substat_real = 'substat'
            if raw_substats and len(raw_substats) > 0:
                keys = raw_substats[0].keys()
                key_substat_real = next((k for k in keys if "substat" in k.lower()), 'substat')

            for item in raw_substats:
                tipo = item.get('tipo', '').strip().lower()
                nombre_substat = item.get(key_substat_real, "Desconocido")
                unique_key = f"{nombre_substat}_{tipo}"
                
                self.substats_db.append({
                    'key_interna': nombre_substat, 
                    'tipo': tipo,                  
                    'valor': self._parse_valor(item.get('valor', 0)),
                    'unique_key': unique_key,      
                    'label': f"{nombre_substat} ({'%' if 'porcentual' in tipo else 'Flat'})"
                })
                
                if unique_key not in self.estado_actual.substats_counts:
                    self.estado_actual.substats_counts[unique_key] = 0

            raw_discos = self.cargador.cargar_csv('discos.csv')
            self.discos_data = {4: [], 5: [], 6: []}
            for disco in raw_discos:
                slot = int(disco.get('slot', 0))
                if slot in self.discos_data:
                    self.discos_data[slot].append(disco)

            self.actualizar_controles_con_datos()
            self.gui.generar_substats_ui(self.substats_db)

        except Exception as e:
            logger.error(f"FALLO CRÍTICO EN CARGA DE DATOS: {e}", exc_info=True)

    def abrir_dialogo_uid(self, e):
        """ Muestra el popup para pedir el UID (Usa Enka.network) """
        self.campo_uid_input = ft.TextField(
            label="UID", 
            hint_text="Ej: 130088...", 
            width=250, 
            text_align=ft.TextAlign.CENTER
        )
        
        self.dialogo_uid = ft.AlertDialog(
            title=ft.Text("Importar Personaje"),
            content=ft.Column([
                ft.Text("Descargando datos desde Enka.network..."),
                self.campo_uid_input
            ], height=80, tight=True, alignment=ft.MainAxisAlignment.CENTER),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: self.page.close(self.dialogo_uid)),
                ft.ElevatedButton("Buscar", on_click=self.ejecutar_busqueda_uid, bgcolor=ft.Colors.BLUE_900, color="white")
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.page.open(self.dialogo_uid)

    def ejecutar_busqueda_uid(self, e):
        uid = self.campo_uid_input.value.strip()
        if not uid:
            self.mostrar_mensaje("Por favor escribe un UID.")
            return

        self.page.close(self.dialogo_uid)
        self.mostrar_mensaje(f"Consultando UID {uid}...")
        self.page.update()


        personajes, error = self.gestor_api.obtener_datos_uid(uid)

        if error != "OK":
            self.mostrar_mensaje(f"Error: {error}")
            return

        if personajes:
            self.lista_personajes_temp = personajes

            self.abrir_selector_personajes()
        else:
            self.mostrar_mensaje("UID válido pero sin personajes públicos.")

    def cambiar_core_activo(self, e):
        self.estado_actual.core_activo = e.control.value
        self.recalcular_stats_finales()
        
    def actualizar_controles_con_datos(self):
        self.gui.agent_dropdown.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(a['Nombre']) for a in self.agentes_data]
        self.gui.wengine_dropdown.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in self.wengine_data.keys()]
        if self.enemigos_data:
            self.gui.enemy_dropdown.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(e['Nombre']) for e in self.enemigos_data]
            self.gui.enemy_dropdown.value = "Ninguno"
            self.cargar_enemigo("Ninguno")
        set_options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(s['Nombre']) for s in self.sets_data]
        self.gui.set1_dropdown.options, self.gui.set2_dropdown.options, self.gui.set3_dropdown.options = set_options, set_options, set_options
        for slot, discos in self.discos_data.items():
            if slot in self.gui.disco_dropdowns:
                self.gui.disco_dropdowns[slot].options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(d['nombre']) for d in discos]
        self.gui.team_controls["sup1_agente"].options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(a['Nombre']) for a in self.agentes_data]
        self.gui.team_controls["sup2_agente"].options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(a['Nombre']) for a in self.agentes_data]
        self.gui.team_controls["sup1_wengine"].options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in self.wengine_data.keys()]
        self.gui.team_controls["sup2_wengine"].options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in self.wengine_data.keys()]
        self.gui.team_controls["sup1_set4"].options = set_options
        self.gui.team_controls["sup2_set4"].options = set_options
        
        self.gui.team_controls["sup1_set4"].value = "Ninguno"
        self.gui.team_controls["sup2_set4"].value = "Ninguno"
        self.gui.team_controls["sup1_agente"].value = "Ninguno"
        self.gui.team_controls["sup2_agente"].value = "Ninguno"
        self.gui.team_controls["sup1_wengine"].value = "Ninguno"
        self.gui.team_controls["sup2_wengine"].value = "Ninguno"

        self.gui.actualizar_imagen_team("sup1", "agente", "Ninguno")
        self.gui.actualizar_imagen_team("sup2", "agente", "Ninguno")
        self.gui.actualizar_imagen_team("sup1", "wengine", "Ninguno")
        self.gui.actualizar_imagen_team("sup2", "wengine", "Ninguno")
        self.gui.page.update()

    def abrir_selector_personajes(self):
        """ Abre un segundo diálogo para elegir qué personaje importar """

        opciones = []
        for i, p in enumerate(self.lista_personajes_temp):
            nombre = p.get("name", "Desconocido")
            nivel = p.get("level", "?")
            texto = f"{nombre} (Nv. {nivel})"
            opciones.append(ft.dropdown.Option(key=str(i), text=texto))

        self.dropdown_selector_uid = ft.Dropdown(
            label="Selecciona Agente",
            options=opciones,
            width=250,
            autofocus=True
        )
        
        if opciones:
            self.dropdown_selector_uid.value = "0"

        self.dialogo_selector = ft.AlertDialog(
            title=ft.Text("Personajes Encontrados"),
            content=ft.Column([
                ft.Text("Tus agentes en exposición son los siguientes:"),
                self.dropdown_selector_uid
            ], height=100, tight=True, alignment=ft.MainAxisAlignment.CENTER),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: self.page.close(self.dialogo_selector)),
                ft.ElevatedButton("IMPORTAR", on_click=self.confirmar_seleccion_uid, bgcolor=ft.Colors.GREEN_700, color="white")
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        
        self.page.open(self.dialogo_selector)

    def confirmar_seleccion_uid(self, e):
        """ Se ejecuta al dar click en IMPORTAR en el selector """
        idx_str = self.dropdown_selector_uid.value
        
        if not idx_str:
            return

        try:
            idx = int(idx_str)
            personaje_elegido = self.lista_personajes_temp[idx]
            
            self.page.close(self.dialogo_selector)
            
            self.mostrar_mensaje(f"Cargando a {personaje_elegido['name']}...")

            self._cargar_formato_externo(personaje_elegido)
            
        except Exception as ex:
            self.mostrar_mensaje(f"Error al cargar selección: {ex}")

    def _parse_valor(self, valor, es_porcentual=False):
        if valor is None: return 0.0
        try:
            val_str = str(valor).replace('%', '').replace(',', '.').strip()
            num = float(val_str) if val_str else 0.0
            return num / 100.0 if es_porcentual else num
        except (ValueError, TypeError):
            return 0.0

    def cargar_agente(self, nombre):
        """
        Carga toda la información del agente seleccionado:
        Stats base, Elemento, Habilidades, Arma firma y Configuración de UI (Stacks).
        """
        self.estado_actual.nombre_agente = nombre
        self.base_stats.clear()
        
        if nombre == "Ninguno":
            self.elemento = None
            self.tipo = None
            self.habilidades_agente = {}
            self.estado_actual.nombre_habilidad = None
            self.gui.core_stacks_dropdown.visible = False
            self.gui.core_stacks_dropdown.update()
            
        else:
            agente = next((a for a in self.agentes_data if a['Nombre'] == nombre), None)
            
            if agente:
                mapeo = { 
                    'nivel': 'Nivel', 'ataque': 'Ataque', 'puntos de vida': 'Puntos_Vida', 
                    'defensa': 'Defensa', 'probabilidad': 'Probabilidad_crítico', 
                    'daño crítico': 'Daño_crítico', 'daño elemental': 'Daño_elemental', 
                    'Maestría de anomalía': 'Maestría_Anomalía', 'tasa de anomalía': 'Tasa_de_Anomalía', 
                    'Impacto': 'Impacto', 'Tasa de perforación': 'Tasa_de_Perforación', 
                    'Perforación plana': 'Perforación_Plana', 'Recuperación de energía': 'Recuperación_energía' 
                }
                for csv_header, stat_key in mapeo.items(): 
                    self.base_stats[stat_key] = self._parse_valor(agente.get(csv_header, "0"))
                
                self.elemento = agente.get("elemento")
                self.tipo = agente.get("Tipo")
                self.gui.actualizar_campo_pen_res(self.elemento)

                self.cargar_habilidades_agente(nombre)
                if self.habilidades_agente: 
                    self.estado_actual.nombre_habilidad = list(self.habilidades_agente.keys())[0]
                
                self.actualizar_lista_wengines()
                arma_firma = None
                for w_nombre, w_datos in self.wengine_data.items():
                    if w_datos.get('agente') == nombre:
                        arma_firma = w_nombre
                        break
                
                if arma_firma:
                    self.gui.wengine_dropdown.value = arma_firma
                    self.cargar_wengine(arma_firma)

                config = CONFIG_CORE_UI.get(nombre, {})
                usa_stacks = config.get("usa_stacks", False)
                self.gui.core_stacks_dropdown.visible = usa_stacks
                
                if usa_stacks:
                    etiqueta = config.get("label", "Stacks")
                    max_s = config.get("max_stacks", 6)
                    val_def = config.get("default", max_s)
                    usar_slider = (max_s > 10) 
                    
                    self.gui.configurar_input_core(
                        visible=True,
                        usa_slider=usar_slider,
                        label=etiqueta,
                        max_val=max_s,
                        val_def=val_def
                    )
                    
                    self.estado_actual.core_stacks = int(val_def)
                else:
                    self.gui.configurar_input_core(visible=False)
                
                self.gui.core_stacks_dropdown.update()

        self.gui.actualizar_imagen_agente(nombre)
        self.generar_controles_pasivas(nombre)
        self.actualizar_ui_completa()

    def cambiar_mindscape(self, e):
        try:
            val = int(e.control.value)
            self.estado_actual.mindscape = val
            
            self.actualizar_visibilidad_stacks_agente()
            
            self.recalcular_stats_finales()
        except: pass

    def cambiar_mindscape_stacks(self, e):
        try:
            val = int(e.control.value)
            self.estado_actual.mindscape_stacks = val
            self.recalcular_stats_finales()
        except: pass

    def actualizar_visibilidad_stacks_agente(self):
        nombre = self.estado_actual.nombre_agente
        m_level = self.estado_actual.mindscape
        
        config = CONFIG_MINDSCAPES.get(nombre)
        mostrar_stacks = False
        max_s = 0
        
        if config:
            req = config.get("min_mindscape", 0)
            
            cumple_requisito = False
            if isinstance(req, list):
                cumple_requisito = m_level in req 
            else:
                cumple_requisito = m_level >= req 

            if cumple_requisito:
                mostrar_stacks = True
                self.gui.mindscape_stacks_dropdown.label = config.get("nombre_stack", "Stacks")

                config_max = config.get("max_stacks", 1)
                
                if isinstance(config_max, dict):
                    limit_found = 0
                    for nivel_req, limite in sorted(config_max.items()):
                        if m_level >= nivel_req:
                            limit_found = limite
                    max_s = limit_found
                else:
                    max_s = int(config_max)

                self.gui.mindscape_stacks_dropdown.options = [
                    ft.dropdown.Option(str(i)) for i in range(max_s + 1)
                ]
                
                val_actual = int(self.gui.mindscape_stacks_dropdown.value or "0")
                if val_actual > max_s:
                    self.gui.mindscape_stacks_dropdown.value = "0"
                    self.estado_actual.mindscape_stacks = 0

        self.gui.mindscape_stacks_dropdown.visible = mostrar_stacks
        self.gui.mindscape_stacks_dropdown.update()

    def cargar_enemigo(self, nombre):
        enemigo = next((e for e in self.enemigos_data if e.get('Nombre') == nombre), None)
        if nombre == "Ninguno":
            self.base_enemigo.clear()
            self.gui.actualizar_imagen_enemigo("Ninguno")
            keys_enemigo = [
                'Defensa_Base', 'Resistencia_porcentual', 'Defensa_Plana', 
                'Resistencia_Fuego', 'Resistencia_Electrico', 'Resistencia_Hielo', 
                'Resistencia_Físico', 'Resistencia_Etereo'
            ]
            for key in keys_enemigo:
                self.base_enemigo[key] = 0.0
                if key in self.gui.entry_vars:
                    self.gui.entry_vars[key].value = "0"
            self.page.update()
            return

        enemigo = next((e for e in self.enemigos_data if e.get('Nombre') == nombre), None)

        mapeo_enemigo = { 'Defensa_Base': 'Defensa base del enemigo', 'Resistencia_porcentual': 'Resistencia porcentual',
                        'Defensa_Plana': 'Defensa plana del enemigo', 'Resistencia_Fuego': 'Resistencia fuego',
                        'Resistencia_Electrico': 'Resistencia electrico', 'Resistencia_Hielo': 'Resistencia hielo',
                        'Resistencia_Físico': 'Resistencia físico', 'Resistencia_Etereo': 'Resistencia etereo' }
        for key_ui, key_csv in mapeo_enemigo.items():
            valor_base = self._parse_valor(enemigo.get(key_csv, '0'))
            self.base_enemigo[key_ui] = valor_base
            
            if key_ui in self.gui.entry_vars: 
                self.gui.entry_vars[key_ui].value = str(valor_base)

        self.gui.actualizar_imagen_enemigo(nombre)
        self.recalcular_stats_finales()
        self.page.update()

    def cargar_wengine(self, nombre):
        self.estado_actual.nombre_wengine = nombre
        self.gui.actualizar_imagen_wengine(nombre)
        self.estado_actual.refinamiento = 1
        self.gui.refinamiento_dropdown.value = "1"
        self.gui.refinamiento_dropdown.update()

        datos_arma = self.wengine_data.get(nombre)
        if datos_arma:

            descripcion = datos_arma.get('pasiva')
            
            self.gui.img_wengine.tooltip = descripcion
            self.gui.img_wengine.update()
        else:
            self.gui.img_wengine.tooltip = "Selecciona un W-Engine"
            self.gui.img_wengine.update()

        nombre_limpio = nombre.strip()
        if nombre_limpio in CONFIG_WENGINES:
            config = CONFIG_WENGINES[nombre]
            max_stacks = config["max_stacks"]
            label = config.get("nombre_stack", "Stacks")
            
            self.gui.stacks_dropdown.label = label
            self.gui.stacks_dropdown.options = [ft.dropdown.Option(str(i)) for i in range(0, max_stacks + 1)]
            
            self.gui.stacks_dropdown.value = "1"
            self.estado_actual.stacks = 1       
            self.gui.stacks_dropdown.visible = True

            self.gui.stacks_dropdown.update()
        else:
            self.estado_actual.stacks = 0
            self.gui.stacks_dropdown.visible = False
            self.gui.stacks_dropdown.update()
        self.page.update()
        self.recalcular_stats_finales()

    def cambiar_stacks(self, e):
        try:
            val = int(e.control.value)
            self.estado_actual.stacks = val 
            self.recalcular_stats_finales()
        except Exception as ex:
            import traceback
            traceback.print_exc()
            self.mostrar_mensaje(f"Error en stacks: {ex}")

    def cambiar_set_condicion(self, e):
        self.estado_actual.set_condicion = e.control.value
        
        self.recalcular_stats_finales()

    def cambiar_set_stacks(self, e):
        try:
            val = int(e.control.value)
            self.estado_actual.set_stacks = val
            self.recalcular_stats_finales()
        except:
            pass
        
    def aplicar_set(self, nombre, slot):
        
        if nombre != "Ninguno":
            sets_actuales = self.estado_actual.sets
            
            for otro_slot, otro_nombre in sets_actuales.items():
                if otro_slot != slot and otro_nombre == nombre:
                    
                    self.mostrar_mensaje(f"El set '{nombre}' ya está equipado en otro slot.")
                    
                    if slot == 'set1': self.gui.set1_dropdown.value = "Ninguno"
                    elif slot == 'set2': self.gui.set2_dropdown.value = "Ninguno"
                    elif slot == 'set3': self.gui.set3_dropdown.value = "Ninguno"
                    
                    self.page.update()
                    return 
        
        self.estado_actual.sets[slot] = nombre
        nombre_set1 = self.estado_actual.sets.get('set1', "").strip()
        
        self.gui.set_checkbox.visible = False
        self.gui.set_checkbox.value = False
        self.estado_actual.set_condicion = False
        
        self.gui.set_stacks_dropdown.visible = False
        self.estado_actual.set_stacks = 0

        if nombre_set1 in CONFIG_SETS:
            config = CONFIG_SETS[nombre_set1]
            
            if config.get("usa_condicion", False):
                self.gui.set_checkbox.label = config.get("texto_condicion", "¿Activo?")
                self.gui.set_checkbox.visible = True
                self.gui.set_checkbox.value = False 
                self.gui.set_checkbox.update()

            max_stacks = config.get("max_stacks", 0)
            if max_stacks > 0:
                self.gui.set_stacks_dropdown.label = config.get("nombre_stack", "Stacks")
                self.gui.set_stacks_dropdown.options = [ft.dropdown.Option(str(i)) for i in range(1, max_stacks + 1)]
                
                self.gui.set_stacks_dropdown.visible = True
                self.gui.set_stacks_dropdown.value = "1"
                self.estado_actual.set_stacks = 1
                self.gui.set_stacks_dropdown.update()
        
        self.gui.set_checkbox.update()
        self.gui.set_stacks_dropdown.update()

        self.recalcular_stats_finales()

    def aplicar_disco(self, nombre, slot):
        self.estado_actual.discos[slot] = nombre
        self.recalcular_stats_finales()
        
    def manejador_habilidad(self, e):
        self.estado_actual.nombre_habilidad = e.control.value
        self.actualizar_habilidad_ui()
        self.recalcular_stats_finales()

    def manejar_edicion_stat(self, e):
        stat_key = e.control.data
        try:
            valor_usuario = float(e.control.value)
            self.estado_actual.bonos_manuales_planos[stat_key] = 0
            self.recalcular_stats_finales()
            valor_calculado = float(self.gui.entry_vars[stat_key].value)
            self.estado_actual.bonos_manuales_planos[stat_key] = valor_usuario - valor_calculado
        except (ValueError, TypeError):
            self.estado_actual.bonos_manuales_planos.pop(stat_key, None)
        self.recalcular_stats_finales()

    def manejar_edicion_stat(self, e):
        stat_key = e.control.data
        try:
            valor_usuario = float(e.control.value)

            keys_enemigo = [
                'Defensa_Base', 'Resistencia_porcentual', 'Defensa_Plana', 
                'Resistencia_Fuego', 'Resistencia_Electrico', 'Resistencia_Hielo', 
                'Resistencia_Físico', 'Resistencia_Etereo'
            ]
            
            if stat_key in keys_enemigo:
                self.base_enemigo[stat_key] = valor_usuario
            else:
                self.estado_actual.bonos_manuales_planos[stat_key] = 0
                self.recalcular_stats_finales()
                valor_calculado = float(self.gui.entry_vars[stat_key].value)
                self.estado_actual.bonos_manuales_planos[stat_key] = valor_usuario - valor_calculado
            
        except (ValueError, TypeError):
            pass
        
        self.recalcular_stats_finales()

    def recalcular_stats_finales(self):

        keys_enemigo_ignorar = [
            'Defensa_Base', 'Resistencia_porcentual', 'Defensa_Plana', 
            'Resistencia_Fuego', 'Resistencia_Electrico', 'Resistencia_Hielo', 
            'Resistencia_Físico', 'Resistencia_Etereo', 'Reduccion_DEF_enemigo'
        ]
        
        if not self.base_stats:
            for key in self.gui.entry_vars:
                if key not in keys_enemigo_ignorar and key not in ["Multiplicador_de_ataques", "Aturdimiento"]:
                    self.gui.entry_vars[key].value = "0"
            self.page.update()
            return
        
        stats_para_calculo = self.base_stats.copy()
        lista_sets_externos = []
        buffs_acumulados_mindscapes = {}
        msgs_sup1 = [] 
        msgs_sup2 = []

        for prefijo in ["sup1", "sup2"]:
            nombre_set = self.gui.team_controls.get(f"{prefijo}_set4", ft.Dropdown()).value
            nombre_agente = self.gui.team_controls.get(f"{prefijo}_agente", ft.Dropdown()).value
            nombre_arma = self.gui.team_controls.get(f"{prefijo}_wengine", ft.Dropdown()).value

            try:ref_arma = int(self.gui.team_controls.get(f"{prefijo}_wengine_ref", ft.Dropdown()).value)
            except:ref_arma = 1
            try:stacks_arma = int(self.gui.team_controls.get(f"{prefijo}_wengine_stacks", ft.Dropdown()).value)
            except:stacks_arma = 0
            try: val_m = int(self.gui.team_controls.get(f"{prefijo}_mindscape", ft.Dropdown()).value)
            except: val_m = 0
            try: val_m_stacks = int(self.gui.team_controls.get(f"{prefijo}_mindscape_stacks", ft.Dropdown()).value)
            except: val_m_stacks = 0
            try: val_m_cond = self.gui.team_controls.get(f"{prefijo}_mindscape_cond", ft.Checkbox()).value
            except: val_m_cond = False

            if nombre_agente and nombre_agente != "Ninguno":
                datos_agente = next((a for a in self.agentes_data if a['Nombre'] == nombre_agente), None)
                tipo_agente_sup = datos_agente.get("Tipo", "") if datos_agente else ""
                elem_agente_sup = datos_agente.get("Elemento", "") or datos_agente.get("elemento", "") if datos_agente else ""
                facc_agente_sup = datos_agente.get("Faccion", "") or datos_agente.get("Facción", "") if datos_agente else ""

                stats_soporte = {
                    "Ataque": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_atk").value),
                    "Puntos_de_Vida": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_hp").value),
                    "Probabilidad_de_crítico": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_crit_rate").value),
                    "Daño_crítico": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_crit_dmg").value),
                    "Tasa_de_Perforación": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_pen").value),
                    "Tasa_de_Anomalía": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_am").value),
                    "Recuperación_energía": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_er").value),
                    "Impacto": self._parse_valor(self.gui.team_controls.get(f"{prefijo}_stat_imp").value)
                }

                lista_sets_externos.append({
                    "origen": prefijo,
                    "nombre_set": nombre_set,
                    "nombre_agente": nombre_agente,
                    "tipo_agente": tipo_agente_sup,
                    "elemento_agente": elem_agente_sup,
                    "faccion_agente": facc_agente_sup,
                    "nombre_arma": nombre_arma,
                    "refinamiento_arma": ref_arma,
                    "stacks_arma": stacks_arma,
                    "stats": stats_soporte
                })

                if nombre_agente in MAPA_MINDSCAPES:
                    funcion_mindscape = MAPA_MINDSCAPES[nombre_agente]
                    bonos_soporte = funcion_mindscape(mindscape=val_m, stacks=val_m_stacks, condicion_activa=val_m_cond)
                    
                    if bonos_soporte:
                        desc_bonos = ", ".join([f"{k}: +{v}" for k, v in bonos_soporte.items()])
                        mensaje = f"{nombre_agente} (M{val_m}): {desc_bonos}"
                        
                        if prefijo == "sup1":
                            msgs_sup1.append(mensaje)
                        else:
                            msgs_sup2.append(mensaje)

                        for stat_key, valor in bonos_soporte.items():
                            buffs_acumulados_mindscapes[stat_key] = buffs_acumulados_mindscapes.get(stat_key, 0.0) + valor

        if hasattr(self.gui, 'lbl_resumen_buffs'):

            for info in lista_sets_externos:
                n_agente_raw = info['nombre_agente']
                n_set_raw = info['nombre_set']
                t_agente_raw = info['tipo_agente']
                stats_del_soporte = info.get('stats', {}) 

                n_agente_norm = self.gestor_stats._normalizar(n_agente_raw)
                n_set_norm = self.gestor_stats._normalizar(n_set_raw)
                
                origen = info.get("origen", "sup1")
                lista_destino = msgs_sup1 if origen == "sup1" else msgs_sup2

                dummy_res = {}

                for key_agente, funcion in MAPA_SOPORTES_AGENTES.items():
                    if key_agente in n_agente_norm:
                        datos_equipo_ui = {
                            "roles": [str(self.tipo).lower()] if self.tipo else [],
                            "elementos": [str(self.elemento).lower()] if self.elemento else [],
                            "nombres": [str(self.estado_actual.nombre_agente).lower()]
                        }
                        texto = funcion(
                            dummy_res, 
                            tipo_agente=t_agente_raw, 
                            stats=stats_del_soporte,
                            datos_equipo=datos_equipo_ui
                        )
                        if texto: lista_destino.append(texto)
                        break

                for key_set, funcion in MAPA_SOPORTES_SETS.items():
                    if key_set in n_set_norm:
                        texto = funcion(dummy_res, tipo_agente=t_agente_raw, stats=stats_del_soporte)
                        if texto: lista_destino.append(texto)
                        break
                
                raw_arma = info.get('nombre_arma', '')
                n_arma_norm = self.gestor_stats._normalizar(raw_arma)
                for key_w, funcion in MAPA_SOPORTES_WENGINES.items():
                    if key_w in n_arma_norm:
                        texto = funcion(
                            dummy_res, 
                            refinamiento=info.get('refinamiento_arma', 1),
                            stacks=info.get('stacks_arma', 0)
                        )
                        if texto: lista_destino.append(texto)
                        break

                for k, v in dummy_res.items():
                    stats_para_calculo[k] = stats_para_calculo.get(k, 0.0) + v


            if hasattr(self.gui, 'lbl_resumen_buffs'):
                self.gui.lbl_resumen_buffs.value = ""
                self.gui.lbl_resumen_buffs.spans = [] 
                
                lista_spans = []

                if msgs_sup1:
                    lista_spans.append(ft.TextSpan(
                        "SOPORTE 1:\n", 
                        style=ft.TextStyle(weight=ft.FontWeight.BOLD, color=ft.Colors.CYAN_300)
                    ))
                    lista_spans.append(ft.TextSpan(
                        " | ".join(msgs_sup1), 
                        style=ft.TextStyle(color=ft.Colors.CYAN_100)
                    ))

                if msgs_sup1 and msgs_sup2:
                    lista_spans.append(ft.TextSpan("\n\n"))

                if msgs_sup2:
                    # Título
                    lista_spans.append(ft.TextSpan(
                        "SOPORTE 2:\n", 
                        style=ft.TextStyle(weight=ft.FontWeight.BOLD, color=ft.Colors.GREEN_300)
                    ))
                    lista_spans.append(ft.TextSpan(
                        " | ".join(msgs_sup2), 
                        style=ft.TextStyle(color=ft.Colors.GREEN_100)
                    ))

                if lista_spans:
                    self.gui.lbl_resumen_buffs.spans = lista_spans
                else:
                    self.gui.lbl_resumen_buffs.value = "• Sin buffs de equipo activos."
                    self.gui.lbl_resumen_buffs.color = ft.Colors.GREEN_300
                
                self.gui.lbl_resumen_buffs.update()

        estado_actual_enemigo = "Normal"
        if hasattr(self.gui, 'dd_estado_enemigo') and self.gui.dd_estado_enemigo.value:
            estado_actual_enemigo = self.gui.dd_estado_enemigo.value

        stats_para_calculo = self.base_stats.copy()

        if self.estado_actual.nombre_habilidad in self.habilidades_agente:
            info_habilidad = self.habilidades_agente[self.estado_actual.nombre_habilidad]
            stats_para_calculo['Aturdimiento'] = float(info_habilidad.get('Aturdimiento', 0.0))
            stats_para_calculo['Multiplicador_de_ataques'] = float(info_habilidad.get('Multiplicador', 0.0))

        for k, v in buffs_acumulados_mindscapes.items():
            stats_para_calculo[k] = stats_para_calculo.get(k, 0.0) + v

        stacks_core_ui = int(self.gui.core_stacks_dropdown.value or 0)
        kwargs_pasivas = {}

        if hasattr(self.gui, 'controles_pasivas'):
            for key, control in self.gui.controles_pasivas.items():
                kwargs_pasivas[key] = control.value

        stats_calculadas = self.gestor_stats.calcular_stats_finales(
            base_stats=stats_para_calculo, 
            estado_build=self.estado_actual,
            wengine_db=self.wengine_data,
            sets_db=self.sets_data,
            discos_db=self.discos_data,
            substats_db=self.substats_db,
            elemento_agente=self.elemento,
            tipo_agente=self.tipo,
            stacks_core=stacks_core_ui,
            sets_externos=lista_sets_externos,
            estado_enemigo=estado_actual_enemigo,
            **kwargs_pasivas
        )

        self.ultimos_stats_calculados = stats_calculadas.copy()

        for stat_key, campo_ui in self.gui.entry_vars.items():
            if stat_key in keys_enemigo_ignorar:
                continue
            
            valor_final = stats_calculadas.get(stat_key, 0.0)
            
            es_decimal = False
            label_lower = campo_ui.label.lower()
            if any(x in label_lower for x in ["%", "daño elem", "pen res", "aturdimiento", "rec."]):
                es_decimal = True
            
            campo_ui.value = f"{valor_final:.2f}" if es_decimal else f"{valor_final:.0f}"

        keys_enemigo_visual = [
            'Resistencia_Fuego', 'Resistencia_Electrico', 'Resistencia_Hielo', 
            'Resistencia_Físico', 'Resistencia_Etereo', 'Resistencia_porcentual',
            'Defensa_Base', 'Reduccion_DEF_enemigo' 
        ]

        for key in keys_enemigo_visual:
            if key in self.gui.entry_vars:

                base = self.base_enemigo.get(key, 0.0)
                cambio = stats_calculadas.get(key, 0.0)
                
                if key == 'Reduccion_DEF_enemigo':
                    valor_visual = cambio
                else:
                    valor_visual = base + cambio

                if key == 'Defensa_Base':
                     self.gui.entry_vars[key].value = f"{valor_visual:.0f}"
                else:
                     self.gui.entry_vars[key].value = f"{valor_visual:.2f}"
                
                es_debuff = (cambio != 0 and key != 'Defensa_Base') or (key == 'Reduccion_DEF_enemigo' and cambio > 0)
                if es_debuff:
                     self.gui.entry_vars[key].text_color = ft.Colors.RED_300
                else:
                     self.gui.entry_vars[key].text_color = ft.Colors.WHITE

        self.page.update()

    def cambiar_refinamiento(self, e):
        try:
            val = int(e.control.value)
            self.estado_actual.refinamiento = val
            logger.info(f"Refinamiento cambiado a R{val}")
            self.recalcular_stats_finales()
        except Exception as ex:
            logger.error(f"Error cambiando refinamiento: {ex}")

    def reiniciar_stats(self, e=None):
        self.estado_actual.reiniciar()
        self.base_stats.clear()
        if hasattr(self.gui, 'substat_counters'):
            for counter in self.gui.substat_counters.values():
                counter.value = "0"
        if self.gui.refinamiento_dropdown:
            self.gui.refinamiento_dropdown.value = "1"
            self.gui.refinamiento_dropdown.update()   
        self.gui.actualizar_imagen_agente("Ninguno")
        self.gui.actualizar_imagen_team("sup1", "agente", "Ninguno")
        self.gui.actualizar_imagen_team("sup1", "wengine", "Ninguno")
        self.gui.actualizar_imagen_team("sup2", "agente", "Ninguno")
        self.gui.actualizar_imagen_team("sup2", "wengine", "Ninguno")
        self.gui.team_controls["sup1_agente"].value = "Ninguno"
        self.gui.team_controls["sup2_agente"].value = "Ninguno"
        self.gui.actualizar_imagen_wengine("Ninguno")
        self.actualizar_ui_completa()
        self.mostrar_mensaje("Build reiniciada.")

    def cambiar_core_stacks(self, e):
        try:
            val = float(e.control.value)
            self.estado_actual.core_stacks = int(val)
            self.recalcular_stats_finales()
        except:
            pass

    def generar_controles_pasivas(self, nombre_agente):
        """Genera checkboxes dinámicos basados en CONFIG_PASIVAS_UI"""
        
        
        self.gui.contenedor_pasivas_ui.controls.clear()
        self.gui.controles_pasivas.clear()
        
        if nombre_agente in CONFIG_PASIVAS_UI:
            configs = CONFIG_PASIVAS_UI[nombre_agente]
            
            for conf in configs:
                if conf["tipo"] == "checkbox":
                    chk = ft.Checkbox(
                        label=conf["label"],
                        value=conf["default"],
                        on_change=lambda e: self.recalcular_stats_finales()
                    )
                    self.gui.contenedor_pasivas_ui.controls.append(chk)
                    self.gui.controles_pasivas[conf["key"]] = chk
            
            self.gui.contenedor_pasivas_ui.update()
        else:
            self.gui.contenedor_pasivas_ui.update()

    def activar_tres_leches(self, e=None):
        self.tres_leches = not self.tres_leches
        self.gui.set3_dropdown.visible = self.tres_leches
        self.gui.btn_tres_leches.text = "Desactivar Tres Leches" if self.tres_leches else "Activar Tres Leches"
        if not self.tres_leches:
            self.aplicar_set("Ninguno", 'set3')
            self.gui.set3_dropdown.value = "Ninguno"
        self.page.update()

    def actualizar_ui_completa(self):
        self.gui.agent_dropdown.value, self.gui.wengine_dropdown.value = self.estado_actual.nombre_agente, self.estado_actual.nombre_wengine
        self.gui.set1_dropdown.value, self.gui.set2_dropdown.value, self.gui.set3_dropdown.value = self.estado_actual.sets['set1'], self.estado_actual.sets['set2'], self.estado_actual.sets['set3']
        for slot, nombre in self.estado_actual.discos.items():
            if slot in self.gui.disco_dropdowns: self.gui.disco_dropdowns[slot].value = nombre
        self.actualizar_habilidad_ui()
        self.recalcular_stats_finales()

    def actualizar_habilidad_ui(self):
        self.gui.habilidad_dropdown.options = [ft.dropdown.Option(h) for h in self.habilidades_agente.keys()]
        self.gui.habilidad_dropdown.value = self.estado_actual.nombre_habilidad
        habilidad = self.habilidades_agente.get(self.estado_actual.nombre_habilidad, {})
        self.gui.entry_vars["Multiplicador_de_ataques"].value = str(habilidad.get("Multiplicador", 0))
        self.gui.entry_vars["Aturdimiento"].value = str(habilidad.get("Aturdimiento", 0))
        self.page.update()

    def actualizar_lista_wengines(self):
        """
        Filtra la lista de W-Engines según el tipo del agente actual (Atacante, Aturdidor...)
        si el checkbox 'Solo Compatibles' está activo.
        """
        filtrar = self.gui.chk_filtro_wengine.value
        tipo_agente = self.tipo
        
        todas_armas = list(self.wengine_data.keys())
        armas_filtradas = []

        if filtrar and tipo_agente:
            tipo_agente_norm = self.gestor_stats._normalizar(tipo_agente)
            
            for nombre_arma in todas_armas:
                datos = self.wengine_data.get(nombre_arma, {})
                
                tipo_arma = datos.get('tipow', '')
                tipo_arma_norm = self.gestor_stats._normalizar(tipo_arma)

                if tipo_arma_norm == tipo_agente_norm:
                    armas_filtradas.append(nombre_arma)

            if not armas_filtradas:
                armas_filtradas = todas_armas
        else:
            armas_filtradas = todas_armas

        armas_filtradas.sort()

        seleccion_actual = self.gui.wengine_dropdown.value

        self.gui.wengine_dropdown.options = [ft.dropdown.Option("Ninguno")] + [ft.dropdown.Option(w) for w in armas_filtradas]
        if seleccion_actual in armas_filtradas:
            self.gui.wengine_dropdown.value = seleccion_actual
        else:
            self.gui.wengine_dropdown.value = "Ninguno"
            if seleccion_actual != "Ninguno":
                self.cargar_wengine("Ninguno")

        self.gui.wengine_dropdown.update()

    def cambiar_filtro_wengines(self, e):
        """ Evento del Checkbox """
        self.actualizar_lista_wengines()
        
    def cargar_habilidades_agente(self, nombre_agente):
        self.habilidades_agente.clear()
        file_path = os.path.join(self.datos_dir, 'agentes', f"{nombre_agente}.csv")
        if not os.path.exists(file_path): return
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f, delimiter=';')
                for row in reader:
                    self.habilidades_agente[row['Habilidad']] = { 'Multiplicador': self._parse_valor(row.get('Multiplicador')), 'Aturdimiento': self._parse_valor(row.get('Aturdimiento')) }
        except Exception as e:
            logger.error(f"Error al leer archivo de habilidad para {nombre_agente}: {e}")
    
    def calcular_dano(self, e):
        params = getattr(self, 'ultimos_stats_calculados', {}).copy()

        for key, field in self.gui.entry_vars.items():
            params[key] = self._parse_valor(field.value)

        for key, field in self.gui.buff_vars.items(): 
            params[key] = self._parse_valor(field.value)

        if hasattr(self.gui, 'dd_estado_enemigo'):
             params['Estado_Enemigo'] = self.gui.dd_estado_enemigo.value
        
        if not self.elemento:
            self.mostrar_mensaje("Selecciona un agente primero.")
            return

        enemigo_seleccionado = self.gui.enemy_dropdown.value
        if not enemigo_seleccionado or enemigo_seleccionado == "Ninguno":
            self.mostrar_mensaje("¡¡Debes seleccionar un enemigo para calcular!!")
            return

        try:
            nombre_agente = self.estado_actual.nombre_agente
            tipo_agente = ""
            if isinstance(self.agentes_data, list):
                for agente in self.agentes_data:
                    if agente.get("Nombre") == nombre_agente:
                        tipo_agente = agente.get("Tipo", "")
                        break
            
            params['Tipo'] = tipo_agente
            params['Nombre_Agente'] = nombre_agente
            
            elemento_calculo = self.elemento.lower() if self.elemento else ""

            dmg, sheer, anomaly, disorder, stats_combate = self.logica_dmg.calcular_todos_danos(params, elemento_calculo)
            self.mostrar_resultados(dmg, sheer, anomaly, disorder, stats_combate)
            
        except Exception as ex:
            print(f"Error detallado: {ex}") 
            self.mostrar_mensaje(f"Error al calcular: {ex}")

    def mostrar_resultados(self, dmg, sheer, anomaly, disorder, stats):
        self.gui.resultado_normal.value = f"Daño Normal: {dmg:,.2f}"
        self.gui.resultado_sheer.value = f"Daño Sheer: {sheer:,.2f}"
        self.gui.resultado_anomaly.value = f"Daño Anomalía: {anomaly:,.2f}"
        self.gui.resultado_disorder.value = f"Daño Disorder: {disorder:,.2f}"
        detalles = f"Elemento: {self.elemento.capitalize()}\n" + "-"*33 + "\n"
        detalles += "Estadísticas Finales en Combate:\n"
        for stat, valor in stats.items():
            if isinstance(valor, (float, int)):
                detalles += f"- {stat}: {valor:,.2f}\n"
            else:
                detalles += f"- {stat}: {valor}\n"
        self.gui.resultados_text.value = detalles
        self.page.update()

    def mostrar_mensaje(self, texto):
        if self.page:
            self.page.snack_bar = ft.SnackBar(ft.Text(texto), duration=2000)
            self.page.snack_bar.open = True
            self.page.update()
    
    def guardar_config(self, e):
        nombre_config = self.gui.config_name_field.value.strip()
        
        if not nombre_config:
            self.mostrar_mensaje("Escribe un nombre para la configuración.")
            return

        datos_guardar = {
            "agente": self.estado_actual.nombre_agente,
            "wengine": self.estado_actual.nombre_wengine,
            "refinamiento": self.estado_actual.refinamiento,
            "stacks_arma": self.estado_actual.stacks,
            "habilidad": self.estado_actual.nombre_habilidad,
            "sets": self.estado_actual.sets,
            "set_stacks": self.estado_actual.set_stacks,
            "set_condicion": self.estado_actual.set_condicion,       
            "discos": self.estado_actual.discos, 
            "substats_counts": self.estado_actual.substats_counts,        
            "stats_manuales": {k: v.value for k, v in self.gui.entry_vars.items()},
            "buffs_combate": {k: v.value for k, v in self.gui.buff_vars.items()}
        }

        ruta_carpeta = os.path.join(self.base_path, 'guardados')
        if not os.path.exists(ruta_carpeta):
            os.makedirs(ruta_carpeta)

        nombre_archivo = f"{nombre_config}.json"
        ruta_completa = os.path.join(ruta_carpeta, nombre_archivo)
        
        try:
            with open(ruta_completa, 'w', encoding='utf-8') as f:
                json.dump(datos_guardar, f, indent=4, ensure_ascii=False)
            
            self.mostrar_mensaje(f"Configuración '{nombre_config}' guardada con éxito.")
        
        except Exception as ex:
            logger.error(f"Error al guardar: {ex}")
            self.mostrar_mensaje(f"Error al guardar: {ex}")

    def actualizar_lista_archivos(self, e):
        """Refresca el dropdown de archivos en la pestaña Comparador"""
        try:
            ruta_guardados = os.path.join(self.base_path, 'guardados')
            opciones = []
            if os.path.exists(ruta_guardados):
                archivos = [f for f in os.listdir(ruta_guardados) if f.endswith('.json')]
                for arch in archivos:
                    nombre = arch.replace(".json", "")
                    opciones.append(ft.dropdown.Option(nombre))
            
            if hasattr(self.gui, 'archivo_dropdown'):
                self.gui.archivo_dropdown.options = opciones
                self.gui.archivo_dropdown.update()
                self.mostrar_mensaje("Lista de archivos actualizada.")
        except Exception as ex:
            logger.error(f"Error actualizando lista: {ex}")

    def cargar_config(self, e):
        nombre_archivo = self.gui.archivo_dropdown.value
        if not nombre_archivo:
            self.mostrar_mensaje("Selecciona un archivo primero.")
            return

        ruta_completa = os.path.join(self.base_path, 'guardados', f"{nombre_archivo}.json")
        if not os.path.exists(ruta_completa):
            self.mostrar_mensaje("El archivo ya no existe.")
            return

        try:
            with open(ruta_completa, 'r', encoding='utf-8') as f:
                datos = json.load(f)

            if isinstance(datos, list):
                if len(datos) > 0:
                    #self.logger.warning("El JSON es una lista. Cargando el primer elemento.")
                    datos = datos[0] 
                else:
                    #self.mostrar_mensaje("El archivo JSON es una lista vacía.")
                    return

            if "character" in datos or "discs" in datos:
                self.logger.info("Detectado formato externo. Iniciando traducción...")
                self._cargar_formato_externo(datos)
                self.mostrar_mensaje(f"Build externa '{nombre_archivo}' importada.")

            else:
                self.logger.info("Detectado formato interno estándar.")
                self._cargar_formato_interno(datos)
                self.mostrar_mensaje(f"Configuración '{nombre_archivo}' cargada.")

        except Exception as ex:
            if hasattr(self, 'logger'):
                self.logger.error(f"Error cargando: {ex}", exc_info=True)
            self.mostrar_mensaje(f"Error crítico al cargar: {ex}")

    def _cargar_formato_interno(self, datos):
        agente = datos.get("agente", "Ninguno")
        self.gui.agent_dropdown.value = agente
        self.cargar_agente(agente) 

        wengine = datos.get("wengine", "Ninguno")
        self.gui.wengine_dropdown.value = wengine
        self.cargar_wengine(wengine) 

        ref = str(datos.get("refinamiento", 1))
        stacks_arma = str(datos.get("stacks_arma", 0))
        
        self.gui.refinamiento_dropdown.value = ref
        self.estado_actual.refinamiento = int(ref)
        
        if self.gui.stacks_dropdown.visible:
            self.gui.stacks_dropdown.value = stacks_arma
            self.estado_actual.stacks = int(stacks_arma)

        habilidad = datos.get("habilidad")
        if habilidad:
            self.gui.habilidad_dropdown.value = habilidad
            self.estado_actual.nombre_habilidad = habilidad
            self.manejador_habilidad(type('obj', (object,), {'control': type('c', (object,), {'value': habilidad})}))

        sets_guardados = datos.get("sets", {})
        self.gui.set1_dropdown.value = sets_guardados.get("set1", "Ninguno")
        self.gui.set2_dropdown.value = sets_guardados.get("set2", "Ninguno")
        self.gui.set3_dropdown.value = sets_guardados.get("set3", "Ninguno")
        
        self.aplicar_set(sets_guardados.get("set1", "Ninguno"), 'set1')
        self.aplicar_set(sets_guardados.get("set2", "Ninguno"), 'set2')
        self.aplicar_set(sets_guardados.get("set3", "Ninguno"), 'set3')

        set_stacks = str(datos.get("set_stacks", 0))
        set_cond = datos.get("set_condicion", False)
        
        if self.gui.set_stacks_dropdown.visible:
            self.gui.set_stacks_dropdown.value = set_stacks
            self.estado_actual.set_stacks = int(set_stacks)
        
        if self.gui.set_checkbox.visible:
            self.gui.set_checkbox.value = set_cond
            self.estado_actual.set_condicion = set_cond

        discos_guardados = datos.get("discos", {})
        for slot, nombre in discos_guardados.items():
            slot_int = int(slot)
            if slot_int in self.gui.disco_dropdowns:
                self.gui.disco_dropdowns[slot_int].value = nombre
                self.estado_actual.discos[slot_int] = nombre

        for counter in self.gui.substat_counters.values():
            counter.value = "0"
        self.estado_actual.substats_counts.clear()
        
        substats_guardadas = datos.get("substats_counts", {})
        for key, val in substats_guardadas.items():
            self.estado_actual.substats_counts[key] = val
            if key in self.gui.substat_counters:
                self.gui.substat_counters[key].value = str(val)

        stats_manuales = datos.get("stats_manuales", {})
        for k, v in stats_manuales.items():
            if k in self.gui.entry_vars:
                self.gui.entry_vars[k].value = str(v)
                if k in self.base_stats:
                    try:
                        self.estado_actual.bonos_manuales_planos[k] = float(v) - float(self.base_stats[k])
                    except: pass

        buffs_guardados = datos.get("buffs_combate", {})
        for k, v in buffs_guardados.items():
            if k in self.gui.buff_vars:
                self.gui.buff_vars[k].value = str(v)

        self.actualizar_ui_completa()

    def _cargar_formato_externo(self, datos):
        self.logger.info("Iniciando importación inteligente desde JSON externo...")


        nombre_agente = datos.get("name")
        if not nombre_agente:
            nombre_agente = datos.get("character", {}).get("name", "Ninguno")

        self.gui.agent_dropdown.value = nombre_agente
        self.cargar_agente(nombre_agente)

        arma_data = datos.get("weapon", {})
        nombre_arma = arma_data.get("name", "Ninguno")
        self.gui.wengine_dropdown.value = nombre_arma

        self.cargar_wengine(nombre_arma)
        ref = 1
        self.gui.refinamiento_dropdown.value = str(ref)
        self.estado_actual.refinamiento = ref
        self.gui.refinamiento_dropdown.update()

        discos_json = datos.get("discs", [])
        conteo_sets = {}

        for disco in discos_json:
            nombre_set = "Desconocido"
            if "set_id" in disco:
                set_id = int(disco.get("set_id"))
                nombre_set = MAPA_SETS_ID.get(set_id, "Desconocido")
            
            if nombre_set == "Desconocido":
                brand = disco.get("brand")
                if brand:
                    nombre_set = MAPA_SETS_JSON.get(brand, brand)

            if nombre_set != "Desconocido":
                conteo_sets[nombre_set] = conteo_sets.get(nombre_set, 0) + 1

        set1, set2 = "Ninguno", "Ninguno"
        for nombre, cantidad in conteo_sets.items():
            if cantidad >= 4:
                set1 = nombre
            elif cantidad >= 2:
                if set2 == "Ninguno": set2 = nombre
        
        if set1 == "Ninguno" and set2 != "Ninguno":
            set1 = set2
            set2 = "Ninguno"

        self.gui.set1_dropdown.value = set1
        self.aplicar_set(set1, 'set1')
        self.gui.set2_dropdown.value = set2
        self.aplicar_set(set2, 'set2')

        for disco in discos_json:
            slot = str(disco.get("slot"))
            if slot in ["4", "5", "6"]:
                main_stat_data = disco.get("main_stat", {})
                nombre_ingles = main_stat_data.get("name")
                nombre_es = "Ninguno"
                for k, v in MAPA_STATS_JSON.items():
                    if k.lower() == str(nombre_ingles).lower():
                        nombre_es = v
                        break
                
                self.estado_actual.discos[int(slot)] = nombre_es
                if int(slot) in self.gui.disco_dropdowns:
                    self.gui.disco_dropdowns[int(slot)].value = nombre_es


        self.estado_actual.substats_counts = {k: 0 for k in self.substats_db_keys} if hasattr(self, 'substats_db_keys') else {}
        self.estado_actual.substats_counts = {}
        for item in self.substats_db:
            self.estado_actual.substats_counts[item['unique_key']] = 0

        for counter in self.gui.substat_counters.values():
            counter.value = "0"
        
        for disco in discos_json:
            substats = disco.get("sub_stats", [])
            for sub in substats:
                nombre_ingles = sub.get("name")
                valor_raw = str(sub.get("value", "0"))
                
                es_porcentual = "%" in valor_raw or "Percent" in str(nombre_ingles)
                sufijo = "porcentual" if es_porcentual else "plano"
                valor_limpio = valor_raw.replace("%", "").replace(",", "").strip()
                
                try:
                    valor_float = float(valor_limpio)
                except:
                    continue

                clave_base = None
                for k, v in MAPA_STATS_JSON.items():
                    if k.lower() == str(nombre_ingles).lower():
                        clave_base = v
                        break
                
                if clave_base:
                    stats_planas_forzadas = [
                        "Maestría_Anomalía", "Tasa_de_Anomalía", "Impacto", 
                        "Probabilidad_crítico", "Daño_crítico", "Recuperación_energía",
                        "Tasa_de_Perforación", "Perforación_Plana"
                    ]
                    
                    if clave_base in stats_planas_forzadas:

                        unique_key_candidate_pct = f"{clave_base}_porcentual"
                        unique_key_candidate_flat = f"{clave_base}_plano"

                        if es_porcentual:
                            unique_key = unique_key_candidate_pct
                        else:
                            unique_key = unique_key_candidate_flat
                            if clave_base == "Maestría_Anomalía": unique_key = "Maestría_Anomalía_plano"
                    else:
                        unique_key = f"{clave_base}_{sufijo}"

                    valor_unitario = 0
                    for item_db in self.substats_db:
                        if item_db['unique_key'] == unique_key:
                            valor_unitario = item_db['valor'] 
                            break
                    
                    if valor_unitario > 0:
                        rolls_calc = int(round(valor_float / valor_unitario))
                        
                        if rolls_calc > 0:
                            if unique_key not in self.estado_actual.substats_counts:
                                self.estado_actual.substats_counts[unique_key] = 0
                            
                            self.estado_actual.substats_counts[unique_key] += rolls_calc
                            print(f"   -> {nombre_ingles} ({valor_float}) = {rolls_calc} rolls de {unique_key}")
                    else:
                        print(f"   [WARN] No se encontró valor base en DB para {unique_key} (Origen: {nombre_ingles})")
                else:
                    print(f"   [WARN] No se encontró traducción para stat: {nombre_ingles}")

        for key, val in self.estado_actual.substats_counts.items():
            if key in self.gui.substat_counters:
                self.gui.substat_counters[key].value = str(val)

        try:
            m_count = int(datos.get("mindscape", 0))
            if m_count < 0: m_count = 0
            if m_count > 6: m_count = 6
            self.estado_actual.mindscape = m_count
            self.gui.mindscape_dropdown.value = str(m_count)
            self.gui.mindscape_dropdown.update()
            self.actualizar_visibilidad_stacks_agente()
        except Exception as e:
            self.logger.error(f"Error cargando mindscapes: {e}")

        self.actualizar_ui_completa()
        self.mostrar_mensaje(f"Build importada. Revisa la consola para detalles de rolls.")

    def comparar_configs(self, e): self.mostrar_mensaje("Función no implementada.")
    def generar_recomendaciones(self, e): self.mostrar_mensaje("Función no implementada.")
    def graficar_variable(self, e): self.mostrar_mensaje("Función no implementada.")

MAPA_STATS_JSON ={
    "HP": "Puntos_Vida","ATK": "Ataque","DEF": "Defensa",
    "CRIT Rate": "Probabilidad_crítico","CRIT DMG": "Daño_crítico","PEN Ratio": "Tasa_de_Perforación",
    "PEN": "Perforación_Plana","Anomaly Proficiency": "Maestría_Anomalía","Physical DMG Bonus": "Daño_elemental",
    "Fire DMG Bonus": "Daño_elemental","Ice DMG Bonus": "Daño_elemental","Electric DMG Bonus": "Daño_elemental",
    "Ether DMG Bonus": "Daño_elemental","Anomaly Mastery": "Tasa_de_Anomalía","Impact": "Impacto",
    "Energy Regen": "Recuperación_energía","Percent ATK": "Ataque","Percent HP": "Puntos_Vida","Percent DEF": "Defensa",
    "Sheer Force": "Sheer_force",
}

MAPA_SETS_JSON ={
    "Chaos Jazz": "Jazz caótico","Fanged Metal": "Metal colmilludo",
    "Thunder Metal": "Metal eléctrico","Chaotic Metal": "Metal caótico",
    "Inferno Metal": "Metal infernal","Polar Metal": "Metal Polar",
    "Branch & Blade Song": "Balada de la rama y la espada","Yunkui Tales": "Fábula Yunkui",
    "Hormone Punk": "Punk Hormonal","Woodpecker Electro": "Tecno Pícido","Astral Voice": "Voz Astral",
    "Swing jazz": "Jazz Oscilante","Shadow Harmony": "Armonía Umbría","Puffer Electro": "Tecno Tetraodóntido",
    "Dawn's Bloom": "Floración del alba","King of summit": "Monarca del Pináculo","Moonlight Lullaby": "Nana a la Luz Cenicienta",
    "Phaethon's Melody": "Melodía de Phaeton","Proto Punk": "Proto Punk","Shockstar Disco": "Disco sacudestrellas",
    "Shining Aria": "Aria Radiante","White Water Ballad": "Balada de Aguas Blancas","Freedom Blues": "Blues Libre"
}

MAPA_SETS_ID = {
    31800: "Jazz caótico",32600: "Metal colmilludo",32400: "Metal eléctrico",
    32300: "Metal caótico",32200: "Metal infernal",32500: "Metal Polar",32700: "Balada de la rama y la espada",
    33100: "Fábula Yunkui",31400: "Punk Hormonal",31000: "Tecno Pícido",32800: "Voz Astral",
    31600: "Jazz Oscilante",32900: "Armonía Umbría",31100: "Tecno Tetraodóntido",
    33300: "Floración del alba",33200: "Monarca del Pináculo",33400: "Nana a la Luz Cenicienta",
    33000: "Melodía de Phaeton",31900: "Proto Punk",31200: "Disco sacudestrellas",
    33600: "Aria Radiante",33500: "Balada de Aguas Blancas",31300: "Blues Libre"
}

def main(page: ft.Page):
    page.window.width, page.window.height = 1490, 980
    page.title = "Calculadora Zenless Zone Zero"
    
    page.theme_mode = ft.ThemeMode.SYSTEM
    
    page.theme = ft.Theme(
        color_scheme=ft.ColorScheme(
            primary=ft.Colors.CYAN_300,        
            on_primary=ft.Colors.BLACK12,
            secondary=ft.Colors.GREEN_300,
            on_secondary=ft.Colors.BLACK12,
            background=ft.Colors.GREY_900,
            surface=ft.Colors.GREY_900,
            error=ft.Colors.RED_ACCENT_400,
        ),
        card_theme=ft.CardTheme(
            color=ft.Colors.BLACK12,
            elevation=5
        ),
    )
    
    page.padding = 15
    CalculadoraZZZ(page)

if __name__ == "__main__":
    ft.app(target=main)