import pandas as pd
import os
import logging

class CargadorDatos:
    
    def __init__(self, base_path):
        self.base_path = base_path

    def cargar_csv(self, nombre_archivo, campos_numericos=None):
        """
        Carga un archivo CSV y lo convierte en una lista de diccionarios.
        CORRECCIÓN: Limpia los espacios de las cabeceras para evitar errores.
        """
        ruta_archivo = os.path.join(self.base_path, nombre_archivo)
        if not os.path.exists(ruta_archivo):
            return []
        try:
            df = pd.read_csv(ruta_archivo, delimiter=';', encoding='utf-8-sig', dtype=str)
            df = df.fillna('')
            
            df = df.rename(columns=lambda x: x.strip())
            
            if campos_numericos:
                for campo in campos_numericos:
                    if campo in df.columns:
                        df[campo] = pd.to_numeric(
                            df[campo].astype(str).str.replace(',', '.'), 
                            errors='coerce'
                        ).fillna(0)
            
            return df.to_dict('records')
        except Exception as e:
            return []

    def cargar_wengine(self, nombre_archivo, campos_numericos=None):
        """
        Carga los datos de W-Engine, usando el nombre como clave del diccionario.
        """
        ruta_archivo = os.path.join(self.base_path, nombre_archivo)
        if not os.path.exists(ruta_archivo):
            return {}
        try:
            df = pd.read_csv(ruta_archivo, delimiter=';', encoding='utf-8-sig', dtype=str)
            df = df.fillna('')
            df = df.rename(columns=lambda x: x.strip()) 
            
            if 'Nombre W-Engine' not in df.columns:
                return {}

            df.set_index('Nombre W-Engine', inplace=True)
            
            if campos_numericos:
                for campo in campos_numericos:
                    if campo in df.columns:
                        df[campo] = pd.to_numeric(
                            df[campo].astype(str).str.replace(',', '.'), 
                            errors='coerce'
                        ).fillna(0)

            return df.to_dict('index')
        except Exception as e:
            return {}
    