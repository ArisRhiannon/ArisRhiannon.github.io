CONFIG_CORE_UI = {
    "Harumasa": {"usa_stacks": True, "max_stacks": 6,
        "default": 6, "label": "Stacks"},
    "Hugo": {"usa_stacks": True,"max_stacks": 15,
        "default": 15,"label": "Segundos"},
    "Piper": {"usa_stacks": True,"max_stacks": 20,
        "default": 20,"label": "Stacks"},
    "ZhuYuan": {"usa_stacks": True,"max_stacks": 2,
        "default": 2,"label": "Modo"},
    "Astra Yao": {"usa_stacks": True, "max_stacks": 1, 
        "default": 1, "label": "¿Activo?"},
    "Dialyn": {"usa_stacks": True, "max_stacks": 120, 
        "default": 60,"label": "Reseñas"},
    "Lighter": {"usa_stacks": True, "max_stacks": 10,
        "default": 10,"label": "Moral (x10)"},
    "Qingyi": {"usa_stacks": True, "max_stacks": 20,
        "default": 20,"label": "Cargas Subyugación"},
    "Soukaku": {"usa_stacks": True, "max_stacks": 3, 
        "default": 3,"label": "1=Normal, 2=Vortex"},
    "Yuzuha": {"usa_stacks": True, "max_stacks": 6, 
        "default": 3,"label": "Sugar Points"},

}

KEYS = {
    "ATK_PCT": "Ataque",
    "DMG_BONUS": "Daño_Adicional",
    "CRIT_DMG": "Daño_crítico",
    "ENERGY_REGEN": "Recuperación_energía",
    "CRIT_RATE": "Probabilidad_crítico",
    "DAZE": "Aturdimiento",
    "PEN_RATIO": "Tasa_de_Perforación",
    "ANOMALY_BUILDUP": "Bono_Acumulación",
    "ANOMALY_MASTERY": "Tasa_de_Anomalía",
    "ANOMALY_PROF": "Maestría_Anomalía",
    "DEF_FLAT": "Defensa",
}

def core_anby(condicion_activa=False, nombre_habilidad=""):
    """
    Core: Launch Basic Attack: Thunderbolt... for an extra 64% Daze.
    Aplicamos esto si la casilla 'Core Activo' está marcada.
    """
    bonos = {}
    if condicion_activa:
        bonos[KEYS["DAZE"]] = 64.0
    return bonos

def core_ellen(condicion_activa=False, nombre_habilidad=""):
    """
    Core: ...skill's CRIT DMG increases by 100%.
    Aplica a: Chain, Ultimate, y Básicos específicos.
    """
    bonos = {}

    hab = nombre_habilidad.lower()
    keywords = ["basico", "cadena", "definitiva"]
    
    es_habilidad_valida = any(k in hab for k in keywords)

    if condicion_activa and es_habilidad_valida:
        bonos[KEYS["CRIT_DMG"]] = 100.0
        
    return bonos

def core_evelyn(condicion_activa=False, nombre_habilidad=""):
    """
    Core: Upon entering Binding Seal, CRIT Rate increases by 25%.
    """
    bonos = {}
    if condicion_activa:
        bonos[KEYS["CRIT_RATE"]] = 25.0
    return bonos

def core_alice(condicion_activa=False, nombre_habilidad=""):
    """
    Core: 
    1. (Activo) +25% Physical Anomaly Buildup Rate (durante 30s tras Assault).
    2. (Opcional) Max Disorder Multiplier +180% (Depende de la duración).
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["ANOMALY_BUILDUP"]] = 25.0
        bonos["Bono_Disorder_Seg"] = 18.0

    return bonos

def core_soldier_0(condicion_activa=False, nombre_habilidad="", stats_actuales=None, **kwargs):
    """
    Core: 
    1. +25% DMG a enemigos marcados (Silver Star).
    2. Las Réplicas (Aftershocks) ganan Crit DMG igual al 35% (30+5) del Crit DMG de Anby.
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 25.0

        if stats_actuales:

            crit_dmg_actual = stats_actuales.get(KEYS["CRIT_DMG"], 50.0)
            bono_critico = crit_dmg_actual * 0.35
            
            bonos[KEYS["CRIT_DMG"]] = bono_critico

    return bonos

def core_anton(condicion_activa=False, nombre_habilidad="", **kwargs):
    """
    Core Passive Anton:
    - Drill Attack (Taladro) -> +40% DMG
    - Pile Driver (Piloteadora) -> +24% DMG
    """
    bonos = {}
    if not condicion_activa:
        return bonos

    hab = nombre_habilidad.lower()

    keywords_drill = ["taladro"]
    if any(k in hab for k in keywords_drill):
        bonos[KEYS["DMG_BONUS"]] = 40.0

    elif any(k in hab for k in ["martillo"]):
        bonos[KEYS["DMG_BONUS"]] = 24.0

    return bonos

def core_ben(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Ben:
    1. Gana 80% de su Defensa como ATAQUE (Plano).
    2. (Shield) 30% DEF + 550. (Calculamos el valor por si lo quieres mostrar).
    """
    bonos = {}
    
    if stats_actuales:
        defensa = stats_actuales.get(KEYS["DEF_FLAT"], 0.0)
        if defensa == 0:
             defensa = stats_actuales.get("Defensa", 0.0)

        atk_extra = defensa * 0.80

        bonos["Ataque_Ben_Conversion"] = atk_extra

    return bonos

def core_banyue(condicion_activa=False, **kwargs):
    """
    Core Passive Banyue:
    - Activa (EX/Assist): +300 Sheer Force, +36% Fire DMG, +36% Crit DMG.
    """
    bonos = {}

    if condicion_activa:
        bonos["Sheer_force"] = 300.0
        bonos["Daño_elemental"] = 36.0
        bonos[KEYS["CRIT_DMG"]] = 36.0

    return bonos

def core_billy(condicion_activa=False, **kwargs):
    """
    Core Billy:
    - Crouching Shot (Disparo Agachado) -> +50% DMG
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 50.0

    return bonos

def core_burnice(stats_actuales=None, **kwargs):
    """
    Core Burnice:
    - El efecto 'Afterburn' gana 1% de DMG por cada 10 de Maestría de Anomalía.
    - Máximo 30%.
    """
    bonos = {}
    
    if stats_actuales:
        maestria = stats_actuales.get("Maestría_Anomalía", 0.0)

        bono_pct = maestria / 10.0
        if bono_pct > 30.0:
            bono_pct = 30.0
            
        bonos["Bono_Afterburn"] = bono_pct

    return bonos

def core_corin(condicion_activa=False, **kwargs):
    """
    Core Corin:
    - Extended Slash (Motosierra continua) -> +37.5% DMG
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 37.5

    return bonos

def core_grace(condicion_activa=False, **kwargs):
    """
    Core Grace:
    - Consumir 8 stacks de Zap -> +130% Electric Anomaly Buildup.
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["ANOMALY_BUILDUP"]] = 130.0

    return bonos

def core_harumasa(condicion_activa=False, **kwargs):
    """
    Core Harumasa (Dinámico):
    - Dash Attack: +25% Crit Rate (Fijo si activo).
    - Gleaming Edge: +12% Crit DMG por Stack (Max 6).
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["CRIT_RATE"]] = 25.0

        stacks_input = kwargs.get('stacks', 0)
        if not stacks_input:
            stacks_input = 6

        stacks_reales = min(int(stacks_input), 6)

        bonos[KEYS["CRIT_DMG"]] = 12.0 * stacks_reales

    return bonos

def core_hugo(condicion_activa=False, nombre_habilidad="", stacks=0, tipos_soportes=None, **kwargs):
    """
    Core Hugo:
    - Dark Abyss Reverb (Activo): +12% Crit Rate, +25% Crit DMG.
    - Sinergia Stun: +300 ATK (1 Stunner), +900 ATK (2 Stunners).
    - Totalize (Stacks = Segundos Restantes de Stun):
      Aumenta masivamente el Multiplicador de la Habilidad (Ex/Ulti).
      Base +1000%. 
      <= 5s: +280% por seg.
      > 5s: +100% por seg extra.
      Max +3400%.
    """
    bonos = {}
    

    if condicion_activa:
        bonos["Probabilidad_crítico"] = 12.0
        bonos["Daño_crítico"] = 25.0

    if tipos_soportes:
        num_stunners = sum(1 for t in tipos_soportes if "aturdidor" in t)
        
        if num_stunners == 1:
            bonos["Ataque"] = 300.0
        elif num_stunners >= 2:
            bonos["Ataque"] = 900.0

    hab_norm = nombre_habilidad.lower()
    es_nuke = "ex" in hab_norm or "special" in hab_norm or "definitiva" in hab_norm or "ultimate" in hab_norm or "soul" in hab_norm
    
    if es_nuke and stacks > 0:
        tiempo_restante = float(stacks)
        
        bono_mv = 1000.0
        
        segundos_fase1 = min(tiempo_restante, 5.0)
        bono_mv += segundos_fase1 * 280.0
        
        if tiempo_restante > 5.0:
            segundos_fase2 = min(tiempo_restante - 5.0, 10.0)
            bono_mv += segundos_fase2 * 100.0

        if bono_mv > 3400.0:
            bono_mv = 3400.0
            
        bonos["Multiplicador_de_ataques"] = bono_mv

    if "ex" in hab_norm and stacks == 0:
        bonos["Bono_Stun_Ex"] = 20.0

    return bonos

def core_jane(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Jane:
    - Estado 'Gnawed': Permite que el ASSAULT (Asalto) haga Crítico.
    - Base: 40% Rate, 50% DMG.
    - Scaling: +0.16% Rate por cada punto de Maestría de Anomalía.
    """
    bonos = {}

    if condicion_activa:
        maestria = 0.0
        if stats_actuales:
            maestria = stats_actuales.get("Maestría_Anomalía", 0.0)

        extra_rate = maestria * 0.16
        total_assault_rate = 40.0 + extra_rate

        bonos["Assault_Crit_Rate"] = total_assault_rate
        bonos["Assault_Crit_DMG"] = 50.0

    return bonos

def core_manato(condicion_activa=False, **kwargs):
    """
    Core Manato:
    - Molten Edge (Activo):
        * +10% Crit Rate
        * +20% Fire DMG
        * +50% Crit DMG (Asumiendo ataque con consumo de HP)
    """
    bonos = {}

    if condicion_activa:
        bonos["Probabilidad_crítico"] = 10.0
        bonos["Daño_elemental"] = 20.0
        
        # Asumimos que si activas el Core usaste el EX.
        bonos[KEYS["CRIT_DMG"]] = 50.0

    return bonos

def core_miyabi(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Miyabi:
    - Pasiva: Convierte Crit Rate en Anomaly Buildup (1:1).
      * Tope: 80% extra.
    - Activa (Frostburn - Break):
      * Simula el golpe de 1500% ATK (Se suma al Multiplicador).
      * Aplica el bono de equipo de +20% Buildup.
    """
    bonos = {}

    if stats_actuales:
        crit_rate = stats_actuales.get("Probabilidad_crítico", 0.0)
        
        extra_buildup = crit_rate
        
        if extra_buildup > 80.0:
            extra_buildup = 80.0

        bonos[KEYS["ANOMALY_BUILDUP"]] = extra_buildup

    if condicion_activa:
        atk_actual = 0.0
        if stats_actuales:
            atk_actual = stats_actuales.get("Ataque", 0.0)

        daño_proc = atk_actual * 15.0

        bonos["Flat_MV"] = daño_proc

        bonos[KEYS["ANOMALY_BUILDUP"]] = bonos.get(KEYS["ANOMALY_BUILDUP"], 0.0) + 20.0

    return bonos

def core_nekomata(condicion_activa=False, **kwargs):
    """
    Core Nekomata:
    - Al acertar Dodge Counter o Quick Assist: +60% DMG por 6s.
    """
    bonos = {}

    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 60.0

    return bonos

def core_piper(condicion_activa=False, **kwargs):
    """
    Core Piper:
    - Acumula stacks de 'Power' (Max 20).
    - Efecto: +4% Physical Anomaly Buildup por stack.
    - Max: +80% Buildup.
    """
    bonos = {}

    if condicion_activa:
        stacks_input = kwargs.get('stacks', 20)

        stacks_reales = min(int(stacks_input), 20)

        bono_buildup = stacks_reales * 4.0

        bonos[KEYS["ANOMALY_BUILDUP"]] = bono_buildup

    return bonos

def core_soldier11(condicion_activa=False, **kwargs):
    """
    Core Soldier 11:
    - Fire Suppression: Requiere timing preciso en los ataques.
    - Efecto: +70% DMG al acertar el timing (Basic Attack).
    """
    bonos = {}

    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 70.0

    return bonos

def core_yanagi(condicion_activa=False, **kwargs):
    """
    Core Yanagi:
    - Buff Elemental: +20% Daño Eléctrico (por 15s).
    - Buff Disorder: Aumenta el multiplicador base de Disorder en +250%.
      (Ej: De 450% pasa a 700%).
    """
    bonos = {}

    if condicion_activa:
        bonos["Daño_elemental"] = 20.0
        bonos["Disorder_Extra_Mult"] = 250.0

    return bonos

def core_yidhari(condicion_activa=False, **kwargs):
    """
    Core Yidhari:
    - Low HP Buff (<50% HP):
      * Si activas el Core, asumimos que estás por debajo del 50% de vida.
      * Otorga el bono máximo: +100% DMG.
    """
    bonos = {}

    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 100.0

    return bonos

def core_yixuan(condicion_activa=False, **kwargs):
    """
    Core Yixuan:
    - Buff de Habilidad: +60% DMG a Básicos, EX, Assist, Chain y Ult.
      (Al cubrir casi todo el kit, lo aplicamos como DMG Bonus general).
    """
    bonos = {}

    if condicion_activa:
        bonos[KEYS["DMG_BONUS"]] = 60.0

    return bonos

def core_zhuyuan(condicion_activa=False, **kwargs):
    """
    Core Zhu Yuan:
    - Modo Supresivo (Uso de Cartuchos): +36.6% DMG base.
    - Bonus Stun: +36.6% adicional si el enemigo está aturdido.
    Control por Stacks:
    - 1: Solo Modo Supresivo (+36.6%).
    - 2: Modo Supresivo + Enemigo Aturdido (+73.2%).
    """
    bonos = {}

    if condicion_activa:
        bono_dmg = 36.6
        modo_stun = int(kwargs.get('stacks', 1)) >= 2
        
        if modo_stun:
            bono_dmg += 36.6
            
        bonos[KEYS["DMG_BONUS"]] = bono_dmg

    return bonos

def core_lucy(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Lucy:
    - Los Jabalíes heredan el ATK y el Impacto de Lucy.
    - El bufo 'Cheer On!' para los jabalíes es del 200% de su efecto original.
    """
    bonos = {}

    if condicion_activa and stats_actuales:
        atk_lucy = stats_actuales.get(KEYS["ATK_PCT"], 0.0)
        if atk_lucy == 0: 
            atk_lucy = stats_actuales.get("Ataque", 0.0)
            
        impact_lucy = stats_actuales.get("Impacto", 0.0)

        buff_base = (atk_lucy * 0.138) + 44.0

        buff_jabalies = buff_base * 2.0

        atk_jabali_total = atk_lucy + buff_jabalies

        bonos["Jabalí_Impacto"] = impact_lucy
        bonos["Jabalí_ATK_Total"] = atk_jabali_total

    return bonos

def core_astra_yao(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Astra Yao:
    - Estado 'Idyllic Cadenza': Aumenta el ATK en 35% del ATK Inicial de Astra.
    - Máximo: 1,200 ATK.
    """
    bonos = {}

    if condicion_activa and stats_actuales:
        atk_inicial = stats_actuales.get("Ataque", 0.0)
        
        buff_atk = atk_inicial * 0.35

        if buff_atk > 1200.0:
            buff_atk = 1200.0
            
        bonos["Ataque"] = buff_atk

    return bonos

def core_dialyn(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Dialyn:
    1. Conversión de Stats: Si Prob. Crit > 50%, gana 2 Impacto por cada 1% extra.
       (Máximo +100 Impacto).
    2. Queja Maliciosa (Condición Activa): +30% Multiplicador de Daño de Aturdimiento.
    """
    bonos = {}

    if stats_actuales:
        crit_rate = stats_actuales.get("Probabilidad_crítico", 0.0)
        
        if crit_rate > 50.0:
            exceso = crit_rate - 50.0
            bono_impacto = exceso * 2.0
            
            if bono_impacto > 100.0:
                bono_impacto = 100.0
                
            bonos["Impacto"] = bono_impacto

    if condicion_activa:
        bonos["Stun_DMG_Multiplier"] = 30.0

    return bonos

def core_ju_fufu(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Ju Fufu (Tiger's Roar):
    - Base: +20% Crit DMG para el equipo.
    - Escalado: Si ATK Inicial > 2800 -> +5% Crit DMG por cada 100 ATK extra.
    - Máximo extra: +30% (Tope total: 50% Crit DMG).
    - Efectos adicionales: Chain DMG +20%, Ult DMG +40%.
    - Self-Buff (Solo ella): +50 Impacto.
    """
    bonos = {}

    if condicion_activa and stats_actuales:
        atk_actual = stats_actuales.get("Ataque", 0.0)
        
        crit_dmg_bonus = 20.0

        if atk_actual >= 2800.0:
            exceso = atk_actual - 2800.0
            pasos = int(exceso // 100)
            extra = pasos * 5.0
            
            if extra > 30.0:
                extra = 30.0
            
            crit_dmg_bonus += extra

        bonos["Daño_crítico"] = crit_dmg_bonus

        bonos["Bono_Daño_Ulti"] = 40.0
        bonos["Bono_Daño_Cadena"] = 20.0
        bonos["Impacto"] = 50.0

    return bonos

def core_koleda(condicion_activa=False, **kwargs):
    """
    Core Koleda:
    - Al usar EX Special Attack o Basic Attack potenciado (Furnace Fire): El Daze (Aturdimiento) aumenta un 60%.
    """
    bonos = {}
    
    if condicion_activa:
        bonos[KEYS["DAZE"]] = 60.0

    return bonos

def core_caesar(condicion_activa=False, **kwargs):
    """
    Core Caesar (Radiant Aegis):

    - Buff: ATK +1000 (Plano).
    - Escudo: 1400% del Impacto + 1400 que no nos importa
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Ataque"] = 1000.0
        
    return bonos

def core_lighter(condicion_activa=False, stacks=0, **kwargs):
    """
    Core Lighter (Morale Burst):
    - Impacto: Aumenta 2% por cada 10 Moral consumida (Stacks 0-10). Máx 20%.
    - Debuff (Activo): Reduce RES Hielo y Fuego del enemigo en 15%.
    """
    bonos = {}
    
    if stacks > 0:
        buff_impacto = stacks * 2.0
        if buff_impacto > 20.0: buff_impacto = 20.0
        bonos["Impacto"] = buff_impacto

    if condicion_activa:
        bonos["Red_Resistencia_Fuego"] = 15.0
        bonos["Red_Resistencia_Hielo"] = 15.0

    return bonos

def core_lucia(condicion_activa=False, **kwargs):
    """
    Core Lucia (Dream State):
    - Ether Veil: Aumenta HP Max en 5%.
    - Dreamer's Nursery Rhyme: Aumenta Daño en 20%.
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Puntos_Vida"] = 5.0 
        bonos["Daño_Adicional"] = 20.0

    return bonos

def core_lycaon(condicion_activa=False, nombre_habilidad="", **kwargs):
    """
    Core Lycaon:
    - Básicos Cargados: +80% Daze (Aturdimiento) en ataques básicos.
    - Debuff (Activo): Reduce la RES Hielo del enemigo en 25%.
    """
    bonos = {}
    
    habilidad_norm = nombre_habilidad.lower() if nombre_habilidad else ""
    if "basic" in habilidad_norm or "básico" in habilidad_norm or "basico" in habilidad_norm:
        bonos["Bono_Stun_Basico"] = 80.0

    if condicion_activa:
        bonos["Red_Resistencia_Hielo"] = 25.0

    return bonos

def core_nicole(condicion_activa=False, **kwargs):
    """
    Core Nicole:
    - Al golpear con balas mejoradas o Campo de Energía:
      Reduce la DEF del enemigo en 40% durante 3.5s.
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Reduccion_DEF_enemigo"] = 40.0

    return bonos

def core_orphie_magus(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Orphie & Magus:
    - Pasiva: Crit Rate +25%, Aftershock DMG +85%.
    - Zeroed In (Activo): ATK Base +280.
    - Escalado: Si ER >= 1.6, +20 ATK por cada 0.1 ER extra.
    - Tope total ATK: 700.
    """
    bonos = {}
    
    bonos["Probabilidad_crítico"] = 25.0
    bonos["Daño_Aftershock"] = 85.0

    if condicion_activa and stats_actuales:
        er_actual = stats_actuales.get("Recuperación_energía", 1.56)
        
        buff_atk = 280.0

        if er_actual >= 1.6:
            exceso = er_actual - 1.6
            pasos = int(exceso / 0.1)
            extra = pasos * 20.0
            buff_atk += extra
            
        if buff_atk > 700.0:
            buff_atk = 700.0
            
        bonos["Ataque"] = buff_atk

    return bonos

def core_pan_yinhu(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Pan Yinhu (Meridian Flow):
    - Activo: Otorga Sheer Force igual al 18% del ATK.
    - Max: 540 puntos.
    """
    bonos = {}
    
    if condicion_activa and stats_actuales:
        atk_actual = stats_actuales.get("Ataque", 0.0)
        
        buff_sheer = atk_actual * 0.18
        
        if buff_sheer > 540.0:
            buff_sheer = 540.0

        bonos["Sheer_force"] = buff_sheer

    return bonos

def core_pulchra(condicion_activa=False, **kwargs):
    """
    Core Pulchra (Hunter's Gait):
    - Activo: Aumenta el Aturdimiento (Daze) que ella inflige en un 30%.
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Aturdimiento"] = 30.0

    return bonos

def core_qingyi(stacks=0, **kwargs):
    """
    Core Qingyi (Subjugation):
    - Aplica cargas al enemigo (Max 20).
    - Cada carga aumenta el Multiplicador de Daño de Aturdimiento en 4%.
    """
    bonos = {}
    
    if stacks > 0:
        buff_stun_mult = stacks * 4.0

        if buff_stun_mult > 80.0:
            buff_stun_mult = 80.0

        bonos["Stun_DMG_Multiplier"] = buff_stun_mult

    return bonos

def core_rina(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Rina (Mini Destruction Partner):
    - Activo: Aumenta PEN Ratio del equipo (y ella misma).
    - Fórmula: (PEN_Actual * 0.25) + 12%.
    - Máximo: 30%.
    """
    bonos = {}
    
    if condicion_activa and stats_actuales:
        pen_actual = stats_actuales.get("Tasa_de_Perforación", 0.0)

        bono_pen = (pen_actual * 0.25) + 12.0

        if bono_pen > 30.0:
            bono_pen = 30.0
            
        bonos["Tasa_de_Perforación"] = bono_pen

    return bonos

def core_seed(condicion_activa=False, **kwargs):
    """
    Core Seed:
    - Onslaught: ATK +1000, Crit DMG +30%.
    - Besiege: Daño +25%.
    (Se asume que hay un Vanguardia en el equipo para activar Besiege).
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Ataque"] = 1000.0
        bonos["Daño_crítico"] = 30.0

        bonos["Daño_Adicional"] = 25.0

    return bonos

def core_seth(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Seth:
    - Escudo: 80% del ATK Inicial (Máx 3000).
    - Buff: +100 Maestría de Anomalía (AP) mientras el escudo dura.
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Maestría_Anomalía"] = 100.0
        
        if stats_actuales:
            atk_actual = stats_actuales.get("Ataque", 0.0)
            valor_escudo = atk_actual * 0.80
            
            if valor_escudo > 3000.0:
                valor_escudo = 3000.0
                
            bonos["Escudo_Seth"] = valor_escudo

    return bonos

def core_soukaku(stacks=0, stats_actuales=None, **kwargs):
    """
    Core Soukaku (Fly the Flag):
    - Stack 1 (Normal): ATK +20% (Max 500).
    - Stack 3 (Vortex): ATK +40% (Max 1000).
    - El bono es ATK Plano añadido a sí misma (y transferible).
    """
    bonos = {}
    
    if stacks > 0 and stats_actuales:
        atk_actual = stats_actuales.get("Ataque", 0.0)
        
        if stacks == 1 or 2:
            buff = atk_actual * 0.20
            if buff > 500.0: buff = 500.0
        else:
            buff = atk_actual * 0.40
            if buff > 1000.0: buff = 1000.0
            
        bonos["Ataque"] = buff

    return bonos

def core_trigger(condicion_activa=False, **kwargs):
    """
    Core Trigger:
    - Debuff: Aumenta el Multiplicador de Daño de Stun del enemigo en 35%.
    - Aplica incluso si no está aturdido (afecta cálculo de daño final).
    """
    bonos = {}
    
    if condicion_activa:
        bonos["Unstun_DMG_Multiplier"] = 35.0

    return bonos

###=======================================
# REVISAR A POSTERIORI
###=======================================

def core_vivian(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Vivian (Full Kit):
    1. Vivian's Prophecy: DoT de Éter (55% ATK) cada 0.55s.
    2. Abloom: Daño extra al detonar anomalías.
       Escala con Maestría de Anomalía (AP) por cada 10 puntos.
       Ratios: Ether 6.15%, Elec 3.2%, Fire 8%, Phys 0.75%, Ice 1.08%.
    """
    bonos = {}
    
    if condicion_activa and stats_actuales:
        atk_actual = stats_actuales.get("Ataque", 0.0)
        ap_actual = stats_actuales.get("Maestría_Anomalía", 0.0)
        

        dano_profecia = atk_actual * 0.55
        bonos["Vivian_Prophecy_Tick"] = dano_profecia
        bloques_ap = ap_actual / 10.0
        
        ratios = {
            "Abloom_Ether_Add": 6.15,
            "Abloom_Fire_Add": 8.00,
            "Abloom_Elec_Add": 3.20,
            "Abloom_Ice_Add": 1.08,
            "Abloom_Phys_Add": 0.75
        }
        
        for nombre, ratio in ratios.items():
            pct_extra = bloques_ap * ratio
            bonos[nombre] = pct_extra 

    return bonos

def core_yuzuha(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Yuzuha (Tanuki Wish):
    - Mecánica: Puntos de Azúcar (Sugar Points) 0-6 (No afectan el buff en este texto).
    - Buff Activo: 
      1. ATK +40% del ATK Inicial (Max 1200).
      2. Daño +15%.
    """
    bonos = {}
    
    if condicion_activa and stats_actuales:
        atk_actual = stats_actuales.get("Ataque", 0.0)

        buff_atk = atk_actual * 0.40

        if buff_atk > 1200.0:
            buff_atk = 1200.0
            
        bonos["Ataque"] = buff_atk
        
        bonos["Daño_Adicional"] = 15.0

    return bonos

def core_zhao(condicion_activa=False, stats_actuales=None, **kwargs):
    """
    Core Zhao:
    - Pasiva: Gana 1.4% Crit Rate por cada 1,000 de HP Máximo.
    - Activa (Ether Veil): +1000 ATK y +5% HP Máximo.
    """
    bonos = {}
    
    if stats_actuales:
        hp_actual = stats_actuales.get("Puntos_Vida", 0.0)
        
        crit_extra = (hp_actual / 1000.0) * 1.4
        bonos["Probabilidad_crítico"] = crit_extra

        if condicion_activa:
            bonos["Ataque"] = 100.0
            bonos["Puntos_Vida_%"] = 5.0 

    return bonos

def core_ye_shunguang(condicion_activa=False, **kwargs):
    """
    Core Ye Shunguang:
    - Unity (Siempre): +30% Crit Rate, +25% DMG.
    - Enlightened Mind (Activo):
      Reemplaza el Multiplicador de Stun con Vulnerabilidad (Max 110%).
      Simulamos esto sumando 110% al bono de stun.
      Esto hace que golpear a un enemigo no aturdido sea devastador (210% total).
    """
    bonos = {}
    
    bonos["Probabilidad_crítico"] = 30.0
    bonos["Daño_Adicional"] = 25.0
    
    if condicion_activa:
        bonos["Bono_Multiplicador_Stun"] = 110.0

    return bonos

MAPA_CORE = {
    "Anby": core_anby,
    "Ellen": core_ellen,
    "Evelyn": core_evelyn,
    "Alice": core_alice,
    "Soldier 0 - Anby": core_soldier_0,
    "Anton": core_anton,
    "Ben": core_ben,
    "Banyue": core_banyue,
    "Billy": core_billy,
    "Burnice": core_burnice,
    "Corin": core_corin,
    "Grace": core_grace,
    "Harumasa": core_harumasa,
    "Hugo": core_hugo,
    "Jane": core_jane,
    "Manato": core_manato,
    "Miyabi": core_miyabi,
    "Nekomata": core_nekomata,
    "Piper": core_piper,
    "Soldier 11": core_soldier11,
    "Yanagi": core_yanagi,
    "Yidhari": core_yidhari,
    "Yixuan": core_yixuan,
    "Zhu Yuan": core_zhuyuan,
    "Lucy": core_lucy,
    "Astra Yao": core_astra_yao,
    "Dialyn": core_dialyn,
    "Ju Fufu": core_ju_fufu,
    "Koleda": core_koleda,
    "Caesar": core_caesar,
    "Lighter": core_lighter,
    "Lucia": core_lucia,
    "Lycaon": core_lycaon,
    "Nicole": core_nicole,
    "Orphie & Magus": core_orphie_magus,
    "Pan Yinhu": core_pan_yinhu,
    "Pulchra": core_pulchra,
    "Qingyi": core_qingyi,
    "Rina": core_rina,
    "Seed": core_seed,
    "Seth": core_seth,
    "Soukaku": core_soukaku,
    "Trigger": core_trigger,
    "Vivian": core_vivian,
    "Yuzuha": core_yuzuha,
    "Zhao": core_zhao,
    "Ye Shunguang": core_ye_shunguang
}