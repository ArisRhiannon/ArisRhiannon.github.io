# Calculadora-ZZZ

Una calculadora de daño básica para Zenless Zone Zero (ZZZ) escrita en Python con Flet. También tiene soporte para cargar datos desde la API de Enka.network, asumiendo que el servidor responda y los perfiles estén públicos.

> El proyecto solía ser bastante inútil y solo jalaba datos de la API de Enka. Ahora hace algunos cálculos más de daño, supongo. Tampoco es que solucione la vida, pero al menos funciona para pasar el rato. :FrierenShiver:

---

## Lo que hace (si es que no falla nada)

1. **Importación por UID**: Intenta conectarse a Enka.network para extraer los agentes equipados, sus estadísticas, discos y W-Engines. Requiere que el showcase del juego esté configurado como público.
2. **Cálculos de Daño**:
   - **Daño General**: La matemática habitual de daño no anómalo. Aplica defensas, resistencias elementales del enemigo y aturdimiento.
   - **Daño Sheer**: Lógica dedicada a ignorar la defensa basándose en la estadística Sheer Force.
   - **Daño de Anomalía**: Fórmulas para los distintos elementos (Fuego, Electricidad, Hielo, Físico, Éter) y maestría de anomalía (AP). Incluye el multiplicador de crítico de anomalía para Jane Doe.
   - **Daño de Disorder**: Una simulación estática del daño de detonación de Disorder basada en un tiempo promedio estimado.
   - **Acumulación de Anomalía (Build-up)**: Estimación de acumulación por golpe aplicando las estadísticas de tasa y las resistencias correspondientes del enemigo.
3. **Gestión de Soportes**: Permite meter hasta dos personajes de soporte en el equipo para simular las pasivas y los efectos de sus respectivos W-Engines y discos sobre el DPS.
4. **Base de Datos de Efectos**:
   - **Mindscapes**: Lógica para emular los duplicados y constelaciones de los personajes.
   - **W-Engines**: Modificadores según refinamientos y stacks.
   - **Sets de Discos**: Bonos habituales de 2 y 4 piezas.
   - **Efectos Core y Habilidades Pasivas**: Multiplicadores específicos de cada agente.
5. **Pestañas de la UI**:
   - **DPS**: Edición manual de estadísticas y cálculo de daño.
   - **Soportes / Equipo**: Configuración de buffs pasivos externos.
   - **Guardar/Cargar Builds**: Comparativa local de configuraciones guardadas en disco.
   - **Recomendaciones**: Sugerencias genéricas basadas en las estadísticas actuales.
   - **Gráficas**: Visualización de rendimiento (siempre que tengas matplotlib instalado).

---

## Instalación y Requisitos

Supongo que necesitas tener instalado Python 3.10 o superior si quieres intentar ejecutarlo.

1. **Clona el repositorio:**
   ```bash
   git clone https://github.com/ErikGallardo/Calculadora-ZZZ.git
   cd Calculadora-ZZZ
   ```

2. **Instala las dependencias necesarias:**
   Hay que lidiar con la instalación de paquetes externos:
   ```bash
   pip install flet enka.py pandas
   ```

3. **Ejecuta el archivo principal:**
   ```bash
   python Calculadora_ZZZ.py
   ```

---

## Estructura del Proyecto

Por si tienes ganas de leer código ajeno o depurar fallos:

* `Calculadora_ZZZ.py`: El punto de entrada que une toda la interfaz con la lógica de estadísticas y daños.
* `Crear_Gui.py`: Todo el código Flet de la interfaz gráfica. Controles, layouts y formularios.
* `logica_danos.py`: Contiene las fórmulas matemáticas de daño general, anomalías, build-up y disorder.
* `gestor_api.py`: Cliente asíncrono para mapear los datos crudos extraídos de Enka a variables legibles.
* `gestor_estadisticas.py`: Consolida las estadísticas base de los personajes sumando los bonos de sets, armas y soportes.
* `efectos_*.py`: Módulos que aíslan las pasivas de armas, discos, constelaciones y soportes para evitar que todo sea un solo archivo inmanejable.
* `cargar_datos.py` & `estado_build.py`: Carga rudimentaria de archivos locales y almacenamiento en memoria del estado de la build.

---

## Notas y Advertencias
* **Enka.network**: Dependemos enteramente de que los servidores externos de Enka estén levantados y de que no cambien el formato de sus respuestas.
* **Cálculo de Disorder**: Asume un tiempo promedio estático de 3 segundos debido a las limitaciones de los datos de la interfaz de usuario. En el juego real, la fórmula varía según la duración real de la anomalía previa.
