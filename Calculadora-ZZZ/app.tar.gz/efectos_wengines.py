# efectos_wengines.py

# ==========================================
# DICCIONARIO DE LLAVES (REFERENCIA LOGICADMG)
# ==========================================
KEYS_LOGICA = {

    "ATK_PCT": "Ataque",
    "DMG_ELEMENTAL": "Daño_elemental",
    "DMG_GENERICO": "Daño_Adicional",
    "CRIT_RATE": "Probabilidad_crítico",
    "CRIT_DMG": "Daño_crítico",
    "PEN_DEF": "Reduccion_DEF_enemigo",
    "PEN_RES_PHYS": "Pen_Res_Fisico",
    "PEN_RES_FIRE": "Pen_Res_Fuego",
    "PEN_RATIO": "Tasa_de_Perforación",
    "ANOMALY_PROF": "Maestría_Anomalía",
    "ANOMALY_BUILDUP": "Bono_Acumulación",
    "IMPACT": "Impacto",
    "HP_PCT": "Puntos_Vida",
    "ENERGY_REGEN": "Recarga_Energía",
    "SHIELD": "Valor_Escudo",
    "DAZE": "Aturdimiento",
    "DMG_BASIC": "Bono_Dano_Basico",
    "STUN_BASIC": "Bono_Stun_Basico",
    "DMG_DASH": "Bono_Dano_Dash",  
    "STUN_DASH": "Bono_Stun_Dash",  
    "DMG_EX": "Bono_Dano_Ex",
    "STUN_EX": "Bono_Stun_Ex", 
    "DMG_ASSIST": "Bono_Dano_Assist",
    "STUN_ASSIST": "Bono_Stun_Assist", 
    "DMG_ULT": "Bono_Dano_Ulti",
    "STUN_ULT": "Bono_Stun_Ulti"

}

# ==========================================
# CONFIGURACIÓN DE STACKS
# ==========================================
# Agregamos entradas para armas que usan "estados" (Activo/Inactivo) como stacks de 0 a 1
CONFIG_WENGINES = {
    "The Brimstone": {"max_stacks": 8, "nombre_stack": "Stacks"},
    "Bellicose Blaze": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Blazing Laurel": {"max_stacks": 20, "nombre_stack": "Wilt (Ice/Fire Only)"},
    "Fusion Compiler": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "The Restrained": {"max_stacks": 5, "nombre_stack": "Stacks"},
    "Ice-Jade Teapot": {"max_stacks": 30, "nombre_stack": "Tea-riffic"},
    "Flamemaker Shaker": {"max_stacks": 10, "nombre_stack": "Stacks"},
    "Sharpened Stinger": {"max_stacks": 3, "nombre_stack": "Predatory Instinct"},
    "Cordis Germina": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Flight of Fancy": {"max_stacks": 6, "nombre_stack": "Stacks"},
    "Hailstorm Shrine": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Heartstring Nocturne": {"max_stacks": 2, "nombre_stack": "Heartstring"},
    "Kraken's Cradle": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "Practiced Perfection": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Qingming Birdcage": {"max_stacks": 2, "nombre_stack": "Qingming Companion"},
    "Riot Suppressor Mark VI": {"max_stacks": 8, "nombre_stack": "Charge"},
    "Roaring Fur-nace": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Severed Innocence": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "Spectral Gaze": {"max_stacks": 3, "nombre_stack": "Spirit Lock"},
    "Wrathful Vajra": {"max_stacks": 2, "nombre_stack": "Stacks"},
    "Yesterday Calls": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "Bashful Demon": {"max_stacks": 4, "nombre_stack": "Stacks"},
    "Cauldron of Clarity": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "Housekeeper": {"max_stacks": 15, "nombre_stack": "Stacks"},
    "Kaboom the Cannon": {"max_stacks": 4, "nombre_stack": "Stacks"},
    "Peacekeeper - Specialized": {"max_stacks": 1, "nombre_stack": "Dodge/Assist Trigger"},
    "Precious Fossilized Core": {"max_stacks": 1, "nombre_stack": "Target HP < 50% (On)"},
    "Rainforest Gourmet": {"max_stacks": 10, "nombre_stack": "Stacks"},
    "Roaring Ride": {"max_stacks": 1, "nombre_stack": "Buff Active"},
    "Six Shooter": {"max_stacks": 6, "nombre_stack": "Charges"},
    "Slice of Time": {"max_stacks": 0, "nombre_stack": "N/A"}, # Pasiva de utilidad
    "Spring Embrace": {"max_stacks": 1, "nombre_stack": "ATK Mode (vs Energy)"},
    "Starlight Engine": {"max_stacks": 1, "nombre_stack": "Trigger Active"},
    "Steam Oven": {"max_stacks": 8, "nombre_stack": "Energy Stacks"},
    "Street Superstar": {"max_stacks": 3, "nombre_stack": "Charges"},
    "The Vault": {"max_stacks": 1, "nombre_stack": "Buff Active"},
    "Unfettered Fruition": {"max_stacks": 1, "nombre_stack": "Attribute Counter (Active)"},
    "Weeping Gemini": {"max_stacks": 3, "nombre_stack": "Stacks"},
    "Dreamlit Hearth": {"max_stacks": 1, "nombre_stack": "Ether Veil (Active)"},
    "Elegant Vanity": {"max_stacks": 1, "nombre_stack": "Buff Active (25+ Energy)"},
    "Zanshin Herb Case": {"max_stacks": 1, "nombre_stack": "Squad Anomaly/Stun"},
    # Nuevos para manejar estados On/Off como stacks
    "Cloudcleave Radiance": {"max_stacks": 1, "nombre_stack": "Ether Veil (On/Off)"},
    "Deep Sea Visitor": {"max_stacks": 1, "nombre_stack": "Dash Hit (On/Off)"},

}

# ==========================================
# FUNCIONES DE EFECTOS
# ==========================================

def efecto_arma_bellicose(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Bellicose Blaze: CRIT Rate (Siempre) + Pen DEF (Condicional) """
    bonos = {}
    idx = refinamiento - 1 
    crit_values = [20.0, 23.0, 26.0, 29.0, 32.0]
    ignore_def_values = [15.0, 17.2, 19.5, 21.7, 24.0]

    # Siempre activo
    bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_values[idx]

    # Condicional (Stacks de Aftershock)
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["PEN_DEF"]] = ignore_def_values[idx] * stacks_reales
        
    return bonos

def efecto_arma_lighter(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Blazing Laurel: Impacto (Condicional) + Wilt Stacks (Crit DMG Ice/Fire) """
    bonos = {}
    idx = refinamiento - 1
    
    # 1. Impacto (Al lanzar Asistencia) [Source: 4]
    # Valores: 25% / 28.75% / 32.5% / 36.25% / 40%
    impact_values = [25.0, 28.75, 32.5, 36.25, 40.0]
    
    # Asumimos que el efecto de Asistencia está activo para el cálculo de Impacto
    bonos[KEYS_LOGICA["IMPACT"]] = impact_values[idx]

    # 2. Efecto Wilt (Marchitar) - Acumulable hasta 20 veces [Source: 4]
    # Aumenta el CRIT DMG de Fuego/Hielo por stack.
    # Valores por stack: 1.5% / 1.72% / 1.95% / 2.17% / 2.4%
    wilt_cd_per_stack = [1.5, 1.72, 1.95, 2.17, 2.4]
    
    stacks_reales = int(stacks) if stacks else 0
    # Por seguridad, limitamos a 20 aunque la config lo controle
    stacks_reales = min(stacks_reales, 20)

    if stacks_reales > 0:
        # Se suma al Daño Crítico global (asumiendo personaje de Fuego/Hielo)
        bonos[KEYS_LOGICA["CRIT_DMG"]] = wilt_cd_per_stack[idx] * stacks_reales

    return bonos

def efecto_arma_s11(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ The Brimstone: ATK stacks """
    bonos = {}
    idx = refinamiento - 1
    atk_per_stack = [3.5, 4.4, 5.2, 6.0, 7.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_per_stack[idx] * stacks_reales 
    return bonos

def efecto_arma_zhao(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Half-Sugar Bunny: Team Buffs + Crit DMG Condicional """
    bonos = {}
    idx = refinamiento - 1
    team_atk_hp = [10.0, 11.5, 13.0, 14.5, 16.0]
    crit_dmg_values = [30.0, 34.5, 39.0, 43.5, 48.0]

    # Siempre (Stats de soporte pasivos)
    bonos[KEYS_LOGICA["ATK_PCT"]] = team_atk_hp[idx]
    bonos[KEYS_LOGICA["HP_PCT"]] = team_atk_hp[idx] 
    
    # Condicional (Ether Veil) - Asumimos activo si se usa el arma en calc
    bonos[KEYS_LOGICA["CRIT_DMG"]] = crit_dmg_values[idx]
    return bonos

def efecto_arma_ellen(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Deep Sea Visitor: Ice DMG (Siempre) + CRIT Rate (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    ice_dmg_values = [25.0, 31.5, 38.0, 44.5, 50.0]
    crit_rate_base = [10.0, 12.5, 15.0, 17.5, 20.0]
    
    # Siempre activo
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = ice_dmg_values[idx]
    
    # Condicional: Hit + Dash Hit. Usamos stacks (0 o 1) para simular "Full buff"
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        # Asumimos ambos buffs activos (Hit + Dash) = x2
        bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_rate_base[idx] * 2
    else:
        # Asumimos solo el buff básico de golpe si stacks es 0 pero está equipada? 
        # Mejor ser estricto con el stack: 0 = base, 1 = full combat
        bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_rate_base[idx] # Al menos 1 stack de hit normal

    return bonos

def efecto_arma_lycaon(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ The Restrained: DMG/Daze Stacks """
    bonos = {}
    idx = refinamiento - 1
    buff_per_stack = [6.0, 7.5, 9.0, 10.5, 12.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = buff_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_grace(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Fusion Compiler: ATK (Siempre) + Prof Stacks """
    bonos = {}
    idx = refinamiento - 1
    atk_values = [12.0, 15.0, 18.0, 21.0, 24.0]
    anomaly_per_stack = [25, 31, 37, 43, 50]
    
    # Siempre
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_values[idx]
    
    # Condicional
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["ANOMALY_PROF"]] = anomaly_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_nekomata(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Steel Cushion: Phys DMG (Siempre) + Backstab (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    phys_values = [20.0, 25.0, 30.0, 35.0, 40.0]
    backstab_values = [25.0, 31.5, 38.0, 44.0, 50.0]
    
    # Siempre
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = phys_values[idx]
    
    # Condicional (Asumimos activo por defecto o requeriría toggle, pero se suele asumir en calcs)
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = backstab_values[idx]
    return bonos

def efecto_arma_koleda(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Hellfire Gears: Impact Stacks """
    bonos = {}
    idx = refinamiento - 1
    impact_per_stack = [10.0, 12.5, 15.0, 17.5, 20.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["IMPACT"]] = impact_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_rina(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Weeping Cradle: DMG Vulnerability (Tiempo) """
    bonos = {}
    idx = refinamiento - 1
    dmg_debuff_max = [20.2, 24.5, 30.0, 35.5, 39.8]
    
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_debuff_max[idx]
    return bonos

def efecto_arma_qingyi(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Ice-Jade Teapot: Impact Stacks + Team DMG """
    bonos = {}
    idx = refinamiento - 1
    impact_per_stack = [0.7, 0.88, 1.05, 1.22, 1.4]
    team_dmg = [20.0, 23.0, 26.0, 29.0, 32.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["IMPACT"]] = impact_per_stack[idx] * stacks_reales
    
    if stacks_reales >= 15:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = team_dmg[idx]
    return bonos

def efecto_arma_zhu_yuan(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Riot Suppressor Mark VI: Crit Rate (Siempre) + DMG (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    crit_rate = [15.0, 15.0, 15.0, 15.0, 15.0]
    dmg_buff = [35.0, 40.0, 45.0, 50.0, 55.0]
    
    # Siempre
    bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_rate[idx]
    
    # Condicional (Consumir carga)
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_buff[idx]
    return bonos

def efecto_arma_jane(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Sharpened Stinger: Phys DMG (Stacks) + Anomaly (Max Stacks) """
    bonos = {}
    idx = refinamiento - 1
    phys_per_stack = [12.0, 15.0, 18.0, 21.0, 24.0]
    buildup_max = [40.0, 50.0, 60.0, 70.0, 80.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = phys_per_stack[idx] * stacks_reales
    
    if stacks_reales >= 3:
        bonos[KEYS_LOGICA["ANOMALY_BUILDUP"]] = buildup_max[idx]
    return bonos

def efecto_arma_yanagi(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Timeweaver: Buildup (Siempre) + Prof/Disorder (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    buildup = [30.0, 35.0, 40.0, 45.0, 50.0]
    prof_bonus = [75, 85, 95, 105, 115]
    disorder_dmg = [25.0, 27.5, 30.0, 32.5, 35.0]
    
    # Siempre
    bonos[KEYS_LOGICA["ANOMALY_BUILDUP"]] = buildup[idx]
    
    # Condicionales (Asumimos activo en simulación optima)
    bonos[KEYS_LOGICA["ANOMALY_PROF"]] = prof_bonus[idx]
    
    # Chequeo de stat total
    current_prof = stats_actuales.get(KEYS_LOGICA["ANOMALY_PROF"], 0) + prof_bonus[idx]
    if current_prof >= 375:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = disorder_dmg[idx]
    return bonos

def efecto_arma_caesar(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Tusks of Fury: Shield (Siempre) + Buffs (Condicional Team) """
    bonos = {}
    idx = refinamiento - 1
    shield_val = [30.0, 38.0, 46.0, 52.0, 60.0]
    team_dmg = [18.0, 22.5, 27.0, 31.5, 36.0]
    team_daze = [12.0, 15.0, 18.0, 21.0, 24.0]
    
    # Siempre
    bonos[KEYS_LOGICA["SHIELD"]] = shield_val[idx]
    
    # Condicional (Asumimos activo)
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = team_dmg[idx]
    bonos[KEYS_LOGICA["DAZE"]] = team_daze[idx]
    return bonos

def efecto_arma_burnice(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Flamemaker Shaker: DMG (Stacks) + Prof (Max Stacks) """
    bonos = {}
    idx = refinamiento - 1
    dmg_per_stack = [3.5, 4.4, 5.2, 6.1, 7.0]
    prof_bonus = [50, 62, 75, 87, 100]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_per_stack[idx] * stacks_reales
    
    if stacks_reales >= 5:
        bonos[KEYS_LOGICA["ANOMALY_PROF"]] = prof_bonus[idx]
    return bonos

def efecto_arma_ye_shunguang(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Cloudcleave Radiance: PEN RES (Siempre) + Ether Veil Buffs (Control Manual) """
    bonos = {}
    idx = refinamiento - 1
    PEN_RES_PHYS = [20.0, 22.0, 24.0, 26.0, 28.0]
    buff_val = [25.0, 28.7, 32.5, 36.2, 40.0]
    
    # 1. Efecto Pasivo (Siempre activo)
    bonos[KEYS_LOGICA["PEN_RES_PHYS"]] = PEN_RES_PHYS[idx]
    
    # 2. Efecto Condicional (Velo Etéreo)
    # Si stacks es 1, se activa. Si es 0, no.
    stacks_reales = int(stacks) if stacks else 0
    
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = buff_val[idx]
        bonos[KEYS_LOGICA["CRIT_DMG"]] = buff_val[idx]

    return bonos

def efecto_arma_seed(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Cordis Germina: Crit Rate (Siempre) + Stacks (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    crit_rate = [15.0, 17.0, 19.0, 21.0, 23.0]
    elec_per_stack = [12.5, 14.5, 16.5, 18.5, 20.0]
    ignore_def = [20.0, 23.0, 26.0, 29.0, 32.0]
    
    # Siempre activo
    bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_rate[idx]
    
    # Condicional
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = elec_per_stack[idx] * stacks_reales
        if stacks_reales >= 2:
            bonos[KEYS_LOGICA["PEN_DEF"]] = ignore_def[idx]
            
    return bonos

def efecto_arma_harumasa(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Zanshin Herb Case: Crit Rate (Base + Condicional) + Dash DMG """
    bonos = {}
    idx = refinamiento - 1
    
    # [Source 62] Valores base
    crit_rate_values = [10.0, 11.5, 13.0, 14.5, 16.0]
    dash_elec = [40.0, 46.0, 52.0, 58.0, 64.0]

    # 1. CRIT Rate Base (Siempre activo)
    bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_rate_values[idx]

    # 2. Dash Attack Electric DMG (Solo aplica a Dash)
    bonos[KEYS_LOGICA["DMG_DASH"]] = dash_elec[idx] 
    
    # 3. CRIT Rate Condicional (Squad Anomaly/Stun)
    # [Source 63] "increases by an additional 10-16%"
    stacks_reales = int(stacks) if stacks else 0
    
    if stacks_reales > 0:
        # Sumamos el bono adicional a la llave de CRIT_RATE que ya creamos arriba
        bonos[KEYS_LOGICA["CRIT_RATE"]] += crit_rate_values[idx]

    return bonos

def efecto_arma_miyabi(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Hailstorm Shrine: Crit DMG (Siempre) + Ice DMG (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    cd_val = [50.0, 57.0, 65.0, 72.0, 80.0]
    ice_stack = [20.0, 23.0, 26.0, 29.0, 32.0]
    
    # Siempre activo
    bonos[KEYS_LOGICA["CRIT_DMG"]] = cd_val[idx]
    
    # Condicional
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = ice_stack[idx] * stacks_reales

    return bonos

def efecto_arma_heartstring(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Heartstring Nocturne: Crit DMG (Siempre) + Pen RES (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    cd_val = [50.0, 57.5, 65.0, 72.5, 80.0]
    res_stack = [12.5, 14.5, 16.5, 18.5, 20.0]
    
    # Siempre activo
    bonos[KEYS_LOGICA["CRIT_DMG"]] = cd_val[idx]
    
    # Condicional
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["PEN_RES_FIRE"]] = res_stack[idx] * stacks_reales
    return bonos

def efecto_arma_bashful(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Bashful Demon: Ice DMG (Siempre) + ATK (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    ice_val = [15.0, 17.5, 20.0, 22.0, 24.0]
    atk_stack = [2.0, 2.3, 2.6, 2.9, 3.2]
    
    # Siempre activo
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = ice_val[idx]
    
    # Condicional
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_stack[idx] * stacks_reales
    return bonos

def efecto_arma_demara(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Demara Battery: Elec DMG (Siempre) + Energy (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    elec_val = [15.0, 17.5, 20.0, 22.0, 24.0]
    energy_val = [18.0, 20.5, 23.0, 25.0, 27.5]
    
    # Siempre activo
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = elec_val[idx]
    
    # Condicional (Asumido activo)
    bonos[KEYS_LOGICA["ENERGY_REGEN"]] = energy_val[idx]
    return bonos

def efecto_arma_electro_lip(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Electro-Lip Gloss: Condicional (Enemigos con Anomaly) """
    bonos = {}
    idx = refinamiento - 1
    atk_val = [10.0, 11.5, 13.0, 14.5, 16.0]
    dmg_val = [15.0, 17.5, 20.0, 22.5, 25.0]
    
    # Asumimos que si equipas esto, estás peleando contra gente con anomalía
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_val[idx]
    return bonos

def efecto_arma_housekeeper(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Housekeeper: Phys DMG (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    phys_stack = [3.0, 3.5, 4.0, 4.4, 4.8]
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = phys_stack[idx] * stacks_reales
    return bonos

def efecto_arma_drill_rig(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Drill Rig - Red Axis: Basic/Dash Electric DMG (Condicional) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 72] "Launching EX/Chain boosts Basic/Dash Electric DMG by 50-80%"
    buff_val = [50.0, 57.5, 65.0, 72.5, 80.0]

    # Asumimos el buff activo. 
    # Aplicamos SOLO a Básico y Dash, no al daño global.
    bonos[KEYS_LOGICA["DMG_BASIC"]] = buff_val[idx]
    bonos[KEYS_LOGICA["DMG_DASH"]] = buff_val[idx]
    return bonos

def efecto_arma_cannon_rotor(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Cannon Rotor: ATK (Siempre) """
    bonos = {}
    idx = refinamiento - 1
    atk_val = [7.5, 8.6, 9.7, 10.8, 12.0]
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
    return bonos

def efecto_arma_street_superstar(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Gilded Blossom: ATK (Siempre) + EX DMG (Siempre) """
    bonos = {}
    idx = refinamiento - 1
    atk_val = [6.0, 6.9, 7.8, 8.7, 9.6]
    ex_dmg = [15.0, 17.2, 19.5, 21.8, 24.0]
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = ex_dmg[idx]
    return bonos

def efecto_arma_peacekeeper(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Peacekeeper - Specialized: ATK (Shielded) + Buildup (Trigger) """
    bonos = {}
    idx = refinamiento - 1
    atk_val = [8.0, 9.0, 10.0, 11.0, 12.0] # CSV dice 8-12% pero substat es 25% ATK
    # Nota: CSV dice "Attack: 25%" en substat, y refinamiento 8-12%. 
    # Pero el efecto pasivo dice "Increases ATK". Asumiremos que el refinamiento es el ATK% extra.
    # Corrección: Texto oficial dice "ATK increases by X% while shielded".
    
    # Asumimos que siempre tiene escudo si usa este arma (Stack 0 o 1)
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
    
    # Condicional: Dodge/Assist Trigger
    buildup_val = [8.0, 9.0, 10.0, 11.0, 12.0]
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["ANOMALY_BUILDUP"]] = buildup_val[idx]
        
    return bonos

def efecto_arma_precious_core(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Precious Fossilized Core: HP < 50% (ATK) vs HP >= 50% (Daze) """
    bonos = {}
    idx = refinamiento - 1
    val_bonus = [10.0, 11.5, 13.0, 14.5, 16.0]
    
    stacks_reales = int(stacks) if stacks else 0
    
    if stacks_reales == 1: # HP < 50%
        bonos[KEYS_LOGICA["ATK_PCT"]] = val_bonus[idx]
    else: # HP >= 50% (Default)
        bonos[KEYS_LOGICA["DAZE"]] = val_bonus[idx]
        
    return bonos

def efecto_arma_rainforest(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Rainforest Gourmet: ATK Stacks """
    bonos = {}
    idx = refinamiento - 1
    atk_per_stack = [2.5, 2.8, 3.2, 3.6, 4.0]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["ATK_PCT"]] = atk_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_roaring_ride(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Roaring Ride: Random Buff. Simplificación: Aplicamos promedio o ATK si activo. """
    bonos = {}
    idx = refinamiento - 1
    # Valores base (varían ligeramente por tipo de buff en juego real, aquí usamos el % del CSV)
    # CSV dice "80/100/120 | 0.1 | 20%".
    # El CSV está algo roto en esta línea. Valores reales aprox: 
    # ATK: 8-12%, Anomaly: 40-64, Buildup: 25-40%? 
    # Usaré escalado estándar de A-Rank ATK buff: 10-16% aprox para simplificar si no hay dato limpio.
    # REVISIÓN CSV: "80/100/120" parece Proficiency flat? "20%" buildup?
    # Asumiremos valores medios seguros: 10% ATK.
    
    atk_val = [10.0, 11.5, 13.0, 14.5, 16.0] 
    
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
        
    return bonos

def efecto_arma_six_shooter(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Six Shooter: Daze Stacks """
    bonos = {}
    idx = refinamiento - 1
    daze_per_stack = [4.0, 4.6, 5.2, 5.8, 6.4]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DAZE"]] = daze_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_slice_time(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Slice of Time: Utility (Decibels/Energy). No Combat Stats. """
    return {}

def efecto_arma_spring_embrace(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Spring Embrace: ATK Mode vs Energy Mode """
    bonos = {}
    idx = refinamiento - 1
    val_bonus = [10.0, 11.5, 13.0, 14.5, 16.0]
    
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales == 1: # ATK Mode
        bonos[KEYS_LOGICA["ATK_PCT"]] = val_bonus[idx]
    # else: Energy Gen (No se suele sumar a DMG calc directo)
    
    return bonos

def efecto_arma_starlight_engine_real(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Starlight Engine: ATK on Quick Assist/Counter """
    bonos = {}
    idx = refinamiento - 1
    atk_val = [12.0, 13.8, 15.6, 17.4, 19.2]
    
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["ATK_PCT"]] = atk_val[idx]
    return bonos

def efecto_arma_steam_oven(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Steam Oven: Impact Stacks """
    bonos = {}
    idx = refinamiento - 1
    impact_per_stack = [2.0, 2.3, 2.6, 2.9, 3.2]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["IMPACT"]] = impact_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_street_superstar_real(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Street Superstar: Ultimate DMG per Charge """
    bonos = {}
    idx = refinamiento - 1
    dmg_per_stack = [15.0, 17.5, 20.0, 22.5, 25.0]
    
    stacks_reales = int(stacks) if stacks else 0
    # Se aplica al Ulti, usaremos Generic DMG asumiendo que el usuario calcula Ulti
    bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_the_vault(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ The Vault: DMG vs Target (Triggered by Ether) """
    bonos = {}
    idx = refinamiento - 1
    dmg_val = [15.0, 17.5, 20.0, 22.5, 25.0]
    
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_val[idx]
    return bonos

def efecto_arma_unfettered(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Unfettered Game Ball: Team CRIT Rate (Condicional Attribute Counter) """
    bonos = {}
    idx = refinamiento - 1
    
    # Values: 12% / 13.5% / 15.5% / 17.5% / 20%
    team_crit_rate = [12.0, 13.5, 15.5, 17.5, 20.0]

    # Condicional: Se activa tras un 'Attribute Counter' durante 12s.
    # Usamos stacks = 1 para indicar que el efecto está activo.
    stacks_reales = int(stacks) if stacks else 0
    
    if stacks_reales > 0:
        # Se aplica al CRIT Rate global (afecta al portador y al equipo)
        bonos[KEYS_LOGICA["CRIT_RATE"]] = team_crit_rate[idx]
        
    return bonos

def efecto_arma_weeping_gemini(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Weeping Gemini: Proficiency Stacks """
    bonos = {}
    idx = refinamiento - 1
    prof_per_stack = [30, 34, 38, 42, 46]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["ANOMALY_PROF"]] = prof_per_stack[idx] * stacks_reales
    return bonos

def efecto_arma_flight_of_fancy(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Flight of Fancy: Buildup Rate (Siempre) + Proficiency (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 20] 40-64% Buildup | 20-32 Proficiency per stack
    buildup_val = [40.0, 46.0, 52.0, 58.0, 64.0]
    prof_stack = [20, 23, 26, 29, 32]

    # Siempre activo
    bonos[KEYS_LOGICA["ANOMALY_BUILDUP"]] = buildup_val[idx]

    # Condicional (Stacks)
    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["ANOMALY_PROF"]] = prof_stack[idx] * stacks_reales
    return bonos

def efecto_arma_qingming(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Qingming Birdcage: Crit Rate (Siempre*) + Ether DMG (Stacks) """
    # *Nota: El texto dice "Al lanzar EX, Crit Rate up". Asumimos que se activa junto con los stacks.
    bonos = {}
    idx = refinamiento - 1
    # [Source 40] 20-32% Crit Rate | 8-12.8% Ether DMG per stack
    crit_val = [20.0, 23.0, 26.0, 29.0, 32.0]
    ether_stack = [8.0, 9.2, 10.4, 11.6, 12.8]

    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_val[idx]
        bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = ether_stack[idx] * stacks_reales
    return bonos

def efecto_arma_kraken(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Kraken's Cradle: Ice DMG (Stacks) + Crit Rate (Low HP) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 33] 6-10% Ice DMG per stack | [Source 34] 20-32% Crit Rate if HP < 50%
    ice_stack = [6.0, 7.0, 8.0, 9.0, 10.0]
    crit_low_hp = [20.0, 23.0, 26.0, 29.0, 32.0]

    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = ice_stack[idx] * stacks_reales
    
    # Lógica condicional: Si se usan stacks, asumimos que el usuario simula pérdida de vida.
    # Si stacks == max (3), asumimos HP < 50% para activar el bono secundario.
    if stacks_reales >= 3: 
        bonos[KEYS_LOGICA["CRIT_RATE"]] = crit_low_hp[idx]
    return bonos

def efecto_arma_practiced(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Practiced Perfection: Proficiency (Siempre*) + Phys DMG (Stacks) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 39] 60-96 Mastery/Prof | 20-32% Phys DMG per stack
    # Nota: Texto dice "Anomaly Mastery up" pero valor plano 60-96 sugiere Proficiency.
    prof_val = [60, 69, 78, 87, 96]
    phys_stack = [20.0, 23.0, 26.0, 29.0, 32.0]

    # Asumimos que el bono base se activa al infligir Asalto (condición del arma)
    bonos[KEYS_LOGICA["ANOMALY_PROF"]] = prof_val[idx]
    
    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DMG_ELEMENTAL"]] = phys_stack[idx] * stacks_reales
    return bonos

def efecto_arma_spectral(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Spectral Gaze: DEF PEN (Aftershock) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 50] 25-40% DEF REDUCTION.
    # Nota: El texto menciona Impacto off-field, pero no da valores numéricos. Se omite por seguridad.
    def_pen_val = [25.0, 28.75, 32.5, 36.25, 40.0]

    bonos[KEYS_LOGICA["PEN_DEF"]] = def_pen_val[idx]
    return bonos

def efecto_arma_yesterday(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Yesterday Calls: Daze (Stacks) + Team Crit DMG (Max Stacks) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 60] 9-14.5% Daze? | [Source 61] 30-48% Crit DMG at 3 stacks
    daze_stack = [9.0, 10.3, 11.7, 13.0, 14.5]
    team_cd_val = [30.0, 34.5, 39.0, 43.5, 48.0]

    stacks_reales = int(stacks) if stacks else 0
    bonos[KEYS_LOGICA["DAZE"]] = daze_stack[idx] * stacks_reales

    if stacks_reales >= 3:
        bonos[KEYS_LOGICA["CRIT_DMG"]] = team_cd_val[idx]
    return bonos

def efecto_arma_dreamlit(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Dreamlit Hearth: Team DMG & HP (Condicional Ether Veil) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 14] 25-40% DMG & HP
    buff_val = [25.0, 28.8, 32.5, 36.3, 40.0]

    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = buff_val[idx]
        bonos[KEYS_LOGICA["HP_PCT"]] = buff_val[idx]
    return bonos

def efecto_arma_elegant(stats_actuales, refinamiento, nombre_agente, stacks=0):
    """ Elegant Vanity: Squad DMG (Condicional Energy) """
    bonos = {}
    idx = refinamiento - 1
    # [Source 16] 10-16% DMG
    dmg_val = [10.0, 11.5, 13.0, 14.5, 16.0]

    stacks_reales = int(stacks) if stacks else 0
    if stacks_reales > 0:
        bonos[KEYS_LOGICA["DMG_GENERICO"]] = dmg_val[idx]
    return bonos
# ==========================================
# MAPEO FINAL
# ==========================================

MAPA_WENGINES = {
    "Bellicose Blaze": efecto_arma_bellicose,
    "Blazing Laurel": efecto_arma_lighter,
    "Half-Sugar Bunny": efecto_arma_zhao,
    "The Brimstone": efecto_arma_s11,
    "Deep Sea Visitor": efecto_arma_ellen,
    "The Restrained": efecto_arma_lycaon,
    "Fusion Compiler": efecto_arma_grace,
    "Steel Cushion": efecto_arma_nekomata,
    "Hellfire Gears": efecto_arma_koleda,
    "Weeping Cradle": efecto_arma_rina,
    "Ice-Jade Teapot": efecto_arma_qingyi,
    "Riot Suppressor Mark VI": efecto_arma_zhu_yuan,
    "Sharpened Stinger": efecto_arma_jane,
    "Timeweaver": efecto_arma_yanagi,
    "Tusks of Fury": efecto_arma_caesar,
    "Flamemaker Shaker": efecto_arma_burnice,
    "Cloudcleave Radiance": efecto_arma_ye_shunguang, 
    "Cordis Germina": efecto_arma_seed,               
    "Zanshin Herb Case": efecto_arma_harumasa,        
    "Hailstorm Shrine": efecto_arma_miyabi,           
    "Heartstring Nocturne": efecto_arma_heartstring,
    "Bashful Demon": efecto_arma_bashful,
    "Demara Battery Mark II": efecto_arma_demara,
    "Electro-Lip Gloss": efecto_arma_electro_lip,
    "Housekeeper": efecto_arma_housekeeper,
    "Drill Rig - Red Axis": efecto_arma_drill_rig,
    "Cannon Rotor": efecto_arma_cannon_rotor,
    "Gilded Blossom": efecto_arma_street_superstar, 
    "Big Cylinder": lambda s,r,n,st: {'Reduccion_Daño': [7.5, 8.5, 9.5, 10.5, 12.0][r-1]},
    "Bunny Band": lambda s,r,n,st: {KEYS_LOGICA["HP_PCT"]: [8, 9.2, 10.4, 11.6, 12.8][r-1], KEYS_LOGICA["ATK_PCT"]: [10, 11.5, 13, 14.5, 16][r-1]},
    "Original Transmorpher": lambda s,r,n,st: {KEYS_LOGICA["HP_PCT"]: [8,9,10,11,12.5][r-1], KEYS_LOGICA["IMPACT"]: [10,11.5,13,14.5,16][r-1]},
    "Grill O'Wisp": lambda s,r,n,st: {KEYS_LOGICA["DMG_ELEMENTAL"]: [15,17.25,19.5,21.75,24][r-1]},
    "Marcato Desire": lambda s,r,n,st: {KEYS_LOGICA["ATK_PCT"]: [6,6.9,7.8,8.7,9.6][r-1] * (2 if st else 1)},
    "Box Cutter": lambda s,r,n,st: {KEYS_LOGICA["DMG_ELEMENTAL"]: [15,17.3,19.5,21.8,24][r-1]},
    "Peacekeeper - Specialized": efecto_arma_peacekeeper,
    "Precious Fossilized Core": efecto_arma_precious_core,
    "Rainforest Gourmet": efecto_arma_rainforest,
    "Roaring Ride": efecto_arma_roaring_ride,
    "Six Shooter": efecto_arma_six_shooter,
    "Slice of Time": efecto_arma_slice_time,
    "Spring Embrace": efecto_arma_spring_embrace,
    "Starlight Engine": efecto_arma_starlight_engine_real,
    "Steam Oven": efecto_arma_steam_oven,
    "Street Superstar": efecto_arma_street_superstar_real, 
    "The Vault": efecto_arma_the_vault,
    "Unfettered Fruition": efecto_arma_unfettered,
    "Weeping Gemini": efecto_arma_weeping_gemini,
    "Flight of Fancy": efecto_arma_flight_of_fancy,
    "Qingming Birdcage": efecto_arma_qingming,
    "Kraken's Cradle": efecto_arma_kraken,
    "Practiced Perfection": efecto_arma_practiced,
    "Spectral Gaze": efecto_arma_spectral,
    "Yesterday Calls": efecto_arma_yesterday,
    "Dreamlit Hearth": efecto_arma_dreamlit,
    "Elegant Vanity": efecto_arma_elegant,
}
