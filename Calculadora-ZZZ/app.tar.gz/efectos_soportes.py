def _verificar_activacion(datos_equipo, req_rol=None, req_elemento=None, req_faccion=None):
    """
    Función auxiliar para verificar si se activa la pasiva adicional del soporte
    basada en la composición del equipo.
    """
    if not datos_equipo:
        return False
        
    roles = datos_equipo.get("roles", [])
    elementos = datos_equipo.get("elementos", [])
    facciones = datos_equipo.get("facciones", [])
    
    if req_rol:
        for r in roles:
            if any(valido in r.lower() for valido in req_rol):
                return True
                
    if req_elemento:
        for e in elementos:
            if any(valido in e.lower() for valido in req_elemento):
                return True
                
    if req_faccion:
        for f in facciones:
            if any(valido in f.lower() for valido in req_faccion):
                return True
                
    return False

def soporte_astra_yao(resultados, **kwargs):
    """ 
    Astra Yao: 35% del ATK propio del soporte se transfiere. Max 1200.
    """
    stats = kwargs.get('stats', {})
    atk_soporte = stats.get("Ataque", 0.0)

    buff_calculado = atk_soporte * 0.35
    if buff_calculado > 1200.0:
        buff_calculado = 1200.0
        
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + buff_calculado
    
    return f"ATK +{buff_calculado:.0f} (35% de {atk_soporte:.0f})"

def soporte_burnice(resultados, **kwargs):
    """
    Burnice:
    - Pasiva: Prolonga quemadura (Info).
    - Si se activa: +65% Anomaly Buildup (Acumulación).
    """
    datos_equipo = kwargs.get('datos_equipo')
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_rol=["anomalia"], 
        req_faccion=["hijos de calidón"]
    )
    
    msg = "Burnice (Solo Info)"
    if activado:
        resultados["Bono_Acumulación"] = resultados.get("Bono_Acumulación", 0.0) + 65.0
        msg = "+65% Buildup & +3s Burn"
        
    return msg

def soporte_caesar(resultados, **kwargs):
    """
    Caesar:
    - Buff Activo (Escudo): ATK +1000.
    - Pasiva: +25% Daño a todo el equipo (Si hay Físico/Hijos de Calidón/Defensive Assist).
    """
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + 1000.0
    excepciones_evasivas = ["astra yao", "zhu yuan", "grace", "rina", "pulchra", "billy"]
    datos_equipo = kwargs.get('datos_equipo')
    req_faccion = ["hijos de calidón"]
    activado = True 
    if datos_equipo:
        facciones = datos_equipo.get("facciones", [])
        nombres = datos_equipo.get("nombres", [])
        
        for f in facciones:
            if any(valido in f for valido in req_faccion):
                activado = True
                break

        if not activado:
            for nombre in nombres:
                n_norm = str(nombre).lower().strip()
                
                es_evasivo = any(exc in n_norm for exc in excepciones_evasivas)             
                if not es_evasivo:
                    activado = True
                    break

    if activado:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 25.0
        return "ATK +1000, DMG +25%"
    
    return "ATK +1000"

def soporte_dialyn(resultados, **kwargs):
    """ +30% Stun DMG Multiplier (Queja Maliciosa) """
    resultados["Stun_DMG_Multiplier"] = resultados.get("Stun_DMG_Multiplier", 0.0) + 30.0
    return "Stun DMG +30% (Queja Maliciosa)"

def soporte_ju_fufu(resultados, **kwargs):
    """ 
    Ju Fufu:
    - Base: 20% Crit DMG.
    - Extra: (ATK - 2800) // 100 * 5%. Max +30%.
    - Buff Ulti: +40% DMG.
    """
    stats = kwargs.get('stats', {})
    atk_soporte = stats.get("Ataque", 0.0)
    
    crit_dmg_total = 20.0
    if atk_soporte >= 2800.0:
        exceso = atk_soporte - 2800.0
        pasos = int(exceso // 100)
        extra = pasos * 5.0
        if extra > 30.0: extra = 30.0
        crit_dmg_total += extra

    resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + crit_dmg_total
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 40.0
    
    return f"Crit DMG +{crit_dmg_total:.1f}%, DMG +40%"

def soporte_lighter(resultados, **kwargs):
    """
    Lighter:
    - Debuff: -15% RES Fuego/Hielo (Siempre).
    - Pasiva: +DMG Fuego/Hielo al equipo.
      * Base: 1.25% por stack.
      * Escalado: Si Impacto > 170 -> +0.25% por stack cada 10 pts de Impacto.
      * Max: 20 Stacks. Tope total: 75%.
    """
    stats = kwargs.get('stats', {})
    datos_equipo = kwargs.get('datos_equipo')
    elemento_dps = str(kwargs.get('elemento_dps', '')).lower()
    
    resultados["Resistencia_Hielo"] = resultados.get("Resistencia_Hielo", 0.0) - 15.0
    resultados["Resistencia_Fuego"] = resultados.get("Resistencia_Fuego", 0.0) - 15.0
    
    msg = "RES Hielo/Fuego -15%"
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_rol=["atacante"], 
        req_faccion=["hijos de calidón"]
    )
    
    es_fuego_hielo = any(x in elemento_dps for x in ["fuego", "hielo"])
    
    if activado and es_fuego_hielo:
        impacto = stats.get("Impacto", 0.0)
        
        base_stack = 1.25
        extra_stack = 0.0
        
        if impacto > 170:
            exceso = impacto - 170
            pasos = int(exceso / 10)
            extra_stack = pasos * 0.25
            
        valor_por_stack = base_stack + extra_stack
        
        total_buff = valor_por_stack * 20.0
        
        if total_buff > 75.0: 
            total_buff = 75.0
            
        resultados["Daño_elemental"] = resultados.get("Daño_elemental", 0.0) + total_buff
        msg += f", +{total_buff:.1f}% Fire/Ice DMG (Imp: {impacto:.0f})"
        
    return msg

def soporte_lucia(resultados, **kwargs):

    resultados["Puntos_Vida_%"] = resultados.get("Puntos_Vida_%", 0.0) + 5.0
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 20.0
    
    stats = kwargs.get('stats', {})
    hp_soporte = stats.get("Puntos_de_Vida", stats.get("Puntos_Vida", 0.0))
    datos_equipo = kwargs.get('datos_equipo')
    
    hp_calculo = 24000.0 if hp_soporte > 24000.0 else hp_soporte
    base_sheer = 12.0
    bloques = int(hp_calculo / 200)
    extra_sheer = bloques * 7.4
    
    val_sheer_potencial = base_sheer + extra_sheer
    if val_sheer_potencial > 900.0: val_sheer_potencial = 900.0
    
    req_rol = ["ruptura", "aturdidor"]
    activado = False

    if datos_equipo:
        roles = datos_equipo.get("roles", [])
        for r in roles:
            if any(valido in str(r).lower() for valido in req_rol):
                activado = True
                break
    
    valor_a_aplicar = 0.0
    msg_estado = ""

    if activado:
        valor_a_aplicar = val_sheer_potencial
        msg_estado = "(Activo)"
    else:
        msg_estado = f"(INACTIVO: Potencial {val_sheer_potencial:.0f})"
    
    resultados["Sheer_force"] = resultados.get("Sheer_force", 0.0) + valor_a_aplicar
    
    return f"HP +5%, DMG +20%, Sheer Force +{valor_a_aplicar:.0f} {msg_estado} (HP: {hp_soporte:.0f})"

def soporte_lucy(resultados, **kwargs):
    """
    Lucy:
    - Buff Activo: Otorga ATK (Cheers!). 
      (Formula aprox: 13.8% + flat, simplificado a un valor base o lectura de stats).
      Asumiremos un valor fijo potente o dependiente de su ATK si se pasa.
    - Pasiva: Hereda criticos a sus cerdos (No afecta DPS ppal).
    """
    stats = kwargs.get('stats', {})
    atk_soporte = stats.get("Ataque", 0.0)
    
    buff_atk = atk_soporte * 0.226
    if buff_atk > 600: buff_atk = 600
    
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + buff_atk
    return f"ATK +{buff_atk:.0f} (Lucy)"

def soporte_lycaon(resultados, **kwargs):
    """
    Lycaon:
    - Pasiva: RES Hielo -25%.
    - Adicional: +35% Stun Multiplier (Si enemigo aturdido).
    """
    datos_equipo = kwargs.get('datos_equipo')
    estado_enemigo = kwargs.get('estado_enemigo', 'Normal')
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["hielo"], 
        req_faccion=["servicios domésticos victoria"]
    )
    
    resultados["Resistencia_Hielo"] = resultados.get("Resistencia_Hielo", 0.0) - 25.0
    msg = "RES Hielo -25%"
    
    if activado and estado_enemigo == "Stun_Boss":
        resultados["Stun_DMG_Multiplier"] = resultados.get("Stun_DMG_Multiplier", 0.0) + 35.0
        msg += ", Stun Mult +35%"
        
    return msg

def soporte_nicole(resultados, **kwargs):
    """
    Nicole:
    - Buff Activo: DEF -40% (Debuff).
    - Pasiva: +25% Daño Etereo (Si Etereo/Liebres).
    """
    datos_equipo = kwargs.get('datos_equipo')
    elemento_dps = str(kwargs.get('elemento_dps', '')).lower()
    
    resultados["Reduccion_DEF_enemigo"] = resultados.get("Reduccion_DEF_enemigo", 0.0) + 40.0
    msg = "DEF -40%"
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["etereo"], 
        req_faccion=["liebres astutas"]
    )
    
    if activado and ("etereo" in elemento_dps or "ether" in elemento_dps):
        resultados["Daño_elemental"] = resultados.get("Daño_elemental", 0.0) + 25.0
        msg += ", +25% Ether DMG"
        
    return msg

def soporte_orphie_magus(resultados, **kwargs):
    """
    Orphie & Magus:
    - Buff ATK basado en ER.
    """
    stats = kwargs.get('stats', {})
    er_soporte = stats.get("Recuperación_energía", 1.56)
    
    buff_atk = 280.0
    if er_soporte >= 1.6:
        exceso = er_soporte - 1.6
        pasos = int((exceso + 0.0001) / 0.1) 
        extra = pasos * 20.0
        buff_atk += extra

    if buff_atk > 700.0:
        buff_atk = 700.0
        
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + buff_atk
    return f"ATK +{buff_atk:.0f} (ER: {er_soporte:.2f})"

def soporte_pan_yinhu(resultados, **kwargs):
    """
    Pan Yinhu:
    - Buff Activo: Sheer Force.
    - Pasiva: +20% Daño recibido por enemigo (Vulnerabilidad).
    """
    stats = kwargs.get('stats', {})
    datos_equipo = kwargs.get('datos_equipo')
    
    atk_soporte = stats.get("Ataque", 0.0)
    buff_sheer = atk_soporte * 0.18
    if buff_sheer > 540.0: buff_sheer = 540.0
    resultados["Sheer_force"] = resultados.get("Sheer_force", 0.0) + buff_sheer
    
    activado = _verificar_activacion(datos_equipo, req_rol=["ruptura"], req_faccion=["yunkui"])
    
    msg = f"Sheer Force +{buff_sheer:.0f}"
    
    if activado:
        if kwargs.get("debuff_qi_activo", True): 
            resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 20.0
            msg += ", +20% Dmg Taken"
            
    return msg

def soporte_piper(resultados, **kwargs):
    """
    Piper:
    - Pasiva: +18% Daño al equipo (Si > 20 stacks).
    """
    datos_equipo = kwargs.get('datos_equipo')
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["físico"], 
        req_faccion=["hijos de calidón"]
    )
    
    if activado:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 18.0
        return "DMG +18% (Power Stacks)"
        
    return "Piper (Sin condiciones pasiva)"

def soporte_qingyi(resultados, **kwargs):
    """
    Qingyi:
    - Debuff: +80% Stun DMG Multiplier (Subyugación).
    - Pasiva: +ATK basado en Impacto (Self only, no se transfiere usualmente).
    """
    resultados["Stun_DMG_Multiplier"] = resultados.get("Stun_DMG_Multiplier", 0.0) + 80.0
    return "Stun Mult +80% (20 Stacks)"

def soporte_rina(resultados, **kwargs):
    """
    Rina:
    - Buff Activo: PEN Ratio.
    - Pasiva: +10% Daño Eléctrico (Si enemigo Shocked).
    """
    stats = kwargs.get('stats', {})
    datos_equipo = kwargs.get('datos_equipo')
    elemento_dps = str(kwargs.get('elemento_dps', '')).lower()
    
    pen_soporte = stats.get("Tasa_de_Perforación", 0.0)
    bono = (pen_soporte * 0.25) + 12.0
    if bono > 30.0: bono = 30.0
    resultados["Tasa_de_Perforación"] = resultados.get("Tasa_de_Perforación", 0.0) + bono
    
    msg = f"PEN +{bono:.1f}%"
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["electrico"], 
        req_faccion=["servicios domésticos victoria"]
    )
    
    en_shock = kwargs.get("enemigo_shocked", True)
    
    if activado and en_shock and ("electrico" in elemento_dps or "eléctrico" in elemento_dps):
        resultados["Daño_elemental"] = resultados.get("Daño_elemental", 0.0) + 10.0
        msg += ", +10% Elec DMG"
        
    return msg

def soporte_seed(resultados, **kwargs):
    """
    Seed:
    - Buff Activo: ATK +1000, Crit DMG +30%, DMG +25%.
    """
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + 1000.0
    resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + 30.0
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 25.0
    
    return "ATK +1000, CD +30%, DMG +25%"

def soporte_seth(resultados, **kwargs):
    """
    Seth:
    - Buff Activo: +100 AP (Escudo).
    - Pasiva: -20% Resistencia a Anomalía (Debuff).
    """
    datos_equipo = kwargs.get('datos_equipo')
    
    resultados["Maestría_Anomalía"] = resultados.get("Maestría_Anomalía", 0.0) + 100.0
    msg = "AP +100"
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["electrico"], 
        req_faccion=["n.e.p.s."]
    )
    
    if activado and kwargs.get("debuff_seth_activo", True):
        resultados["Red_Res_Buildup"] = 20.0
        msg += ", -20% Enemy Buildup Res"
        
    return msg

def soporte_soukaku(resultados, **kwargs):
    """
    Soukaku:
    - Buff Activo (Vortex): ATK +1000 (Max).
    - Pasiva: +20% Ice DMG.
    """
    stats = kwargs.get('stats', {})
    datos_equipo = kwargs.get('datos_equipo')
    elemento_dps = str(kwargs.get('elemento_dps', '')).lower()
    
    atk_soporte = stats.get("Ataque", 0.0)
    buff = atk_soporte * 0.40
    if buff > 1000.0: buff = 1000.0
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + buff
    
    msg = f"ATK +{buff:.0f}"
    
    activado = _verificar_activacion(
        datos_equipo, 
        req_elemento=["hielo"], 
        req_faccion=["sección 6"]
    )
    
    if activado and ("hielo" in elemento_dps):
        if kwargs.get("buff_soukaku_activo", True):
            resultados["Daño_elemental"] = resultados.get("Daño_elemental", 0.0) + 20.0
            msg += ", +20% Ice DMG"
            
    return msg

def soporte_trigger(resultados, **kwargs):
    """
    Trigger:
    - Aplica +35% al Multiplicador de Daño de Aturdimiento (Debuff).
    """
    resultados["Unstun_DMG_Multiplier"] = resultados.get("Unstun_DMG_Multiplier", 0.0) + 35.0
    return "Stun Mult +35% (Debuff)"

def soporte_vivian(resultados, **kwargs):
    """
    Vivian:
    - Prophecy: DoT 55% ATK.
    - Abloom: Detecta el elemento del DPS y calcula el bono específico.
    - Pasiva: +12% Corruption DMG (Si Etereo).
    """
    stats = kwargs.get('stats', {})
    datos_equipo = kwargs.get('datos_equipo')
    elemento_dps = str(kwargs.get('elemento_dps', '')).lower()
    
    atk_soporte = stats.get("Ataque", 0.0)
    ap_soporte = stats.get("Maestría_de_Anomalía", 0.0)
    
    dano_dot = atk_soporte * 0.55
    resultados["Vivian_Prophecy_Tick"] = resultados.get("Vivian_Prophecy_Tick", 0.0) + dano_dot
    
    ratios = {
        "eter": 6.15,   "etereo": 6.15, "ether": 6.15,
        "fuego": 8.00,  "fire": 8.00,
        "electrico": 3.20, "eléctrico": 3.20, "electric": 3.20,
        "hielo": 1.08,  "ice": 1.08,
        "fisico": 0.75, "físico": 0.75, "physical": 0.75
    }
    
    ratio_seleccionado = 0.0
    nombre_elemento = "Desconocido"
    
    for clave, valor in ratios.items():
        if clave in elemento_dps:
            ratio_seleccionado = valor
            nombre_elemento = clave.capitalize()
            break
            
    texto_abloom = ""
    if ratio_seleccionado > 0:
        bloques_ap = ap_soporte / 10.0
        bono_final = bloques_ap * ratio_seleccionado
        resultados["Bono_Abloom_Final"] = resultados.get("Bono_Abloom_Final", 0.0) + bono_final
        texto_abloom = f", Abloom ({nombre_elemento}) +{bono_final:.2f}%"
    else:
        texto_abloom = ", Abloom (Sin Elemento)"

    activado = _verificar_activacion(datos_equipo, req_rol=["anomalia"], req_atributo=["etereo"])
    if activado and "etereo" in elemento_dps:
        resultados["Bono_Daño_Anomalia"] = resultados.get("Bono_Daño_Anomalia", 0.0) + 12.0
        texto_abloom += ", +12% Corruption"

    return f"Prophecy {dano_dot:.0f}{texto_abloom}"

def soporte_yuzuha(resultados, **kwargs):
    """
    Yuzuha (Tanuki Wish):
    - Otorga ATK Plano (40% del ATK de Yuzuha, Max 1200).
    - Otorga +15% de Daño.
    """
    stats = kwargs.get('stats', {})
    atk_soporte = stats.get("Ataque", 0.0)
    
    buff_atk = atk_soporte * 0.40
    
    if buff_atk > 1200.0:
        buff_atk = 1200.0
        
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + buff_atk
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 15.0
    
    return f"Tanuki Wish: ATK +{buff_atk:.0f}, DMG +15%"

def soporte_zhao(resultados, **kwargs):
    """
    Zhao Soporte (Ether Veil):
    - Otorga +1000 ATK Plano a todo el equipo.
    - Otorga +5% HP Max a todo el equipo.
    - Pasiva: +10-40% DMG (Según HP).
    """
    resultados["Ataque"] = resultados.get("Ataque", 0.0) + 1000.0
    resultados["Puntos_Vida_%"] = resultados.get("Puntos_Vida_%", 0.0) + 5.0

    stats = kwargs.get('stats', {})
    hp_max = stats.get("Puntos_de_Vida", 0.0)
    
    base_bonus = 10.0
    extra_bonus = 0.0
    if hp_max > 15000:
        exceso = hp_max - 15000
        stacks = int(exceso / 400)
        extra_bonus = stacks * 1.0
        
    total_bonus = base_bonus + extra_bonus
    if total_bonus > 40.0: total_bonus = 40.0
    
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + total_bonus
    
    return f"Ether Veil: ATK +1000, HP +5%, DMG +{total_bonus:.1f}%"

MAPA_SOPORTES_AGENTES = {
    "astra yao": soporte_astra_yao,
    "burnice": soporte_burnice,
    "caesar": soporte_caesar,
    "dialyn": soporte_dialyn,
    "ju fufu": soporte_ju_fufu,
    "lighter": soporte_lighter,
    "lucia": soporte_lucia,
    "lucy": soporte_lucy,
    "lycaon": soporte_lycaon,
    "nicole": soporte_nicole,
    "orphie & magus": soporte_orphie_magus,
    "pan yinhu": soporte_pan_yinhu,
    "piper": soporte_piper,
    "qingyi": soporte_qingyi,
    "rina": soporte_rina,
    "seed": soporte_seed,
    "seth": soporte_seth,
    "soukaku": soporte_soukaku,
    "trigger": soporte_trigger,
    "vivian": soporte_vivian,
    "yuzuha": soporte_yuzuha,
    "zhao": soporte_zhao,
}

###======================
# --- SETS DE SOPORTE ---
###======================

def set_swing_jazz(resultados, **kwargs):
    """ +15% Daño """
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 15.0
    return "Daño +15%"

def set_proto_punk(resultados, **kwargs):
    """ +15% Daño """
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 15.0
    return "Daño +15%"

def set_astral_voice(resultados, **kwargs):
    """ +24% Daño """
    resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 24.0
    return "Daño +24%"

def set_king_of_summit(resultados, **kwargs):
    """ +30% Crit DMG (Solo si es Aturdidor) """
    tipo = kwargs.get("tipo_agente", "").lower()
    if "aturdidor" in tipo or "stun" in tipo:
        resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + 30.0
        return "Crit DMG +30%"
    return None

def set_moonlight_lullaby(resultados, **kwargs):
    """ +18% Daño (Solo si es Soporte) """
    tipo = kwargs.get("tipo_agente", "").lower()
    if "soporte" in tipo or "support" in tipo:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + 18.0
        return "Daño +18%"
    return None

MAPA_SOPORTES_SETS = {
    "jazz oscilante": set_swing_jazz,
    "proto punk": set_proto_punk,
    "voz astral": set_astral_voice,
    "monarca del pináculo": set_king_of_summit,
    "nana a la luz cenicienta": set_moonlight_lullaby,
}

###=========================
# --- W-Engines Soporte ---
###=========================

def wengine_Kaboom_the_Cannon(resultados, **kwargs):
    """
    Kaboom the Cannon:
    - Al golpear, ATK equipo +2.5/2.8/3.2/3.6/4%.
    - Max 4 Stacks.
    """
    ref = kwargs.get('refinamiento', 1)
    stacks = kwargs.get('stacks', 0)
    
    valores_base = [2.5, 2.8, 3.2, 3.6, 4.0]
    
    indice = ref - 1
    if indice < 0: indice = 0
    if indice > 4: indice = 4
    
    valor_por_stack = valores_base[indice]
    buff_total = valor_por_stack * stacks
    
    resultados["Ataque_%"] = resultados.get("Ataque_%", 0.0) + buff_total
    
    return f"Kaboom the Cannon: ATK +{buff_total:.1f}% ({stacks} stacks)"

def wengine_unfettered_game_ball(resultados, **kwargs):
    """
    Unfettered Game Ball (Bola de Juego Sin Restricciones):
    - Al activar Contraataque de Atributo -> CRIT Rate +12/13.5/15.5/17.5/20% al equipo.
    - Duración 12s. No se apila.
    - Lógica Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [12.0, 13.5, 15.5, 17.5, 20.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_bono = valores[idx]
    
    buff_aplicado = 0.0
    estado = ""
    
    if stacks > 0:
        buff_aplicado = valor_bono
        resultados["Probabilidad_de_crítico"] = resultados.get("Probabilidad_de_crítico", 0.0) + buff_aplicado
        estado = "(Activo)"
    else:
        estado = "(Inactivo)"

    return f"Unfettered Game Ball: Crit Rate +{buff_aplicado:.1f}% {estado}"

def wengine_the_vault(resultados, **kwargs):
    """
    The Vault (La Bóveda):
    - Trigger: Daño Etéreo (EX/Chain/Ult).
    - Efecto: Aumenta el Daño (DMG) de todo el equipo contra el objetivo.
    - Valores: 15/17.5/20/22/24%.
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [15.0, 17.5, 20.0, 22.0, 24.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_bono = valores[idx]
    
    buff_aplicado = 0.0
    estado = "(Inactivo)"
    
    if stacks > 0:
        buff_aplicado = valor_bono
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_aplicado
        estado = "(Activo)"

    return f"The Vault: DMG +{buff_aplicado:.1f}% {estado}"

def wengine_bashful_demon(resultados, **kwargs):
    """
    Bashful Demon (Demonio Tímido):
    - Al usar Especial EX -> ATK equipo +2/2.3/2.6/2.9/3.2%.
    - Max 4 Stacks. Duración 12s.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [2.0, 2.3, 2.6, 2.9, 3.2]
    
    idx = max(0, min(ref - 1, 4))
    valor_por_stack = valores[idx]
    stacks_reales = min(stacks, 4)
    
    buff_total = valor_por_stack * stacks_reales
    
    estado = "(Inactivo)"
    if buff_total > 0:
        resultados["Ataque_%"] = resultados.get("Ataque_%", 0.0) + buff_total
        estado = f"({stacks_reales} stacks)"

    return f"Bashful Demon: ATK +{buff_total:.1f}% {estado}"

def wengine_slice_of_time(resultados, **kwargs):
    """
    Slice of Time:
    - Genera Decibelios y Energía al activar Esquiva/EX/Assist/Chain.
    - Como es generación de recursos (no stats de daño), solo mostramos la info.
    - Stacks: 0 = Inactivo, >=1 = Activo (Muestra los valores).
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    idx = max(0, min(ref - 1, 4))

    db_dodge  = [20.0, 23.0, 26.0, 29.0, 32.0]
    db_special= [25.0, 28.5, 32.0, 35.5, 40.0]
    db_assist = [30.0, 34.5, 39.0, 43.5, 48.0]
    db_chain  = [35.0, 40.0, 45.0, 50.0, 55.0]
    
    energy_gen = [0.7, 0.8, 0.9, 1.0, 1.1]

    estado = "(Inactivo)"
    msg_info = ""

    if stacks > 0:
        val_db_min = db_dodge[idx]
        val_db_max = db_chain[idx]
        val_energy = energy_gen[idx]
        
        msg_info = f"Decibeles +{val_db_min:g}-{val_db_max:g} / Energy +{val_energy:g}"
        estado = "(Activo)"

    if stacks == 0:
        return f"Slice of Time: {estado}"
        
    return f"Slice of Time: {msg_info} {estado}"

def wengine_weeping_cradle(resultados, **kwargs):
    """
    Weeping Cradle (Cuna Llorosa):
    - Efecto 1: Regeneración de Energía (Pasiva del portador).
    - Efecto 2 (Team): Daño Base +10-20%.
    - Efecto 3 (Ramp-up): Aumenta 1.7-3.3% cada 0.5s hasta un tope.
    - Lógica: Si Stacks > 0, asumimos el TIEMPO MÁXIMO (Bono Base + Bono Adicional Máximo).
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    base_dmg = [10.0, 12.5, 15.0, 17.5, 20.0]
    max_add_dmg = [10.2, 12.0, 15.0, 18.0, 19.8]
    
    idx = max(0, min(ref - 1, 4))
    
    total_buff = base_dmg[idx] + max_add_dmg[idx]
    
    estado = "(Inactivo)"
    
    if stacks > 0:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + total_buff
        estado = "(Activo - Max Time)"

    return f"Weeping Cradle: DMG +{total_buff:.1f}% {estado}"

def wengine_metanukimorphosis(resultados, **kwargs):
    """
    Metanukimorphosis:
    - Efecto Equipo: Al golpear con Aftershock -> Tasa de Anomalía (AP) +60/69/78/87/98.
    - (El buff de Maestría es propio del portador, no se suma al DPS).
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [60.0, 69.0, 78.0, 87.0, 98.0]
    
    idx = max(0, min(ref - 1, 4))
    val_ap = valores[idx]
    
    estado = "(Inactivo)"
    buff_aplicado = 0.0
    
    if stacks > 0:
        buff_aplicado = val_ap
        resultados["Tasa_de_Anomalía"] = resultados.get("Tasa_de_Anomalía", 0.0) + buff_aplicado
        estado = "(Activo)"

    return f"Metanukimorphosis: AP +{buff_aplicado:.0f} {estado}"

def wengine_elegant_vanity(resultados, **kwargs):
    """
    Elegant Vanity:
    - Parte 1: El portador gana energía en Asistencias (No afecta stats del DPS directamente).
    - Parte 2: Al gastar 25 energía -> Daño equipo +10/11.5/13/14.5/16%.
    - Max 2 Stacks.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [10.0, 11.5, 13.0, 14.5, 16.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_por_stack = valores[idx]
    
    stacks_reales = min(stacks, 2)
    
    buff_total = valor_por_stack * stacks_reales
    
    estado = "(Inactivo)"
    if buff_total > 0:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_total
        estado = f"({stacks_reales} stacks)"

    return f"Elegant Vanity: DMG +{buff_total:.1f}% {estado}"

def wengine_dreamlit_hearth(resultados, **kwargs):
    """
    Dreamlit Hearth (Hogar Onírico):
    - Efecto: Al activar Velo Etéreo -> Daño +25-40% y Max HP +15-24% al equipo.
    - Duración 45s (Prácticamente permanente).
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_dmg = [25.0, 28.8, 32.5, 36.3, 40.0]
    vals_hp = [15.0, 17.3, 19.5, 21.8, 24.0]
    
    idx = max(0, min(ref - 1, 4))
    
    buff_dmg = vals_dmg[idx]
    buff_hp = vals_hp[idx]
    
    estado = "(Inactivo)"
    
    if stacks > 0:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_dmg
        resultados["Puntos_Vida_%"] = resultados.get("Puntos_Vida_%", 0.0) + buff_hp
        
        estado = "(Activo)"

    return f"Dreamlit Hearth: DMG +{buff_dmg:.1f}% / HP +{buff_hp:.1f}% {estado}"

def wengine_reverb_mark_i(resultados, **kwargs):
    """
    (Reverb) Mark I:
    - Al usar Especial EX -> Impacto equipo +8/9/10/11/12% por 10s.
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [8.0, 9.0, 10.0, 11.0, 12.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_bono = valores[idx]
    
    estado = "(Inactivo)"
    buff_aplicado = 0.0
    
    if stacks > 0:
        buff_aplicado = valor_bono
        resultados["Impacto"] = resultados.get("Impacto", 0.0) + buff_aplicado
        estado = "(Activo)"

    return f"(Reverb) Mark I: Impacto +{buff_aplicado:.1f}% {estado}"

def wengine_reverb_mark_ii(resultados, **kwargs):
    """
    (Reverb) Mark II:
    - Trigger: Especial EX o Ataque en Cadena.
    - Efecto: Maestría de Anomalía (AM) y Tasa de Anomalía (AP) +10/12/13/15/16.
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [10.0, 12.0, 13.0, 15.0, 16.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_bono = valores[idx]
    
    estado = "(Inactivo)"
    buff_aplicado = 0.0
    
    if stacks > 0:
        buff_aplicado = valor_bono
        
        resultados["Maestría_Anomalía"] = resultados.get("Maestría_Anomalía", 0.0) + buff_aplicado
        resultados["Tasa_de_Anomalía"] = resultados.get("Tasa_de_Anomalía", 0.0) + buff_aplicado
        
        estado = "(Activo)"

    return f"(Reverb) Mark II: AM/AP +{buff_aplicado:.0f} {estado}"

def wengine_reverb_mark_iii(resultados, **kwargs):
    """
    (Reverb) Mark III:
    - Trigger: Chain Attack o Ultimate.
    - Efecto: ATK equipo +8/9/10/11/12% por 10s.
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    valores = [8.0, 9.0, 10.0, 11.0, 12.0]
    
    idx = max(0, min(ref - 1, 4))
    valor_bono = valores[idx]
    
    estado = "(Inactivo)"
    buff_aplicado = 0.0
    
    if stacks > 0:
        buff_aplicado = valor_bono
        resultados["Ataque_%"] = resultados.get("Ataque_%", 0.0) + buff_aplicado
        estado = "(Activo)"

    return f"(Reverb) Mark III: ATK +{buff_aplicado:.1f}% {estado}"

def wengine_tusks_of_fury(resultados, **kwargs):
    """
    Tusks of Fury (Colmillos de Furia):
    - Parte 1: Escudo del portador (No relevante para daño del DPS).
    - Parte 2: Al activar Interrupt/Perfect Dodge -> Daño +18-36% y Aturdimiento (Daze) +12-24% al equipo.
    - Stacks: 0 = Inactivo, >=1 = Activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_dmg = [18.0, 22.5, 27.0, 31.5, 36.0]
    vals_daze = [12.0, 15.0, 18.0, 21.0, 24.0]
    
    idx = max(0, min(ref - 1, 4))
    
    buff_dmg = vals_dmg[idx]
    buff_daze = vals_daze[idx]
    
    estado = "(Inactivo)"
    
    if stacks > 0:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_dmg
        resultados["Aturdimiento"] = resultados.get("Aturdimiento", 0.0) + buff_daze
        
        estado = "(Activo)"

    return f"Tusks of Fury: DMG +{buff_dmg:.1f}% / Daze +{buff_daze:.1f}% {estado}"

def wengine_half_sugar_bunny(resultados, **kwargs):
    """
    Half-Sugar Bunny:
    - Pasiva 1: ATK +10-16% y Max HP +10-16% al equipo (Permanente).
    - Pasiva 2: Al activar Ether Veil -> CRIT DMG +30-48% al equipo.
    - Lógica Stacks: 
        0 = Inactivo.
        >=1 = Activo (Aplica ambos buffs asumiendo combate activo).
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_stat = [10.0, 11.5, 13.0, 14.5, 16.0]
    vals_cd = [30.0, 34.5, 39.0, 43.5, 48.0]
    
    idx = max(0, min(ref - 1, 4))
    
    buff_stat = vals_stat[idx]
    buff_cd = vals_cd[idx]
    
    estado = "(Inactivo)"
    
    if stacks > 0:
        resultados["Ataque_%"] = resultados.get("Ataque_%", 0.0) + buff_stat  
        resultados["Puntos_Vida_%"] = resultados.get("Puntos_Vida_%", 0.0) + buff_stat
        resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + buff_cd
        
        estado = "(Activo)"

    return f"Half-Sugar Bunny: ATK/HP +{buff_stat:.1f}% / CD +{buff_cd:.1f}% {estado}"

def wengine_blazing_laurel(resultados, **kwargs):
    """
    Blazing Laurel:
    - Efecto 1: Impacto para el portador (No afecta al DPS directamente).
    - Efecto 2 (Wilt): CRIT DMG +1.5-2.4% por stack al golpear con Fuego/Hielo.
    - "Mejor de los casos": Asumimos 20 stacks siempre que esté activo.
    - Restricción: Solo aplica si el DPS es de Fuego o Hielo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks_ui = int(kwargs.get('stacks', 0))
    except: stacks_ui = 0
    
    val_stack = [1.5, 1.72, 1.95, 2.17, 2.4]
    
    idx = max(0, min(ref - 1, 4))
    
    buff_total = val_stack[idx] * 20.0
    
    estado = "(Inactivo)"
    aplicado = False
    
    if stacks_ui > 0:
        elem_dps = str(kwargs.get('elemento_dps', '')).lower()
        
        validos = ["fuego", "hielo"]
        
        if any(v in elem_dps for v in validos):
            resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + buff_total
            estado = f"(Activo: 20 Stacks - {elem_dps.capitalize()})"
            aplicado = True
        else:
            estado = f"(Inactivo: DPS es {elem_dps}, requiere Fuego/Hielo)"

    val_msg = buff_total if aplicado else 0.0
    return f"Blazing Laurel: Crit DMG +{val_msg:.1f}% {estado}"

def wengine_ice_jade_teapot(resultados, **kwargs):
    """
    Ice-Jade Teapot (Tetera de Jade Helado):
    - Efecto 1 (Propio): Impacto +0.7-1.4% por stack (Max 30).
    - Efecto 2 (Equipo): Si Stacks >= 15 -> Daño Equipo +20-32%.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_imp_stack = [0.7, 0.88, 1.05, 1.22, 1.4]
    vals_team_dmg = [20.0, 23.0, 26.0, 29.0, 32.0]
    
    idx = max(0, min(ref - 1, 4))
    
    stacks_reales = min(stacks, 30)
    
    buff_imp_propio = vals_imp_stack[idx] * stacks_reales
    resultados["Impacto"] = resultados.get("Impacto", 0.0) + buff_imp_propio
    
    buff_dmg_team = 0.0
    estado = "(Inactivo < 15)"
    
    if stacks_reales >= 15:
        buff_dmg_team = vals_team_dmg[idx]
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_dmg_team
        estado = "(Activo)"

    return f"Ice-Jade Teapot: DMG Team +{buff_dmg_team:.1f}% / Imp (Self) +{buff_imp_propio:.1f}% {estado}"

def wengine_roaring_furnace(resultados, **kwargs):
    """
    Roaring Fur-nace (Horno Rugiente):
    - Parte 1: Daze propio (Ignorado para stats del DPS).
    - Parte 2: Al usar Chain/Ult de Fuego -> Daño Equipo +10-16%.
    - Max 2 Stacks.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_dmg = [10.0, 11.5, 13.0, 14.5, 16.0]
    idx = max(0, min(ref - 1, 4))
    
    stacks_reales = min(stacks, 2)
    buff_total = vals_dmg[idx] * stacks_reales
    
    estado = "(Inactivo)"
    
    if stacks_reales > 0:
        resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + buff_total
        estado = f"({stacks_reales} stacks)"

    return f"Roaring Furnace: DMG +{buff_total:.1f}% {estado}"

def wengine_spectral_gaze(resultados, **kwargs):
    """
    Spectral Gaze (Mirada Espectral):
    - Efecto 1 (Debuff): Al hacer daño Eléctrico con Aftershock -> Reducción DEF enemigo 25-40%.
    - Efecto 2 (Propio): Impacto +4-6.4% por stack (Max 3). 
    - Bonus Max Stacks: Impacto adicional +8-12.8%.
    - Lógica: Asumimos que si hay stacks, el debuff de Defensa también está activo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_shred = [25.0, 28.75, 32.5, 36.25, 40.0]
    vals_imp_stack = [4.0, 4.6, 5.2, 5.8, 6.4]
    vals_imp_bonus = [8.0, 9.2, 10.4, 11.6, 12.8]
    
    idx = max(0, min(ref - 1, 4))
    
    stacks_reales = min(stacks, 3)
    
    if stacks_reales == 0:
        return "Spectral Gaze: (Inactivo)"

    shred_total = vals_shred[idx]
    resultados["Reduccion_DEF_enemigo"] = resultados.get("Reduccion_DEF_enemigo", 0.0) + shred_total
    imp_total = vals_imp_stack[idx] * stacks_reales
    if stacks_reales == 3:
        imp_total += vals_imp_bonus[idx]
        
    resultados["Impacto"] = resultados.get("Impacto", 0.0) + imp_total
    
    return f"Spectral Gaze: Def Shred -{shred_total:.2f}% / Imp (Self) +{imp_total:.1f}% (Activo)"

def wengine_yesterday_calls(resultados, **kwargs):
    """
    Yesterday Calls (Llamadas del Ayer):
    - Parte 1 (Self): Recarga Energía y Aturdimiento (Daze) por stack.
    - Parte 2 (Team): Al alcanzar 3 stacks -> CRIT DMG +30-48% para el equipo.
    - Lógica: Si stacks < 3, el buff de equipo está inactivo.
    """
    try:
        ref = int(kwargs.get('refinamiento', 1))
    except: ref = 1
    
    try:
        stacks = int(kwargs.get('stacks', 0))
    except: stacks = 0
    
    vals_cd = [30.0, 34.5, 39.0, 43.5, 48.0]
    
    idx = max(0, min(ref - 1, 4))
    
    stacks_reales = min(stacks, 3)
    
    buff_total = 0.0
    estado = f"(Inactivo: {stacks_reales}/3 stacks)"
    
    if stacks_reales >= 3:
        buff_total = vals_cd[idx]
        resultados["Daño_crítico"] = resultados.get("Daño_crítico", 0.0) + buff_total
        estado = "(Activo)"

    return f"Yesterday Calls: CD Team +{buff_total:.1f}% {estado}"

MAPA_SOPORTES_WENGINES = {
    "kaboom the cannon": wengine_Kaboom_the_Cannon,
    "unfettered game ball": wengine_unfettered_game_ball,
    "the vault": wengine_the_vault,
    "bashful demon": wengine_bashful_demon,
    "slice of time": wengine_slice_of_time,
    "weeping cradle": wengine_weeping_cradle,
    "metanukimorphosis": wengine_metanukimorphosis,
    "elegant vanity": wengine_elegant_vanity,
    "dreamlit hearth": wengine_dreamlit_hearth,
    "(reverb) mark i": wengine_reverb_mark_i,
    "(reverb) mark ii": wengine_reverb_mark_ii,
    "(reverb) mark iii": wengine_reverb_mark_iii,
    "tusks of fury": wengine_tusks_of_fury,
    "half-sugar bunny": wengine_half_sugar_bunny,
    "blazing laurel": wengine_blazing_laurel,
    "ice-jade teapot": wengine_ice_jade_teapot,
    "roaring fur-nace": wengine_roaring_furnace,
    "spectral gaze": wengine_spectral_gaze,
    "yesterday calls": wengine_yesterday_calls,
}