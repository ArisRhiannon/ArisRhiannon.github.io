import asyncio
import enka
import logging

# Mapeo manual de IDs internos del juego a nombres legibles de agentes.
# Si meten un personaje nuevo en el banner, hay que agregarlo a esta lista
# para que no salga como 'Unknown' o rompa la UI.
AVATAR_ID_MAP = {
    1011: "Anby", 1021: "Nekomata", 1031: "Nicole", 1041: "Soldier 11",
    1051: "Yidhari", 1061: "Corin", 1071: "Caesar", 1081: "Billy",
    1091: "Miyabi", 1101: "Koleda", 1111: "Anton", 1121: "Ben", 1131: "Soukaku",
    1141: "Lycaon", 1151: "Lucy", 1161: "Lighter", 1171: "Burnice", 1181: "Grace",
    1191: "Ellen", 1201: "Harumasa", 1211: "Rina", 1221: "Yanagi", 1241: "Zhu Yuan",
    1251: "Qingyi", 1271: "Seth", 1281: "Piper", 1291: "Hugo", 1301: "Orphie & Magus",
    1311: "Astra Yao", 1321: "Evelyn", 1331: "Vivian", 1341: "Zhao", 1351: "Pulchra",
    1361: "Trigger", 1371: "Yixuan", 1381: "Soldier 0 - Anby", 1391: "Ju Fufu", 1401: "Alice",
    1411: "Yuzuha", 1421: "Pan Yinhu", 1431: "Ye Shunguang", 1441: "Manato", 1451: "Lucia",
    1461: "Seed", 1471: "Banyue", 1481: "Dialyn", 1491: "Sunna", 1501: "Aria",
}

def procesar_agente(agent):
    stats_dict = {}
    if agent.stats:
        for stat_obj in agent.stats.values():
            stats_dict[stat_obj.name] = {
                "value": stat_obj.value,
                "formatted": stat_obj.formatted_value
            }

    weapon_data = {} 
    if agent.w_engine:
        weapon_data = {
            "name": agent.w_engine.name,
            "rarity": agent.w_engine.rarity,
            "level": agent.w_engine.level,
            "refinement": agent.w_engine.modification, 
            "main_stat": {
                "name": agent.w_engine.main_stat.name,
                "value": agent.w_engine.main_stat.formatted_value
            }
        }

    discs_list = []
    for disc in agent.discs:
        subs = []
        for sub in disc.sub_stats:
            subs.append({
                "name": sub.name,
                "value": sub.formatted_value
            })

        discs_list.append({
            "slot": disc.slot,
            "set_id": disc.set_id,
            "level": disc.level,
            "main_stat": {
                "name": disc.main_stat.name,
                "value": disc.main_stat.formatted_value
            },
            "sub_stats": subs
        })

    mindscape_count = getattr(agent, "rank", 0)

    return {
        "name": agent.name,
        "level": agent.level,
        "element": str(agent.elements[0].name) if agent.elements else "Unknown",
        "specialty": str(agent.specialty.name) if agent.specialty else "Unknown",
        "stats": stats_dict,
        "weapon": weapon_data,
        "discs": discs_list,
        "mindscape": mindscape_count
    }

class GestorApi:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def obtener_datos_uid(self, uid):
        """
        Método sincrónico que llama a la lógica asíncrona de Enka.
        Se llama desde la Calculadora (que no es asíncrona).
        """
        try:

            uid_int = int(uid)

            personajes = asyncio.run(self._fetch_async(uid_int))
            
            if not personajes:
                return None, "UID sin personajes públicos o error de conexión."
            
            return personajes, "OK"
            
        except ValueError:
            return None, "El UID debe ser numérico."
        except Exception as e:
            return None, f"Error obteniendo datos: {e}"

    async def _fetch_async(self, uid):
        """
        Lógica asíncrona interna usando la librería 'enka'.
        """
        personajes_procesados = []

        async with enka.ZZZClient() as client:
            self.logger.info(f"Conectando a Enka.network para UID: {uid}")
            try:
                data = await client.fetch_showcase(uid)
                
                if data.agents:
                    for agent in data.agents:
                        datos_limpios = procesar_agente(agent)
                        personajes_procesados.append(datos_limpios)
                        
                return personajes_procesados
            except Exception as e:
                self.logger.error(f"Fallo en llamada API Enka: {e}")
                return []