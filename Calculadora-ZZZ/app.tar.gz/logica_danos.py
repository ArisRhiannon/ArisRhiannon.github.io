import logging
import math

### HOLA
#
# Esta clase maneja toda la matemática detrás del daño de Zenless Zone Zero.
# La fórmula general de daño que implementamos aquí sigue la lógica de:
# Daño = Daño Base * Multiplicador de Daño (DMG%) * Modificador Crítico * Multiplicador de Defensa * Multiplicador de Resistencia * Multiplicador de Stun * DMG Taken
# 
# También calcula:
# - Daño Sheer (ignora defensa, escala con Sheer Force).
# - Daño de Anomalías (Fuego, Electricidad, Hielo, Físico, Éter) basado en maestría (AP) y nivel.
# - Crítico de Anomalías (para Jane Doe y su Assault Crit).
# - Daño de Disorder al detonar una anomalía sobre otra.
# - Acumulación de anomalías (Anomaly build-up).

class LogicaDmg:
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)

    def _get_param(self, params, key, default=0.0):
        """Función segura para obtener parámetros numéricos del diccionario de la UI."""
        try:
            return float(params.get(key, default))
        except (ValueError, TypeError):
            self.logger.warning(f"No se pudo convertir el parámetro '{key}' a float. Usando valor por defecto: {default}.")
            return float(default)

    def _calcular_atk_combate(self, params):
        """
        Calcula el ATK inicial en combate.
        """
        initial_atk = self._get_param(params, "Ataque")

        return initial_atk

    def _calcular_base_dmg(self, params, scaling_stat):
        """
        Calcula el Daño Base de una habilidad.
        Fórmula: Skill MV * Scaling Stat + Flat MV
        """
        skill_mv = self._get_param(params, "Multiplicador_de_ataques") / 100.0
        flat_mv = self._get_param(params, "Flat_MV", 0)
        return skill_mv * scaling_stat + flat_mv

    def _calcular_dmg_mod(self, params):
        """
        Suma todos los bonos de daño porcentuales aplicables.
        Fórmula: 1 + Suma de todos los DMG%
        """
        elemental_dmg_bonus = self._get_param(params, "Daño_elemental") / 100.0
        additional_dmg_bonus = self._get_param(params, "Daño_Adicional") / 100.0
        aftershock_dmg_bonus = self._get_param(params, "Daño_Aftershock") / 100.0

        return 1 + elemental_dmg_bonus + additional_dmg_bonus + aftershock_dmg_bonus

    def _calcular_crit_mod(self, params):
        """
        Calcula el multiplicador de daño promedio por críticos.
        Fórmula: 1 + Prob. Crítico * Daño Crítico
        """
        crit_rate = min(self._get_param(params, "Probabilidad_crítico") / 100.0, 1.0)
        crit_dmg = self._get_param(params, "Daño_crítico") / 100.0

        crit_dmg_increase = self._get_param(params, "Aumento_Daño_Critico") / 100.0

        total_crit_dmg = crit_dmg + crit_dmg_increase

        return 1 + (crit_rate * total_crit_dmg)

    def _calcular_res_mod(self, params, elemento):

        res_map = {
            "fuego": "Resistencia_Fuego", "electrico": "Resistencia_Electrico",
            "hielo": "Resistencia_Hielo", "fisico": "Resistencia_Físico",
            "etereo": "Resistencia_Etereo"
        }

        red_map = {
            "fuego": "Red_Resistencia_Fuego", "electrico": "Red_Resistencia_Electrico",
            "hielo": "Red_Resistencia_Hielo", "fisico": "Red_Resistencia_Físico",
            "etereo": "Red_Resistencia_Etereo"
        }

        player_penres_map = {
            "fuego": "Pen_Res_Fuego", 
            "electrico": "Pen_Res_Electrico",
            "hielo": "Pen_Res_Hielo", 
            "físico": "Pen_Res_Fisico",
            "etereo": "Pen_Res_Etereo"
        }

        attribute_res = self._get_param(params, res_map.get(elemento, "Resistencia_Físico")) / 100.0
        all_type_res = self._get_param(params, "Resistencia_porcentual") / 100.0
        res_reduction = self._get_param(params, red_map.get(elemento, "Red_Resistencia_Físico")) / 100.0

        key_pen = player_penres_map.get(elemento, "Pen_Res_Global")
        
        res_pen = self._get_param(params, key_pen) / 100.0

        return 1 - (attribute_res + all_type_res - res_reduction - res_pen)

    def _calcular_def_mod(self, params):
        """
        Calcula el multiplicador de defensa del enemigo.
        Fórmula: CoefNivel / (CoefNivel + DEF Efectiva)
        """
        target_base_def = self._get_param(params, "Defensa_Base")
        def_reduction = self._get_param(params, "Reduccion_DEF_enemigo") / 100.0
        pen_ratio = self._get_param(params, "Tasa_de_Perforación") / 100.0
        flat_pen = self._get_param(params, "Perforación_Plana")
        def_ignored = self._get_param(params, "Ignorar_Defensa") / 100
        def_ignored_aftershock = self._get_param(params, "Ignorar_Defensa_Aftershock") / 100

        level_coefficient = 794

        target_def = target_base_def * (1 - def_reduction - def_ignored - def_ignored_aftershock)
        effective_def = max(0, target_def * (1 - pen_ratio) - flat_pen)

        return level_coefficient / (level_coefficient + effective_def)

    def _calcular_anomaly_mod(self, params):
        """
        Calcula el bono de daño específico para Anomalías.
        """
        anomaly_dmg_bonus = self._get_param(params, "Bono_Daño_Anomalia", 0) / 100.0
        return 1 + anomaly_dmg_bonus

    def _calcular_ap_bonus_mod(self, params):
        """
        Calcula el bono de daño por Anomaly Proficiency (Maestría de Anomalía).
        Fórmula: AP / 100
        """
        anomaly_proficiency = self._get_param(params, "Maestría_Anomalía")
        return anomaly_proficiency / 100.0

    def _calcular_buff_level_mod(self, params):
        """
        Calcula el bono de daño por el nivel del atacante.
        Fórmula: 1 + ((Nivel Atacante - 1) / 59)
        """
        attacker_level = self._get_param(params, "Nivel", 1)
        return 1 + ((attacker_level - 1) / 59.0)
    
    def _calcular_stun_mod(self, params):
        """
        Calcula el multiplicador de daño por aturdimiento.
        - No Aturdido: 0% Bono (Mult 1.0)
        - Aturdido (Jefe): 50% Bono Base (Mult 1.5)
        - Bonos extra (Lycaon, Qingyi, Dialyn, etc) se suman al bono base.
        """
        estado = params.get("Estado_Enemigo", "Normal")
        
        if estado == "Stun_Boss":
            base_mult = 1.50
        else:
            return 1.0

        extra_bonus = self._get_param(params, "Stun_DMG_Multiplier", 0.0) / 100.0
        return base_mult + extra_bonus
    
    def _calcular_unstun_mod(self, params):
        """
        Calcula el multiplicador de daño por aturdimiento excepciones.
        """
        estado = 1.0

        extra_bonus = self._get_param(params, "Unstun_DMG_Multiplier", 0.0) / 100.0
        return estado + extra_bonus

    def calcular_dano_general(self, params, elemento, atk_combate):
        """
        Calcula el daño normal, no-Anomalía.
        Fórmula: BaseDMG * DMG%Mod * CritMod * RESMod * DEFMod * ...
        """
        base_dmg = self._calcular_base_dmg(params, atk_combate)
        dmg_mod = self._calcular_dmg_mod(params)
        crit_mod = self._calcular_crit_mod(params)
        res_mod = self._calcular_res_mod(params, elemento)
        def_mod = self._calcular_def_mod(params)
        unstun_mod = self._calcular_unstun_mod(params)

    ### =================================================
    ### IMPORTANTE REVISAR
    ### =================================================
        # Modificadores de  DMG Taken no están en la UI, se asumen como 1.
        stun_mod = self._calcular_stun_mod(params)
        dmg_taken_mod = 1.0

        return base_dmg * dmg_mod * crit_mod * res_mod * def_mod * stun_mod * dmg_taken_mod * unstun_mod

    def calcular_dano_sheer(self, params, elemento, atk_combate):
        """
        Calcula el daño Sheer. Es idéntico al general pero IGNORA la defensa.
        Su daño base escala con Sheer Force (30% del ATK).
        """
        sheer_force = self._get_param(params, "Sheer_force")
        
        base_dmg = sheer_force 
        dmg_mod = self._calcular_dmg_mod(params) 
        crit_mod = self._calcular_crit_mod(params)
        res_mod = self._calcular_res_mod(params, elemento)
        unstun_mod = self._calcular_unstun_mod(params)

        stun_mod = self._calcular_stun_mod(params)
        dmg_taken_mod = 1.0

        return base_dmg * dmg_mod * crit_mod * res_mod * stun_mod * dmg_taken_mod * unstun_mod
    
    def _calcular_assaults_jane(self, params, elemento):
        """
        NUEVO: Calcula el multiplicador de crítico EXCLUSIVO para Anomalías.
        Actualmente solo aplica a 'Assault' (Físico) por Jane Doe .
        """
        if elemento not in ["fisico", "físico"]:
            return 1.0

        assault_rate = self._get_param(params, "Assault_Crit_Rate", 0.0)

        if assault_rate <= 0:
            return 1.0

        assault_dmg = self._get_param(params, "Assault_Crit_DMG", 50.0)

        rate_dec = min(assault_rate / 100.0, 1.0)
        dmg_dec = assault_dmg / 100.0

        return 1 + (rate_dec * dmg_dec)

    def calcular_dano_anomalia(self, params, elemento, atk_combate):
        """
        Calcula el daño de una Anomalía elemental.
        """
        base_dmg_multipliers = {
            "fuego": 0.50,    
            "electrico": 1.25, 
            "hielo": 5.00,    
            "físico": 7.13,   
            "etereo": 0.625   
        }

        elemento_key = elemento.lower().replace("í", "i") if elemento else ""
        if "fisico" in elemento_key: elemento_key = "físico"
        
        base_dmg = atk_combate * base_dmg_multipliers.get(elemento_key, 0.0)
        
        if base_dmg == 0: return 0 

        dmg_mod = self._calcular_dmg_mod(params)
        res_mod = self._calcular_res_mod(params, elemento)
        def_mod = self._calcular_def_mod(params)

        anomaly_mod = self._calcular_anomaly_mod(params)
        ap_bonus = self._calcular_ap_bonus_mod(params)
        buff_level_mod = self._calcular_buff_level_mod(params)


        crit_anomalia_mod = self._calcular_assaults_jane(params, elemento)

        return base_dmg * dmg_mod * res_mod * def_mod * anomaly_mod * ap_bonus * buff_level_mod * crit_anomalia_mod

    def calcular_dano_disorder(self, params, elemento, atk_combate):
        """
        Calcula el daño de Disorder. Su daño base depende del tiempo 't' restante.
        Como 't' no está en la UI, se asume un valor promedio (ej. t=5s).
        """
        # Asumimos t = 3 segundos como un valor de ejemplo, me basé en que hay cooldown de 3s si no recuerdo mal...
        t = 3.0

        disorder_multipliers = {
            "fuego": (4.50 + (math.floor(t / 0.5) * 0.50)), 
            "electrico": (4.50 + (t * 1.25)),                 
            "hielo": (4.50 + (t * 0.075)),                    
            "físico": (4.50 + (t * 0.075)),                   
            "etereo": (4.50 + (math.floor(t / 0.5) * 0.625)) 
        }
        
        base_mult = disorder_multipliers.get(elemento, 0.0)

        extra_mult = self._get_param(params, "Disorder_Extra_Mult", 0.0) / 100.0
        
        final_mult = base_mult + extra_mult

        base_dmg = atk_combate * final_mult
        if base_dmg == 0: return 0

        tasa_por_segundo = self._get_param(params, "Bono_Disorder_Seg", 0.0)
        bono_pct = min(180.0, tasa_por_segundo * t)
        disorder_mod = 1 + (bono_pct / 100.0)

        dmg_mod = self._calcular_dmg_mod(params)
        res_mod = self._calcular_res_mod(params, elemento)
        def_mod = self._calcular_def_mod(params)
        anomaly_mod = self._calcular_anomaly_mod(params)
        ap_bonus = self._calcular_ap_bonus_mod(params)
        buff_level_mod = self._calcular_buff_level_mod(params)

        return base_dmg * dmg_mod * res_mod * def_mod * anomaly_mod * ap_bonus * buff_level_mod * disorder_mod
    
    ###======================================================================
    ###   NO ESTOY SEGURO QUE ASÍ FUNCIONE EL DISORDER_MOD
    ###======================================================================

    def calcular_todos_danos(self, params, elemento):
        """
        Función principal que se comunica con la UI.
        Calcula todos los tipos de daño y devuelve los resultados.
        """
        try:
            atk_combate = self._calcular_atk_combate(params)

            dano_general = self.calcular_dano_general(params, elemento, atk_combate)
            dano_sheer = self.calcular_dano_sheer(params, elemento, atk_combate)
            dano_anomalia = self.calcular_dano_anomalia(params, elemento, atk_combate)
            dano_disorder = self.calcular_dano_disorder(params, elemento, atk_combate)

            stats_finales = {
                'Ataque en Combate': atk_combate,
                'Prob. Crítico Final': self._get_param(params, "Probabilidad_crítico"),
                'Daño Crítico Final': self._get_param(params, "Daño_crítico") + self._get_param(params, "Aumento_Daño_Critico"),
                'Modificador Crítico Promedio': f"x{self._calcular_crit_mod(params):.3f}",
                'Reducción por Defensa': f"{ (1 - self._calcular_def_mod(params)) * 100:.2f}%",
                'Reducción por Resistencia': f"{ (1 - self._calcular_res_mod(params, elemento)) * 100:.2f}%"
            }

            return dano_general, dano_sheer, dano_anomalia, dano_disorder, stats_finales

        except Exception as e:
            self.logger.error(f"Error catastrófico en el cálculo de daños: {e}", exc_info=True)
            return 0, 0, 0, 0, {"Error": str(e)}
        
    ###==================================================================
    ### CREO QUE FALTA TODO LO DEL ANOMALY BUILD UP Y OBVIO LO DEL MIASMA
    ###==================================================================

    def Anomaly_build_up(self, params, elemento):
            """
            Calcula cuánta anomalía se aplica por golpe.
            Basado en: Base * (Maestría/100) * (1 + %Bonos) * (1 - Resistencia)
            """
            
            base_build_up = 100 

            maestria_stat = self._get_param(params, "Tasa_de_Anomalía")
            am_bonus_multiplier = maestria_stat / 100.0

            bono_acumulacion_pct = self._get_param(params, "Bono_Acumulación")
            buildup_mod = 1 + (bono_acumulacion_pct / 100.0)

            target_res = self._get_param(params, "Resistencia_Anomalía_Enemigo", 0.0)
            res_reduction = self._get_param(params, "Reducción_Resistencia_Anomalía", 0.0)

            if res_reduction > 0:
                print(f"parece q funciona. Reducción aplicada: {res_reduction}%")
            else:
                print(f"parece que no lol q mal (Valor: {res_reduction}%). Verifica el checkbox.")
            
            res_final_pct = max(0.0, target_res - res_reduction) 
            res_mod = 1.0 - (res_final_pct / 100.0)

            total_buildup = base_build_up * am_bonus_multiplier * buildup_mod * res_mod
            
            return total_buildup