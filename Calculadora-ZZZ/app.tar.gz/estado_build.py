
class EstadoBuild:

    def __init__(self):
        self.nombre_agente = "Ninguno"
        self.nombre_wengine = "Ninguno"
        self.refinamiento = 1
        self.stacks = 0
        self.set_stacks = 0
        self.mindscape = 0
        self.mindscape_stacks = 0
        self.core_activo = False
        self.set_condicion = False
        self.nombre_habilidad = None

        self.sets = {
            'set1': "Ninguno",
            'set2': "Ninguno",
            'set3': "Ninguno"
        }
        self.discos = {
            4: "Ninguno",
            5: "Ninguno",
            6: "Ninguno"
        }

        self.substats_counts = {}
        self.bonos_manuales_planos = {}

    def reiniciar(self):
        """
        Restaura el estado a sus valores por defecto, como si se reiniciara la app.
        """
        self.nombre_agente = "Ninguno"
        self.nombre_wengine = "Ninguno"
        self.refinamiento = 1
        self.stacks = 0
        self.set_stacks = 0
        self.mindscape = 0
        self.mindscape_stacks = 0
        self.core_activo = False
        self.set_condicion = False
        self.nombre_habilidad = None
        self.sets = {'set1': "Ninguno", 'set2': "Ninguno", 'set3': "Ninguno"}
        self.discos = {4: "Ninguno", 5: "Ninguno", 6: "Ninguno"}
        self.substats_counts.clear()
        self.bonos_manuales_planos.clear()

    def __str__(self):
        """Representación en texto para depuración."""
        return (
            f"Agente: {self.nombre_agente}, W-Engine: {self.nombre_wengine}\n"
            f"Sets: {self.sets}\n"
            f"Discos: {self.discos}\n"
            f"Bonos Manuales: {self.bonos_manuales_planos}"
        )