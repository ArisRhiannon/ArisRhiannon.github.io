import flet as ft
import os

class CrearGui:
    def __init__(self, app_instance):
        self.app = app_instance
        
        self.entry_vars = {}
        self.buff_vars = {}
        self.team_controls = {}
        self.contenedor_pasivas_ui = ft.Column()
        self.controles_pasivas = {}

        self.agent_dropdown = None
        self.wengine_dropdown = None
        self.refinamiento_dropdown = None 
        self.stacks_dropdown = None       
        self.habilidad_dropdown = None
        self.core_stacks_dropdown = None
        self.core_stacks_slider = None
        self.enemy_dropdown = None
        self.set1_dropdown = None
        self.set2_dropdown = None
        self.set_stacks_dropdown = None  
        self.set3_dropdown = None
        self.disco_dropdowns = {}
        self.btn_tres_leches = None
        
        self.img_agente = None
        self.img_wengine = None  
        self.img_enemigo = None

        self.resultado_normal = None
        self.resultado_sheer = None
        self.resultado_anomaly = None
        self.resultado_disorder = None
        self.resultados_text = None
        self.config_name_field = None

        self.substat_counters = {} 
        self.contenedor_substats = ft.Column(spacing=2)

    def create_character_tab(self):
        """
        Pestaña principal 'DPS' COMPLETA.
        - Inicializa todos los controles para evitar errores.
        - Mueve PEN RES y Reducción DEF al panel del enemigo.
        """

        # --- 1. SECCIÓN SUPERIOR (Inicialización de Controles) ---
        self.img_agente = ft.Image(src="/images/default.png", width=100, height=100, fit=ft.ImageFit.CONTAIN, border_radius=8, opacity=0.2)
        self.img_wengine = ft.Image(
            src="/images/wengine/default_wengine.png", width=100, height=100, 
            fit=ft.ImageFit.CONTAIN, border_radius=8, opacity=0.2,
            tooltip="Selecciona un W-Engine"
        )
        
        self.agent_dropdown = ft.Dropdown(label="Agente", dense=True, expand=True, text_size=14)
        
        btn_importar = ft.IconButton(
            icon=ft.Icons.CLOUD_DOWNLOAD, 
            tooltip="Importar UID (Enka)",
            on_click=self.app.abrir_dialogo_uid
        )

        self.mindscape_dropdown = ft.Dropdown(
            label="Dupe", width=100, dense=True, text_size=14, value="0",
            options=[ft.dropdown.Option(str(i), text=f"M{i}") for i in range(7)],
            on_change=self.app.cambiar_mindscape 
        )
        self.mindscape_stacks_dropdown = ft.Dropdown(
            label="Cargas", width=80, dense=True, text_size=14, visible=False,
            on_change=self.app.cambiar_mindscape_stacks
        )

        row_agente = ft.Row(
            controls=[
                self.agent_dropdown, 
                btn_importar, 
                self.mindscape_dropdown, 
                self.mindscape_stacks_dropdown
            ], 
            spacing=5,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        # --- FILA 2: W-ENGINE + REFINAMIENTO + STACKS ---
        self.wengine_dropdown = ft.Dropdown(label="W-Engine", dense=True, expand=True, text_size=14)
        
        self.chk_filtro_wengine = ft.Checkbox(
            label="Solo Compatibles", 
            value=True, 
            tooltip="Muestra solo armas del mismo tipo que el Agente (Atacante, Aturdidor, etc.)",
            on_change=self.app.cambiar_filtro_wengines
        )

        self.refinamiento_dropdown = ft.Dropdown(
            label="Ref.", width=100, dense=True, text_size=14, value="1",
            options=[ft.dropdown.Option(str(i)) for i in range(1, 6)],
            on_change=self.app.cambiar_refinamiento 
        )

        self.stacks_dropdown = ft.Dropdown(label="Stacks", width=80, dense=True, text_size=12, visible=False)
        self.set_checkbox = ft.Checkbox(label="¿Activo?", value=False, visible=False, on_change=self.app.cambiar_set_condicion)

        row_wengine = ft.Row(
            controls=[
                self.wengine_dropdown,
                self.chk_filtro_wengine,
                self.refinamiento_dropdown, 
                self.stacks_dropdown,
                self.set_checkbox
            ], 
            spacing=5,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        # --- FILA 3: HABILIDAD ---
        self.habilidad_dropdown = ft.Dropdown(
            label="Habilidad a Calcular", dense=True, expand=True, text_size=14,
            on_change=self.app.manejador_habilidad
        )
        self.core_checkbox = ft.Checkbox(
            label="Activar Core", 
            value=False, 
            on_change=self.app.cambiar_core_activo,
            tooltip="Activa o Desactiva el efecto principal (Core/Pasiva)."
        )

        self.core_stacks_dropdown = ft.Dropdown(
            label="Stacks", 
            width=80, 
            dense=True, 
            text_size=12, 
            visible=False,
            options=[ft.dropdown.Option(str(i)) for i in range(1, 10)],
            value="1",
            on_change=self.app.cambiar_core_stacks
        )

        self.core_stacks_slider = ft.Slider(
            min=0, max=100, divisions=100, label="{value}", 
            width=150, visible=False, 
            on_change=self.app.cambiar_core_stacks
        )
        
        row_habilidad = ft.Row(
            controls=[self.habilidad_dropdown,self.core_checkbox,
                      self.core_stacks_dropdown,self.core_stacks_slider],
            spacing=10,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        self.contenedor_pasivas_ui = ft.Column(spacing=5)
        
        top_card_content = ft.Row(
            controls=[
                ft.Container(content=self.img_agente,padding=5,border=ft.border.all(1, ft.Colors.OUTLINE),border_radius=10,bgcolor=ft.Colors.BLACK26),
                ft.Column(controls=[row_agente, row_wengine,row_habilidad, self.contenedor_pasivas_ui],expand=True, spacing=8),
                ft.Container(content=self.img_wengine,padding=5,border=ft.border.all(1, ft.Colors.OUTLINE),border_radius=10,bgcolor=ft.Colors.BLACK26)
                ],spacing=10,alignment=ft.MainAxisAlignment.START,vertical_alignment=ft.CrossAxisAlignment.START 
        )

        # --- 2. ESTADÍSTICAS DEL AGENTE (Izquierda) ---
        parametros_agente = [
            ("Nivel", "Nivel"), ("Ataque", "Ataque"), ("Puntos de Vida", "Puntos_Vida"), ("Defensa", "Defensa"), 
            ("Prob. Crit %", "Probabilidad_crítico"), ("Daño Crit %", "Daño_crítico"),
            ("Bono DMG%", "Daño_Adicional"), ("Daño Elemental", "Daño_elemental"), 
            ("Maestría Anomalía", "Maestría_Anomalía"), ("Tasa Anomalía", "Tasa_de_Anomalía"),
            ("Bono DMG Anomalía%", "Bono_Daño_Anomalia"), ("Impacto", "Impacto"), 
            ("Perforación %", "Tasa_de_Perforación"), ("Perf. Plana", "Perforación_Plana"), 
            ("Rec. Energía %", "Recuperación_energía"), ("Skill Mult %", "Multiplicador_de_ataques"), 
            ("Aturdimiento%", "Aturdimiento"), ("Fuerza Absoluta", "Sheer_force")
        ]
        
        agent_fields = []
        for label, key in parametros_agente:
            field = ft.TextField(label=label, read_only=False, dense=True, data=key, text_size=13, height=40, content_padding=10)
            self.entry_vars[key] = field
            agent_fields.append(field)
        
        # Grid de 3 columnas para el agente
        stats_columns = ft.Row(
            controls=[
                ft.Column(agent_fields[0:6], spacing=5, expand=1),
                ft.Column(agent_fields[6:12], spacing=5, expand=1),
                ft.Column(agent_fields[12:18], spacing=5, expand=1)
            ], spacing=10
        )

        # --- 3. EQUIPAMIENTO Y SUBSTATS (Izquierda) ---
        self.set1_dropdown = ft.Dropdown(label="Set 4pc/2pc", dense=True, expand=True, text_size=13)
        self.set2_dropdown = ft.Dropdown(label="Set 2pc", dense=True, expand=True, text_size=13)
        self.set_stacks_dropdown = ft.Dropdown(label="Buffs Set", width=80, dense=True, text_size=12, visible=False)
        self.set3_dropdown = ft.Dropdown(label="Set 2pc (Tres Leches)", dense=True, expand=True, visible=False, text_size=13)
        
        row_sets = ft.Row([self.set1_dropdown, self.set_checkbox, self.set_stacks_dropdown, self.set2_dropdown], spacing=5)
        
        self.disco_dropdowns[4] = ft.Dropdown(label="Slot IV", dense=True, expand=True, text_size=13)
        self.disco_dropdowns[5] = ft.Dropdown(label="Slot V", dense=True, expand=True, text_size=13)
        self.disco_dropdowns[6] = ft.Dropdown(label="Slot VI", dense=True, expand=True, text_size=13)
        
        self.btn_tres_leches = ft.ElevatedButton(text="Tres Leches", on_click=self.app.activar_tres_leches, style=ft.ButtonStyle(bgcolor=ft.Colors.LIGHT_BLUE_ACCENT_400, color=ft.Colors.WHITE), height=35)
        btn_reiniciar = ft.ElevatedButton("Reiniciar", on_click=self.app.reiniciar_stats, style=ft.ButtonStyle(bgcolor=ft.Colors.RED_ACCENT_400, color=ft.Colors.WHITE), height=35)

        card_substats = ft.Card(
            ft.Container(content=ft.Column([
                ft.Text("Sub-stats (Rolls)", weight=ft.FontWeight.BOLD, size=14),
                ft.Divider(height=5),
                self.contenedor_substats
            ], spacing=5), padding=10)
        )

        # --- 4. BLOQUE DERECHO (Enemigo + Debuffs + Resultados) ---
        self.img_enemigo = ft.Image(src="/images/enemigos/default_enemy.png", width=70, height=70, fit=ft.ImageFit.CONTAIN, border_radius=8, opacity=0.2)
        self.enemy_dropdown = ft.Dropdown(label="Seleccionar Enemigo", dense=True, text_size=14, expand=True)
        
        self.dd_estado_enemigo = ft.Dropdown(
            label="Estado del Enemigo",
            dense=True,
            text_size=13,
            options=[
                ft.dropdown.Option("Normal", text="Normal (No Aturdido)"),
                ft.dropdown.Option("Stun_Boss", text="Aturdido"),
            ],
            value="Normal"
        )
        enemy_header = ft.Column([
            ft.Row([
                self.enemy_dropdown,
                ft.Container(content=self.img_enemigo, padding=5, border=ft.border.all(1, ft.Colors.OUTLINE), border_radius=10, bgcolor=ft.Colors.BLACK26)
            ], spacing=10),
            self.dd_estado_enemigo
        ], spacing=5)

        parametros_enemigo_base = [
            ("Defensa Base", "Defensa_Base"), ("Resistencia %", "Resistencia_porcentual"), 
            ("Defensa Plana", "Defensa_Plana"), ("Resistencia Fuego%", "Resistencia_Fuego"), 
            ("Resistencia Elec", "Resistencia_Electrico"), ("Resistencia Hielo", "Resistencia_Hielo"), 
            ("Resistencia Físico", "Resistencia_Físico"), ("Resistencia Etereo", "Resistencia_Etereo")
        ]
        enemy_fields_readonly = []
        for label, key in parametros_enemigo_base:
            field = ft.TextField(label=label, read_only=True, dense=True, text_size=12, height=40, content_padding=10, bgcolor=ft.Colors.BLACK26)
            self.entry_vars[key] = field
            enemy_fields_readonly.append(field)

        self.campo_pen_res = ft.TextField(
            label="Resistencia Perforada", read_only=False, dense=True, 
            data="Pen_Res_Fisico", text_size=13, height=40, content_padding=10,
            border_color="cyan" 
        )
        self.entry_vars["Pen_Res_Fisico"] = self.campo_pen_res

        field_def_shred = ft.TextField(
            label="Reducción DEF %", read_only=False, dense=True, 
            data="Reduccion_DEF_enemigo", text_size=13, height=40, content_padding=10
        )
        self.entry_vars["Reduccion_DEF_enemigo"] = field_def_shred

        enemy_grid = ft.GridView(runs_count=2, max_extent=150, child_aspect_ratio=2.5, spacing=5, run_spacing=5, controls=enemy_fields_readonly)

        debuffs_row = ft.Row(controls=[self.campo_pen_res, field_def_shred], spacing=5)

        left_content = ft.Column(
            spacing=10,
            controls=[
                ft.Card(ft.Container(content=top_card_content, padding=10)),
                ft.Card(ft.Container(content=ft.Column([
                        ft.Text("Estadísticas Base", weight=ft.FontWeight.BOLD, size=14),
                        ft.Divider(height=5), stats_columns
                    ], spacing=5), padding=10)),
                ft.Card(ft.Container(content=ft.Column([
                        ft.Text("Equipamiento", weight=ft.FontWeight.BOLD, size=14),
                        ft.Divider(height=5), row_sets, self.set3_dropdown,
                        ft.Row([self.disco_dropdowns[4], self.disco_dropdowns[5], self.disco_dropdowns[6]], spacing=5),
                        ft.Divider(height=10), ft.Row([self.btn_tres_leches, btn_reiniciar], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
                    ], spacing=5), padding=10)),
                card_substats
            ]
        )

        style_res = ft.TextStyle(size=15, weight=ft.FontWeight.BOLD)
        self.resultado_normal = ft.Text("Normal: 0", style=style_res)
        self.resultado_sheer = ft.Text("Sheer: 0", style=style_res)
        self.resultado_anomaly = ft.Text("Anomalía: 0", style=style_res)
        self.resultado_disorder = ft.Text("Disorder: 0", style=style_res)
        self.resultados_text = ft.TextField(label="Detalles", multiline=True, read_only=True, text_size=12, height=150)

        right_content = ft.Column(
            spacing=10,
            controls=[
                ft.Card(ft.Container(content=ft.Column([
                        ft.Text("Stats del Enemigo", weight=ft.FontWeight.BOLD, size=14),
                        enemy_header,
                        enemy_grid,
                        ft.Divider(height=10, thickness=1),
                        ft.Text("Modificadores de Defensa y Resistencia", size=12, italic=True),
                        debuffs_row
                    ], spacing=10), padding=10)),
                ft.Card(ft.Container(content=ft.Column([
                        ft.Text("Resultados", weight=ft.FontWeight.BOLD, size=16),
                        ft.Divider(height=5),
                        self.resultado_normal, self.resultado_sheer, self.resultado_anomaly, self.resultado_disorder,
                        ft.Divider(height=10, color="transparent"),
                        ft.ElevatedButton("CALCULAR DAÑO", on_click=self.app.calcular_dano, bgcolor=ft.Colors.CYAN, color=ft.Colors.WHITE, height=45, width=200),
                        self.resultados_text
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5), padding=10))
            ]
        )
        
        contenido_responsivo = ft.ResponsiveRow(
            controls=[
                ft.Column(controls=[left_content], col={"md": 7, "sm": 12}),
                ft.Column(controls=[right_content], col={"md": 5, "sm": 12})
            ]
        )

        return ft.Column(controls=[contenido_responsivo], scroll=ft.ScrollMode.AUTO, expand=True)
    
    def _crear_panel_soporte(self, titulo, prefijo_key, lista_agentes, lista_wengines, lista_sets):
        """
        Crea una tarjeta visual para un personaje de soporte (Lógica UI).
        AHORA INCLUYE: Mindscapes, Stacks de Mindscape y Checkbox de Condición.
        """
        img_agente = ft.Image(src="/images/default.png", width=60, height=60, fit=ft.ImageFit.CONTAIN, opacity=0.3, border_radius=5)
        img_wengine = ft.Image(src="/images/wengine/default_wengine.png", width=60, height=60, fit=ft.ImageFit.CONTAIN, opacity=0.3, border_radius=5)

        marco_agente = ft.Container(content=img_agente, padding=5, border=ft.border.all(1, ft.Colors.WHITE24), border_radius=8, bgcolor=ft.Colors.BLACK26)
        marco_wengine = ft.Container(content=img_wengine, padding=5, border=ft.border.all(1, ft.Colors.WHITE24), border_radius=8, bgcolor=ft.Colors.BLACK26)

        dd_agente = ft.Dropdown(label="Agente", options=[ft.dropdown.Option(a) for a in lista_agentes], expand=True, dense=True, text_size=13)
        
        dd_mindscape = ft.Dropdown(
            label="Mindscape", width=90, dense=True, text_size=12,
            options=[ft.dropdown.Option(str(i), text=f"M{i}") for i in range(7)],
            value="0",
            tooltip="Nivel de Mindscape (Cinemas)"
        )
        
        dd_m_stacks = ft.Dropdown(
            label="Cargas", width=90, dense=True, text_size=12,
            options=[ft.dropdown.Option(str(i)) for i in range(11)],
            value="0",
            tooltip="Stacks del Mindscape (si aplica)"
        )

        chk_m_cond = ft.Checkbox(
            label="¿Activar dupes?", 
            value=False,
            tooltip="Activa la condición del Mindscape (ej. 'Enemigo con Def Down', 'Buff activado')"
        )

        dd_wengine = ft.Dropdown(label="W-Engine", options=[ft.dropdown.Option(w) for w in lista_wengines], expand=True, dense=True, text_size=13)
        
        dd_ref = ft.Dropdown(
            label="Ref", width=90, dense=True, text_size=12, 
            options=[ft.dropdown.Option(str(i)) for i in range(1, 6)], 
            value="1"
        )
        
        dd_stacks = ft.Dropdown(
            label="W.Stacks", width=90, dense=True, text_size=12,
            options=[ft.dropdown.Option(str(i)) for i in range(0, 6)],
            value="0"
        )

        dd_set4 = ft.Dropdown(label="Set 4 Piezas (Efecto Equipo)", options=[ft.dropdown.Option(s) for s in lista_sets], dense=True, text_size=13)

        txt_tipo = ft.TextField(label="Tipo", read_only=True, expand=True, dense=True, text_size=12)
        txt_elemento = ft.TextField(label="Elemento", read_only=True, expand=True, dense=True, text_size=12)
        txt_faccion = ft.TextField(label="Facción", read_only=True, expand=True, dense=True, text_size=12)
            
        txt_ataque = ft.TextField(label="Ataque", suffix_text="", expand=True, dense=True, text_size=12, value="0")
        txt_pv = ft.TextField(label="Puntos_de_Vida", suffix_text="", expand=True, dense=True, text_size=12, value="0")
        txt_prob = ft.TextField(label="Probabilidad_de_crítico", suffix_text="%", expand=True, dense=True, text_size=12, value="0")
        txt_dano = ft.TextField(label="Daño_crítico", suffix_text="%", expand=True, dense=True, text_size=12, value="0")
        txt_perfo = ft.TextField(label="Tasa_de_Perforación", suffix_text="%", expand=True, dense=True, text_size=12, value="0")
        txt_tasa = ft.TextField(label="Tasa_de_Anomalía", suffix_text="", expand=True, dense=True, text_size=12, value="0")
        txt_recarga = ft.TextField(label="Recuperación_energía", suffix_text="%", expand=True, dense=True, text_size=12, value="0")
        txt_imp = ft.TextField(label="Impacto", suffix_text="", expand=True, dense=True, text_size=12, value="0")
        txt_am = ft.TextField(label="Maestría_de_Anomalía", suffix_text="", expand=True, dense=True, text_size=12, value="0")
        txt_def = ft.TextField(label="Defensa", suffix_text="", expand=True, dense=True, text_size=12, value="0")

        self.team_controls[f"{prefijo_key}_agente"] = dd_agente
        
        self.team_controls[f"{prefijo_key}_mindscape"] = dd_mindscape
        self.team_controls[f"{prefijo_key}_mindscape_stacks"] = dd_m_stacks
        self.team_controls[f"{prefijo_key}_mindscape_cond"] = chk_m_cond

        self.team_controls[f"{prefijo_key}_wengine"] = dd_wengine
        self.team_controls[f"{prefijo_key}_wengine_ref"] = dd_ref
        self.team_controls[f"{prefijo_key}_wengine_stacks"] = dd_stacks
        self.team_controls[f"{prefijo_key}_set4"] = dd_set4
        
        self.team_controls[f"{prefijo_key}_img_agente"] = img_agente
        self.team_controls[f"{prefijo_key}_img_wengine"] = img_wengine

        self.team_controls[f"{prefijo_key}_tipo"] = txt_tipo
        self.team_controls[f"{prefijo_key}_elemento"] = txt_elemento
        self.team_controls[f"{prefijo_key}_faccion"] = txt_faccion

        self.team_controls[f"{prefijo_key}_stat_atk"] = txt_ataque
        self.team_controls[f"{prefijo_key}_stat_hp"] = txt_pv
        self.team_controls[f"{prefijo_key}_stat_crit_rate"] = txt_prob
        self.team_controls[f"{prefijo_key}_stat_crit_dmg"] = txt_dano
        self.team_controls[f"{prefijo_key}_stat_pen"] = txt_perfo
        self.team_controls[f"{prefijo_key}_stat_am"] = txt_tasa
        self.team_controls[f"{prefijo_key}_stat_er"] = txt_recarga
        self.team_controls[f"{prefijo_key}_stat_imp"] = txt_imp
        self.team_controls[f"{prefijo_key}_stat_am"] = txt_am
        self.team_controls[f"{prefijo_key}_stat_def"] = txt_def

        return ft.Container(
            padding=10,
            bgcolor=ft.Colors.BLACK26, 
            border_radius=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            content=ft.Column([
                ft.Row([ft.Icon(ft.Icons.PERSON, size=16, color=ft.Colors.CYAN_300), ft.Text(titulo, weight="bold", color=ft.Colors.CYAN_300)]),
                ft.Divider(height=5),
                
                ft.Row([
                    marco_agente,
                    ft.Column([
                        dd_agente, 
                        ft.Row([dd_mindscape, dd_m_stacks, chk_m_cond], spacing=5, alignment=ft.MainAxisAlignment.START),
                        ft.Row([dd_wengine, dd_ref, dd_stacks], spacing=5) 
                    ], expand=True, spacing=5),
                    marco_wengine
                ], alignment=ft.MainAxisAlignment.START, vertical_alignment=ft.CrossAxisAlignment.START),

                ft.Row([txt_ataque, txt_pv]),
                ft.Row([txt_prob, txt_dano]),
                ft.Row([txt_perfo, txt_tasa]),
                ft.Row([txt_recarga, txt_am]),
                ft.Row([txt_imp, txt_def]),

                ft.Divider(height=5, color=ft.Colors.WHITE10),
                ft.Row([txt_tipo, txt_elemento, txt_faccion], spacing=5),

                dd_set4
            ], spacing=10)
        )
    
    def create_buffs_tab(self):
        """
        Pestaña de Buffs rediseñada: 2 Columnas de Soportes + Resumen Inferior.
        """
        lista_agentes = [] 
        lista_wengines = []
        lista_sets = [] 

        panel_sup1 = self._crear_panel_soporte(
            "Agente 1 (Subdps/Soporte)", "sup1", 
            lista_agentes, lista_wengines, lista_sets
        )

        panel_sup2 = self._crear_panel_soporte(
            "Agente 2 (Subdps/Soporte)", "sup2", 
            lista_agentes, lista_wengines, lista_sets
        )

        self.lbl_resumen_buffs = ft.Text(
            "•Selecciona a tus compañeros de equipo, si el mismo tiene buff condicionados (p.e. Astra Yao que depende de su atk para su buff, por favor rellena los datos correspondientes.).", 
            italic=True, 
            color=ft.Colors.GREY_400
        )

        self.team_controls["resumen_texto"] = self.lbl_resumen_buffs

        panel_resumen = ft.Container(
            margin=ft.margin.only(top=10),
            padding=15,
            bgcolor=ft.Colors.BLACK38, 
            border=ft.border.all(1, ft.Colors.GREY_800),
            border_radius=10,
            content=ft.Column([
                ft.Row([
                    ft.Text("Resumen de Efectos Aplicados al DPS", size=16, weight="bold")
                ]),
                ft.Divider(),
                self.lbl_resumen_buffs,
            ])
        )

        columna_contenido = ft.Column([
            ft.ResponsiveRow([
                ft.Column([panel_sup1], col={"md": 6, "sm": 12}),
                ft.Column([panel_sup2], col={"md": 6, "sm": 12}),
            ]),
            panel_resumen
        ], scroll=ft.ScrollMode.AUTO, expand=True) 

        return ft.Container(content=columna_contenido, padding=10, expand=True)
    
    def create_comparator_tab(self):
        self.config_name_field = ft.TextField(
            label="Nombre para Guardar", 
            width=300, 
            text_size=12, 
            content_padding=10,
            dense=True 
        )
        btn_save = ft.ElevatedButton("Guardar Actual", on_click=self.app.guardar_config, icon=ft.Icons.SAVE)
        
        row_save = ft.Row([self.config_name_field, btn_save], alignment=ft.MainAxisAlignment.CENTER)

        ft.Divider()

        opciones_archivos = []

        ruta_guardados = os.path.join(self.app.base_path, 'guardados')
        if os.path.exists(ruta_guardados):
            archivos = [f for f in os.listdir(ruta_guardados) if f.endswith('.json')]
            for arch in archivos:
                nombre_limpio = arch.replace(".json", "")
                opciones_archivos.append(ft.dropdown.Option(nombre_limpio))
        
        self.archivo_dropdown = ft.Dropdown(
            label="Seleccionar Build Guardada",
            width=300,
            options=opciones_archivos,
            text_size=12,
            content_padding=10,
            dense=True
        )
        
        btn_load = ft.ElevatedButton("Cargar Build", on_click=self.app.cargar_config, icon=ft.Icons.UPLOAD_FILE)
        btn_refresh = ft.IconButton(icon=ft.Icons.REFRESH, tooltip="Actualizar lista", on_click=self.app.actualizar_lista_archivos)

        row_load = ft.Row([self.archivo_dropdown, btn_refresh, btn_load], alignment=ft.MainAxisAlignment.CENTER)

        return ft.Column(
            controls=[
                ft.Container(height=20), 
                ft.Text("Guardar Configuración", size=16, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                row_save,
                ft.Divider(height=30, thickness=2),
                ft.Text("Cargar Configuración", size=16, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                row_load,
                ft.Container(height=20),
                ft.Text("Nota: Al cargar, se sobrescribirán todos los datos actuales.", color=ft.Colors.GREY, italic=True, text_align=ft.TextAlign.CENTER)
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER
        )

    def create_recommendations_tab(self):
        btn_gen = ft.ElevatedButton("Generar Recomendaciones", on_click=self.app.generar_recomendaciones)
        return ft.Column(controls=[btn_gen])

    def create_graph_tab(self):
        btn_graph = ft.ElevatedButton("Graficar", on_click=self.app.graficar_variable)
        return ft.Column(controls=[btn_graph])

    def generar_substats_ui(self, db_substats):
        self.contenedor_substats.controls.clear()
        self.substat_counters.clear()
        
        grid = ft.GridView(
            runs_count=3, 
            max_extent=150, 
            child_aspect_ratio=2.5, 
            spacing=5, 
            run_spacing=5
        )
        
        for item in db_substats:
            u_key = item['unique_key']
            label_text = item['label'].replace("porcentual", "%").replace("plano", "").replace("plana", "")
            label_text = label_text.replace("Probabilidad_crítico", "Crit Rate").replace("Daño_crítico", "Crit Dmg")
            label_text = label_text.replace("Maestría_Anomalía", "Maestría").replace("Puntos_Vida", "HP")
            
            txt_count = ft.Text("0", size=14, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER, width=20)
            self.substat_counters[u_key] = txt_count
            
            btn_minus = ft.IconButton(
                icon=ft.Icons.REMOVE, 
                icon_size=14, 
                on_click=lambda e, k=u_key: self.app.modificar_substat(k, -1),
                style=ft.ButtonStyle(padding=0)
            )
            btn_plus = ft.IconButton(
                icon=ft.Icons.ADD, 
                icon_size=14, 
                on_click=lambda e, k=u_key: self.app.modificar_substat(k, 1),
                style=ft.ButtonStyle(padding=0)
            )

            row_ctrl = ft.Container(
                content=ft.Column([
                    ft.Text(label_text, size=10, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS),
                    ft.Row(
                        [btn_minus, txt_count, btn_plus], 
                        alignment=ft.MainAxisAlignment.CENTER, 
                        spacing=0
                    )
                ], spacing=0, alignment=ft.MainAxisAlignment.CENTER),
                bgcolor=ft.Colors.BLACK26,
                border_radius=5,
                padding=2
            )
            grid.controls.append(row_ctrl)
            
        self.contenedor_substats.controls.append(grid)
        self.contenedor_substats.update()

    def actualizar_imagen_agente(self, nombre_agente):
        if nombre_agente == "Ninguno":
            self.img_agente.src = "/images/default.png" 
            self.img_agente.opacity = 0.2
        else:
            ruta_imagen = f"/images/{nombre_agente}.png"
            self.img_agente.src = ruta_imagen
            self.img_agente.opacity = 1.0
        self.img_agente.update()

    def actualizar_imagen_enemigo(self, nombre_enemigo):
        if not nombre_enemigo or nombre_enemigo == "Ninguno":
            self.img_enemigo.src = "/images/enemigos/default_enemy.png" 
            self.img_enemigo.opacity = 0.2
        else:
            ruta_imagen = f"/images/enemigos/{nombre_enemigo}.png"
            self.img_enemigo.src = ruta_imagen
            self.img_enemigo.opacity = 1.0
        self.img_enemigo.update()
        
    def actualizar_imagen_wengine(self, nombre_wengine):
        if not nombre_wengine or nombre_wengine == "Ninguno":
            self.img_wengine.src = "/images/wengine/default_wengine.png"
            self.img_wengine.opacity = 0.2
        else:
            ruta_imagen = f"/images/wengine/{nombre_wengine}.png"
            self.img_wengine.src = ruta_imagen
            self.img_wengine.opacity = 1.0
        self.img_wengine.update()

    def actualizar_imagen_team(self, prefijo, tipo, nombre):
        """
        Actualiza la imagen de un agente específico.
        """
        clave_control = f"{prefijo}_img_{tipo}"

        img_control = self.team_controls.get(clave_control)
        
        if not img_control:
            print(f"Error: No se encontró el control de imagen para {clave_control}")
            return

        if tipo == "agente":
            ruta_default = "/images/default.png"
            ruta_carpeta = "/images/"
        else:
            ruta_default = "/images/wengine/default_wengine.png"
            ruta_carpeta = "/images/wengine/"

        if not nombre or nombre == "Ninguno":
            img_control.src = ruta_default
            img_control.opacity = 0.3
        else:
            img_control.src = f"{ruta_carpeta}{nombre}.png"
            img_control.opacity = 1.0

        img_control.update()

    def configurar_input_core(self, visible, usa_slider=False, label="Stacks", max_val=1, val_def=0):
            """
            Configura dinámicamente si se muestra el Dropdown (pocos stacks) 
            o el Slider (muchos stacks) y actualiza sus etiquetas.
            Sirve tanto para Core Skills como para Pasivas con recursos.
            """
            if not visible:
                self.core_stacks_dropdown.visible = False
                self.core_stacks_slider.visible = False
                self.core_stacks_dropdown.update()
                self.core_stacks_slider.update()
                return

            if usa_slider:
                self.core_stacks_dropdown.visible = False
                self.core_stacks_slider.visible = True
                
                self.core_stacks_slider.min = 0
                self.core_stacks_slider.max = float(max_val)
                self.core_stacks_slider.divisions = int(max_val) if max_val < 100 else 100
                self.core_stacks_slider.value = float(val_def)
                
            else:
                self.core_stacks_slider.visible = False
                self.core_stacks_dropdown.visible = True
                
                self.core_stacks_dropdown.label = label
                self.core_stacks_dropdown.value = str(val_def)

                step = 1
                if max_val > 20: step = 5
                self.core_stacks_dropdown.options = [ft.dropdown.Option(str(i)) for i in range(0, int(max_val) + 1, step)]

            self.core_stacks_dropdown.update()
            self.core_stacks_slider.update()
   
    def actualizar_campo_pen_res(self, elemento):

    
        """
        Cambia dinámicamente el campo PEN RES ubicado en la sección del Enemigo.
        """
        if not elemento: return
        
        elemento = elemento.lower().strip()

        mapa_keys = {
            "fuego": "Pen_Res_Fuego",
            "electrico": "Pen_Res_Electrico", 
            "eléctrico": "Pen_Res_Electrico",
            "hielo": "Pen_Res_Hielo",
            "fisico": "Pen_Res_Fisico", 
            "físico": "Pen_Res_Fisico",
            "etereo": "Pen_Res_Etereo", 
            "etéreo": "Pen_Res_Etereo"
        }

        nueva_clave = mapa_keys.get(elemento, "Pen_Res_Fisico")
        nuevo_label = f"PEN RES ({elemento.capitalize()})"

        self.campo_pen_res.label = nuevo_label
        self.campo_pen_res.data = nueva_clave
        self.campo_pen_res.update()

        keys_viejas = [k for k, v in self.entry_vars.items() if v == self.campo_pen_res]
        for k in keys_viejas:
            del self.entry_vars[k]

        self.entry_vars[nueva_clave] = self.campo_pen_res