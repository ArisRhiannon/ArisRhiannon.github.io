import logging
import unicodedata
from efectos_core import MAPA_CORE
from efectos_sets import MAPA_EFECTOS_SETS
from efectos_mindscapes import MAPA_MINDSCAPES
from efectos_soportes import MAPA_SOPORTES_AGENTES, MAPA_SOPORTES_SETS
from efectos_pasivas import MAPA_PASIVAS
from efectos_soportes import MAPA_SOPORTES_WENGINES
try:
    from efectos_wengines import MAPA_WENGINES
except ImportError:
    MAPA_WENGINES = {} 

class GestorEstadisticas:
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)

    def _parse_valor(self, valor, es_porcentual=False):
        if valor is None: return 0.0
        try:
            val_str = str(valor).replace('%', '').replace(',', '.').strip()
            num = float(val_str) if val_str else 0.0
            return num
        except (ValueError, TypeError):
            return 0.0

    def _normalizar(self, texto):
        if not texto: return ""
        try:
            s = str(texto).strip().lower()
            s = ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')
            return s
        except Exception:
            return str(texto).strip().lower()

    def calcular_stats_finales(self, base_stats, estado_build, wengine_db, sets_db, 
                               discos_db, substats_db, elemento_agente, tipo_agente=None, 
                               stacks_core=0, sets_externos=None, estado_enemigo="Normal", **kwargs):
        if not base_stats:
            return {}

        elemento_agente = elemento_agente if elemento_agente else ""
        STATS_ESCALABLES = {'Ataque', 'Defensa', 'Puntos_Vida', 'Impacto', 'Aturdimiento', 'Recuperación_energía'}
        
        bases_wengine = {k: 0.0 for k in STATS_ESCALABLES} 
        multiplicadores_pct = {} 
        sumas_planas = {}
        info_especial = {} 

        sumas_planas['Daño_Adicional'] = 0.0
        sumas_planas['Daño_elemental'] = 0.0
        sumas_planas['Reduccion_DEF_enemigo'] = 0.0

        tiene_set = (estado_build.sets.get('set1', "Ninguno") != "Ninguno") or \
                    (estado_build.sets.get('set2', "Ninguno") != "Ninguno")
        
        if tiene_set:
            sumas_planas['Puntos_Vida'] = sumas_planas.get('Puntos_Vida', 0.0) + 2200.0
            sumas_planas['Ataque'] = sumas_planas.get('Ataque', 0.0) + 316.0
            sumas_planas['Defensa'] = sumas_planas.get('Defensa', 0.0) + 184.0

        nombre_agente = estado_build.nombre_agente
        core_activo = estado_build.core_activo
        nombre_habilidad = estado_build.nombre_habilidad or ""
        m_level = estado_build.mindscape
        m_stacks = estado_build.mindscape_stacks
        condicion = estado_build.set_condicion 

        def agregar_bono(key, valor, es_pct_flag):
            if valor == 0: return
            key = key.strip()

            if key in STATS_ESCALABLES and es_pct_flag:
                valor_final = valor / 100.0
                multiplicadores_pct[key] = multiplicadores_pct.get(key, 0.0) + valor_final
            else:
                sumas_planas[key] = sumas_planas.get(key, 0.0) + valor

        if nombre_agente in MAPA_MINDSCAPES:
            func_mindscape = MAPA_MINDSCAPES[nombre_agente]
            bonos_m = func_mindscape(m_level, stacks=m_stacks, condicion_activa=condicion)
            
            for stat, valor in bonos_m.items():
                es_pct = (stat in STATS_ESCALABLES)
                agregar_bono(stat, valor, es_pct)

        # --- 1. SUBSTATS ---
        if substats_db and hasattr(estado_build, 'substats_counts'):
            for item in substats_db:
                u_key = item['unique_key']
                cantidad = estado_build.substats_counts.get(u_key, 0)
                if cantidad > 0:
                    stat_key = item['key_interna']
                    tipo = item['tipo']
                    valor_unitario = item['valor']
                    total_bono = cantidad * valor_unitario
                    es_pct = ('porcentual' in tipo)
                    agregar_bono(stat_key, total_bono, es_pct)

        # --- 2. W-ENGINE ---
        wengine_data = wengine_db.get(estado_build.nombre_wengine)
        if wengine_data:
            mapeo_wengine = {
                'Ataque wengine': ('Ataque', False),
                'Ataque': ('Ataque', True),
                'Recuperación de energía': ('Recuperación_energía', True),
                'Maestría de Anomalía del agente': ('Maestría_Anomalía', False),
                'Probabilidad de crítico': ('Probabilidad_crítico', False),
                'Daño crítico': ('Daño_crítico', False),
                'Tasa de perforación': ('Tasa_de_Perforación', False),
                'Puntos de vida': ('Puntos_Vida', True),
                'Defensa': ('Defensa', True),
                'Impacto': ('Impacto', False),
                'Aturdimiento': ('Aturdimiento', False)
            }
            for csv_col, (stat_key, es_pct_csv) in mapeo_wengine.items():
                valor = self._parse_valor(wengine_data.get(csv_col), es_porcentual=es_pct_csv)
                if csv_col == 'Ataque wengine':
                    bases_wengine['Ataque'] += valor
                else:
                    agregar_bono(stat_key, valor, es_pct_csv)

            tipo_arma = wengine_data.get('tipow,personaje')
            if not tipo_arma:
                tipo_arma = wengine_data.get('tipow', '') 
            
            tipo_arma = str(tipo_arma).strip()
            match_tipo = self._normalizar(tipo_agente) in self._normalizar(tipo_arma)
            
            if match_tipo:
                nombre_arma_real = estado_build.nombre_wengine
                if nombre_arma_real in MAPA_WENGINES:
                    funcion_pasiva = MAPA_WENGINES[nombre_arma_real]
                    refinamiento_actual = getattr(estado_build, 'refinamiento', 1)
                    stacks_actuales = getattr(estado_build, 'stacks', 0)
                    
                    stats_temp_arma = base_stats.copy()
                    for k, v in sumas_planas.items():
                        stats_temp_arma[k] = stats_temp_arma.get(k, 0.0) + v 

                    try:
                        bonos_pasiva = funcion_pasiva(
                            stats_actuales=stats_temp_arma, 
                            refinamiento=refinamiento_actual, 
                            nombre_agente=estado_build.nombre_agente,
                            stacks=stacks_actuales,
                            estado_enemigo=estado_enemigo
                        )
                    except TypeError:
                        bonos_pasiva = funcion_pasiva(
                            stats_temp_arma, 
                            refinamiento_actual, 
                            estado_build.nombre_agente, 
                            stacks_actuales
                        )
                    
                    for stat, valor in bonos_pasiva.items():
                        es_pct = (stat in STATS_ESCALABLES)
                        if stat == "Recuperación_energía": es_pct = False 
                        agregar_bono(stat, valor, es_pct)

        # --- 3. SETS ---
        keywords_dash = ["dash"]
        nombre_habilidad_norm = self._normalizar(estado_build.nombre_habilidad or "")

        for set_nombre_usuario in estado_build.sets.values():
            set_norm_usuario = self._normalizar(set_nombre_usuario)
            set_data = next((s for s in sets_db if self._normalizar(s.get('Nombre')) == set_norm_usuario), None)
            
            if set_data:
                stat = set_data.get('stat', '').strip()
                tipo = set_data.get('Tipo')
                es_pct_csv = (tipo == 'porcentual')
                valor = self._parse_valor(set_data.get('valor'), es_porcentual=es_pct_csv)

                if stat == 'Bono_Dash':
                    es_dash = any(k in nombre_habilidad_norm for k in keywords_dash)
                    if es_dash:
                        agregar_bono("Daño_elemental", valor, es_pct_csv) 
                    continue

                elif stat == 'Daño_elemental':
                    set_elemento = str(set_data.get('elemento', 'todos'))
                    if set_elemento.lower() != 'todos' and set_elemento.lower() != str(elemento_agente).lower():
                        continue
                    agregar_bono(stat, valor, es_pct_csv)
                else:
                    agregar_bono(stat, valor, es_pct_csv)

        # --- 4. DISCOS ---
        for slot, disco_nombre in estado_build.discos.items():
            disco_lista = discos_db.get(slot, [])
            disco_norm_usuario = self._normalizar(disco_nombre)
            disco_data = next((d for d in disco_lista if self._normalizar(d.get('nombre')) == disco_norm_usuario), None)
            
            if disco_data:
                stat, tipo = disco_data.get('stat'), disco_data.get('tipo')
                es_pct_csv = (tipo == 'porcentual')
                valor = self._parse_valor(disco_data.get('valor'), es_porcentual=es_pct_csv)
                agregar_bono(stat, valor, es_pct_csv)

        # --- 5. SETS X4 (Efectos Complejos) ---
        nombre_set1 = estado_build.sets.get('set1', "Ninguno")
        nombre_set3 = estado_build.sets.get('set3', "Ninguno")
        es_build_4pc = (nombre_set3 == "Ninguno") and (nombre_set1 != "Ninguno")
        
        if es_build_4pc:
            set1_norm = self._normalizar(nombre_set1)
            funcion_efecto = None
            
            for key_mapa, func in MAPA_EFECTOS_SETS.items():
                if self._normalizar(key_mapa) == set1_norm:
                    funcion_efecto = func
                    break
            
            if funcion_efecto:
                res_set_temp = {}
                stacks_set = getattr(estado_build, 'set_stacks', 0)
                condicion = getattr(estado_build, 'set_condicion', False) 
                
                bonos_extra = funcion_efecto(
                    res_set_temp, 
                    elemento=elemento_agente,
                    stacks=stacks_set,
                    condicion_activa=condicion,
                    tipo_agente=tipo_agente,  
                    nombre_agente=estado_build.nombre_agente
                )
                
                if bonos_extra:
                    for stat, valor in bonos_extra.items():
                        es_pct = (stat in STATS_ESCALABLES)
                        if stat == "Ataque": es_pct = False
                        agregar_bono(stat, valor, es_pct)

        # --- 5.5. SOPORTES Y BUFFS EXTERNOS ---
        lista_tipos_soportes = []
        lista_elementos_soportes = []
        lista_facciones_soportes = []
        lista_nombres_soportes = []

        if tipo_agente: 
            lista_tipos_soportes.append(self._normalizar(tipo_agente))
        if elemento_agente: 
            lista_elementos_soportes.append(self._normalizar(elemento_agente))
        if estado_build.nombre_agente: 
            lista_nombres_soportes.append(self._normalizar(estado_build.nombre_agente))
            
        faccion_dps = kwargs.get("faccion_agente", "")
        if faccion_dps:
             lista_facciones_soportes.append(self._normalizar(faccion_dps))

        if sets_externos:
            for info_set in sets_externos:
                tipo_sup = self._normalizar(info_set.get('tipo_agente', ''))
                if tipo_sup: lista_tipos_soportes.append(tipo_sup)

                raw_elem = str(info_set.get('elemento_agente', ''))
                elem_sup = self._normalizar(raw_elem)
                if elem_sup: lista_elementos_soportes.append(elem_sup)
                
                raw_facc = str(info_set.get('faccion_agente', ''))
                facc_sup = self._normalizar(raw_facc)
                if facc_sup: lista_facciones_soportes.append(facc_sup)

                raw_nombre = str(info_set.get('nombre_agente', ''))
                norm_nombre = self._normalizar(raw_nombre)
                if norm_nombre: lista_nombres_soportes.append(norm_nombre)

        datos_equipo_completo = {
            "roles": lista_tipos_soportes,
            "elementos": lista_elementos_soportes,
            "facciones": lista_facciones_soportes,
            "nombres": lista_nombres_soportes
        }

        if sets_externos:
            for info_set in sets_externos:
                raw_set = info_set.get('nombre_set', '') or info_set.get('nombre', '')
                raw_agente = info_set.get('nombre_agente', '')
                tipo_sup = self._normalizar(info_set.get('tipo_agente', ''))
                
                stats_del_soporte = info_set.get('stats', {})
                n_set = self._normalizar(raw_set)
                n_agente = self._normalizar(raw_agente)
                
                res_soporte_temp = {} 

                raw_arma = info_set.get('nombre_arma', '')
                n_arma = self._normalizar(raw_arma)
                
                ref_arma = info_set.get('refinamiento_arma', 1)
                stacks_arma = info_set.get('stacks_arma', 0)


                for key_agente, funcion in MAPA_SOPORTES_AGENTES.items():
                    if key_agente in n_agente:
                        funcion(
                            res_soporte_temp, 
                            tipo_agente=tipo_sup, 
                            stats=stats_del_soporte, 
                            elemento_dps=elemento_agente,
                            datos_equipo=datos_equipo_completo,
                            **kwargs
                        )
                        break

                for key_set, funcion in MAPA_SOPORTES_SETS.items():
                    if key_set in n_set:
                        funcion(
                            res_soporte_temp, 
                            tipo_agente=tipo_sup, 
                            stats=stats_del_soporte, 
                            elemento_dps=elemento_agente,
                            datos_equipo=datos_equipo_completo
                        )
                        break
                
                for key_wengine, funcion in MAPA_SOPORTES_WENGINES.items():
                    if key_wengine in n_arma:
                        funcion(
                            res_soporte_temp, 
                            refinamiento=ref_arma,
                            stacks=stacks_arma,
                            stats=stats_del_soporte,
                            datos_equipo=datos_equipo_completo
                        )
                        break
                
                for stat, valor in res_soporte_temp.items():
                    if stat == "Ataque_%":
                        agregar_bono("Ataque", valor, True)
                        continue
                        
                    es_pct = (stat in STATS_ESCALABLES)
                    if stat == "Ataque": es_pct = False
                    
                    if isinstance(valor, (int, float)):
                        agregar_bono(stat, valor, es_pct)
                    else:
                        info_especial[stat] = valor

        # --- 5.6.  PASSIVE ---
        if nombre_agente in MAPA_PASIVAS:
            stats_temp_pasiva = base_stats.copy()
            for k, v in sumas_planas.items():
                stats_temp_pasiva[k] = stats_temp_pasiva.get(k, 0.0) + v
            for k, pct in multiplicadores_pct.items():
                base = stats_temp_pasiva.get(k, 0.0)
                stats_temp_pasiva[k] = base * (1 + pct)

            func_pasiva = MAPA_PASIVAS[nombre_agente]

            datos_equipo = {
                "roles": lista_tipos_soportes,
                "elementos": lista_elementos_soportes,
                "facciones": lista_facciones_soportes,
                "nombres": lista_nombres_soportes
            }

            bonos_pasiva = func_pasiva(
                datos_equipo=datos_equipo,
                roles_equipo=lista_tipos_soportes,
                stats_actuales=stats_temp_pasiva,
                nombre_habilidad=estado_build.nombre_habilidad,
                elemento=elemento_agente,
                **sets_externos if isinstance(sets_externos, dict) else {},
                **kwargs
            )
            
            for stat, valor in bonos_pasiva.items():
                if isinstance(valor, (int, float)):
                    es_pct = (stat in STATS_ESCALABLES)
                    agregar_bono(stat, valor, es_pct)
                else:
                    info_especial[stat] = valor

        # --- 5.7. CORE  ---
        if nombre_agente in MAPA_CORE:
            stats_temp_core = base_stats.copy()
            for k, v in sumas_planas.items():
                stats_temp_core[k] = stats_temp_core.get(k, 0.0) + v
            for k, pct in multiplicadores_pct.items():
                base = stats_temp_core.get(k, 0.0)
                stats_temp_core[k] = base * (1 + pct)

            stats_temp_core.update(info_especial)
            
            func_core = MAPA_CORE[nombre_agente]
            
            try:
                bonos_core = func_core(
                    condicion_activa=core_activo, 
                    nombre_habilidad=nombre_habilidad,
                    stats_actuales=stats_temp_core,
                    stacks=stacks_core,
                    tipos_soportes=lista_tipos_soportes,
                )
            except TypeError:
                try:
                    bonos_core = func_core(
                        condicion_activa=core_activo, 
                        nombre_habilidad=nombre_habilidad,
                        stacks=stacks_core,
                        stats_actuales=stats_temp_core
                    )
                except TypeError:
                    bonos_core = func_core(
                        condicion_activa=core_activo, 
                        nombre_habilidad=nombre_habilidad
                    )
            
            for stat, valor in bonos_core.items():
                if stat == "Ataque_Ben_Conversion":
                    agregar_bono("Ataque", valor, False)
                    continue

                if isinstance(valor, (int, float)):
                    es_pct = (stat in STATS_ESCALABLES)
                    agregar_bono(stat, valor, es_pct)
                else:
                    info_especial[stat] = valor

        # --- 6. CÁLCULO FINAL ---
        resultados = {}

        todas_las_keys = set(base_stats.keys()) | set(sumas_planas.keys()) | set(multiplicadores_pct.keys())
        
        for stat_key in todas_las_keys:
            try:
                base_agente = float(base_stats.get(stat_key, 0.0))
            except (ValueError, TypeError):
                base_agente = 0.0
                
            bono_manual = estado_build.bonos_manuales_planos.get(stat_key, 0.0)
            
            if stat_key in STATS_ESCALABLES:
                base_arma = bases_wengine.get(stat_key, 0.0)
                base_total = base_agente + base_arma
                
                pct_total = multiplicadores_pct.get(stat_key, 0.0)
                flat_total = sumas_planas.get(stat_key, 0.0)
                
                valor_final = (base_total * (1 + pct_total)) + flat_total + bono_manual
                resultados[stat_key] = valor_final
            else:
                extras = sumas_planas.get(stat_key, 0.0) + multiplicadores_pct.get(stat_key, 0.0)
                resultados[stat_key] = base_agente + extras + bono_manual
        resultados.update(info_especial)
        
        resultados["Nivel"] = base_stats.get("Nivel", 0)

        # --- 7. BONOS CONDICIONALES DE HABILIDAD ---
        keywords_basic = ["basico"]
        keywords_dash_extra = ["dash"]
        keywords_ex = ["ex", "especial"]
        keywords_assist = ["asistencia"]
        keywords_ulti = ["definitiva"]

        es_basico = any(k in nombre_habilidad_norm for k in keywords_basic)
        es_dash = any(k in nombre_habilidad_norm for k in keywords_dash_extra)
        es_ex = any(k in nombre_habilidad_norm for k in keywords_ex)
        es_assist = any(k in nombre_habilidad_norm for k in keywords_assist)
        es_ulti = any(k in nombre_habilidad_norm for k in keywords_ulti)
        
        bono_dano_condicional = 0.0
        bono_stun_condicional = 0.0
        bono_crit_dmg_condicional = 0.0

        if es_basico: 
            bono_dano_condicional += resultados.get("Bono_Dano_Basico", 0.0)
            bono_stun_condicional += resultados.get("Bono_Stun_Basico", 0.0)
            bono_crit_dmg_condicional += resultados.get("Bono_Crit_DMG_Basico", 0.0)

        if es_dash:
            bono_dano_condicional += resultados.get("Bono_Dash", 0.0)
            bono_dano_condicional += resultados.get("Bono_Dano_Dash", 0.0)
            bono_stun_condicional += resultados.get("Bono_Stun_Dash", 0.0)

        if es_ex: 
            bono_dano_condicional += resultados.get("Bono_Dano_Ex", 0.0)
            bono_stun_condicional += resultados.get("Bono_Stun_Ex", 0.0)
            bono_crit_dmg_condicional += resultados.get("Bono_Crit_DMG_Ex", 0.0)

        if es_assist: 
            bono_dano_condicional += resultados.get("Bono_Dano_Assist", 0.0)
            bono_stun_condicional += resultados.get("Bono_Stun_Assist", 0.0)

        if es_ulti: 
            bono_dano_condicional += resultados.get("Bono_Dano_Ulti", 0.0)
            bono_stun_condicional += resultados.get("Bono_Stun_Ulti", 0.0)
            bono_crit_dmg_condicional += resultados.get("Bono_Crit_DMG_Ulti", 0.0)

        if bono_dano_condicional > 0:
            resultados["Daño_Adicional"] = resultados.get("Daño_Adicional", 0.0) + bono_dano_condicional

        if bono_stun_condicional > 0:
            stun_actual = resultados.get("Aturdimiento", 0.0)
            resultados["Aturdimiento"] = stun_actual * (1 + (bono_stun_condicional / 100.0))

        if bono_crit_dmg_condicional > 0:
            cd_actual = resultados.get("Daño_crítico", 0.0)
            resultados["Daño_crítico"] = cd_actual + bono_crit_dmg_condicional
        
        tipo_sucio = str(tipo_agente or "").lower()
        atk_total = resultados.get("Ataque", 0.0)
        sheer_val = atk_total * 0.3
        if "ruptura" in tipo_sucio:
            hp_total = resultados.get("Puntos_Vida", 0.0)
            sheer_val += (hp_total * 0.1)
        
        bono_core_sheer = sumas_planas.get("Sheer_force", 0.0)
        resultados["Sheer_force"] = sheer_val + bono_core_sheer

        return resultados